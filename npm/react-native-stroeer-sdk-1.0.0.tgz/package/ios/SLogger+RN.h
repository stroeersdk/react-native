//
//  SLogger+RN.h
//  React Native bridge for StroeerSDK SLogger
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RNSLogger : NSObject
+ (void)d:(NSString *)message;
+ (void)i:(NSString *)message;
+ (void)e:(NSString *)message;
@end

NS_ASSUME_NONNULL_END
