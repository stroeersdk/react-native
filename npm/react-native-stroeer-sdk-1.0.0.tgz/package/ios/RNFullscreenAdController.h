#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
#import "RNFullscreenSdkAdapter.h"

NS_ASSUME_NONNULL_BEGIN

extern NSString *const RNFullscreenErrInvalidArgument;
extern NSString *const RNFullscreenErrUnknownAd;
extern NSString *const RNFullscreenErrInvalidState;
extern NSString *const RNFullscreenErrNotReady;
extern NSString *const RNFullscreenErrNoActivity;
extern NSString *const RNFullscreenErrActivityLost;
extern NSString *const RNFullscreenErrLoadFailed;
extern NSString *const RNFullscreenErrLoadTimeout;
extern NSString *const RNFullscreenErrShowFailed;
extern NSString *const RNFullscreenErrDestroyed;
extern NSString *const RNFullscreenErrAppInBackground;

/// Public events of an ad handle. Called on the main thread, after the state transition.
@protocol RNFullscreenAdEvents <NSObject>
- (void)onAdLoaded:(NSString *)adId;
- (void)onAdShowed:(NSString *)adId;
- (void)onAdDismissed:(NSString *)adId;
- (void)onAdClicked:(NSString *)adId;
- (void)onAdImpression:(NSString *)adId;
- (void)onAdFailedToLoad:(NSString *)adId code:(NSString *)code message:(NSString *)message;
- (void)onAdFailedToShow:(NSString *)adId code:(NSString *)code message:(NSString *)message;
@optional
/// Rewarded ads only.
- (void)onUserEarnedReward:(NSString *)adId type:(NSString *)type amount:(double)amount;
@end

/// Shared controller of one-shot full screen ad handles (interstitial, rewarded). Mirrors the
/// Android FullscreenAdController: IDLE -> LOADING -> READY -> SHOWING -> DISMISSED,
/// LOADING -> FAILED, READY / SHOWING -> FAILED; destroy removes the record from any state.
///
/// Confined to the main thread: every method must be called there. Every promise settles exactly
/// once, after the state transition and the event. A failed accepted operation emits one failure
/// event and rejects with the same {code, message}; precondition rejections emit nothing.
@interface RNFullscreenAdController : NSObject

/// @param logTag e.g. "[StroeerInterstitial]", prefixed to every event log line.
- (instancetype)initWithLogTag:(NSString *)logTag
                adapterFactory:(RNFullscreenSdkAdapterFactory)adapterFactory
                        events:(id<RNFullscreenAdEvents>)events NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

- (void)createWithSlot:(NSString *)slot resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject;
- (void)load:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject;
- (void)show:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject;
- (BOOL)isReady:(NSString *)adId;
/// Idempotent: an unknown id resolves.
- (void)destroy:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject;
/// The React instance goes away: cancel timers, reject everything pending, drop every adapter.
- (void)invalidate;

@end

NS_ASSUME_NONNULL_END
