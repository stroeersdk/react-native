#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>

NS_ASSUME_NONNULL_BEGIN

@interface StroeerUtils : NSObject

+ (void)reject:(RCTPromiseRejectBlock)reject withUserInfo:(NSMutableDictionary *)userInfo;

+ (UIViewController *_Nullable)presentingViewController;

@end

NS_ASSUME_NONNULL_END
