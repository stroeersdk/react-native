#import "RNFullscreenSdkAdapter.h"

#import <WebKit/WebKit.h>
#import <StroeerSDK/StroeerSDK-Swift.h>

#import "SLogger+RN.h"

@implementation RNFullscreenSdkCallbacks
@end

// SDK callbacks normally arrive on the main thread; hop there if one does not.
static void RNFullscreenRunOnMain(dispatch_block_t block)
{
  if ([NSThread isMainThread]) {
    block();
  } else {
    dispatch_async(dispatch_get_main_queue(), block);
  }
}

@interface RNInterstitialSdkAdapter () <StroeerInterstitialDelegate>
@end

@implementation RNInterstitialSdkAdapter {
  StroeerInterstitialView *_view;
  RNFullscreenSdkCallbacks *_callbacks;
}

- (void)loadWithSlot:(NSString *)slot callbacks:(RNFullscreenSdkCallbacks *)callbacks
{
  _callbacks = callbacks;
  _view = [[StroeerInterstitialView alloc] initWithAdSlotId:slot publisherDelegate:self];
  [_view load];
}

- (void)showWithViewController:(UIViewController *)viewController
{
  [_view showWithViewController:viewController];
}

- (void)destroy
{
  _callbacks = nil;
  _view = nil;
}

- (BOOL)isCurrent:(StroeerInterstitialView *_Nullable)view
{
  return _view != nil && (view == nil || view == _view);
}

#pragma mark - StroeerInterstitialDelegate

- (void)onAdLoadedWithInterstitial:(StroeerInterstitialView *)interstitial
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(void) = self->_callbacks.onLoaded; if (cb) cb(); }
  });
}

- (void)onAdFailedToLoadWithInterstitial:(StroeerInterstitialView *_Nullable)interstitial error:(NSError *)error
{
  NSString *message = error.localizedDescription;
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(NSString *) = self->_callbacks.onFailedToLoad; if (cb) cb(message); }
  });
}

- (void)onAdShowedFullScreenContentWithInterstitial:(StroeerInterstitialView *)interstitial
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(void) = self->_callbacks.onShowed; if (cb) cb(); }
  });
}

- (void)onAdFailedToShowFullScreenContentWithInterstitial:(StroeerInterstitialView *)interstitial error:(NSError *)error
{
  NSString *message = error.localizedDescription;
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(NSString *) = self->_callbacks.onFailedToShow; if (cb) cb(message); }
  });
}

- (void)onAdDismissedFullScreenContentWithInterstitial:(StroeerInterstitialView *)interstitial
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(void) = self->_callbacks.onDismissed; if (cb) cb(); }
  });
}

- (void)onAdClickedWithInterstitial:(StroeerInterstitialView *)interstitial
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(void) = self->_callbacks.onClicked; if (cb) cb(); }
  });
}

- (void)onAdImpressionWithInterstitial:(StroeerInterstitialView *)interstitial
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:interstitial]) { void (^cb)(void) = self->_callbacks.onImpression; if (cb) cb(); }
  });
}

@end

#pragma mark - Rewarded

@interface RNRewardedSdkAdapter () <StroeerRewardedDelegate>
@end

@implementation RNRewardedSdkAdapter {
  StroeerRewardedView *_view;
  RNFullscreenSdkCallbacks *_callbacks;
}

- (void)loadWithSlot:(NSString *)slot callbacks:(RNFullscreenSdkCallbacks *)callbacks
{
  _callbacks = callbacks;
  _view = [[StroeerRewardedView alloc] initWithAdSlotId:slot publisherDelegate:self];
  [_view load];
}

- (void)showWithViewController:(UIViewController *)viewController
{
  [_view showWithViewController:viewController];
}

- (void)destroy
{
  _callbacks = nil;
  _view = nil;
}

- (BOOL)isCurrent:(StroeerRewardedView *_Nullable)view
{
  return _view != nil && (view == nil || view == _view);
}

#pragma mark - StroeerRewardedDelegate

- (void)onAdLoadedWithRewarded:(StroeerRewardedView *)rewarded
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(void) = self->_callbacks.onLoaded; if (cb) cb(); }
  });
}

- (void)onAdFailedToLoadWithRewarded:(StroeerRewardedView *_Nullable)rewarded error:(NSError *)error
{
  NSString *message = error.localizedDescription;
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(NSString *) = self->_callbacks.onFailedToLoad; if (cb) cb(message); }
  });
}

- (void)onAdShowedFullScreenContentWithRewarded:(StroeerRewardedView *)rewarded
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(void) = self->_callbacks.onShowed; if (cb) cb(); }
  });
}

- (void)onAdFailedToShowFullScreenContentWithRewarded:(StroeerRewardedView *)rewarded error:(NSError *)error
{
  NSString *message = error.localizedDescription;
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(NSString *) = self->_callbacks.onFailedToShow; if (cb) cb(message); }
  });
}

// The DISMISSED callback, not onAdWillDismissFullScreenContent: the handle must not settle
// while the ad is still on screen.
- (void)onAdDismissedFullScreenContentWithRewarded:(StroeerRewardedView *)rewarded
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(void) = self->_callbacks.onDismissed; if (cb) cb(); }
  });
}

- (void)onAdClickedWithRewarded:(StroeerRewardedView *)rewarded
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(void) = self->_callbacks.onClicked; if (cb) cb(); }
  });
}

- (void)onAdImpressionWithRewarded:(StroeerRewardedView *)rewarded
{
  RNFullscreenRunOnMain(^{
    if ([self isCurrent:rewarded]) { void (^cb)(void) = self->_callbacks.onImpression; if (cb) cb(); }
  });
}

- (void)onUserEarnedRewardWithRewarded:(StroeerRewardedView *)rewarded amount:(NSDecimalNumber *)amount type:(NSString *)type
{
  // NSDecimalNumber -> double keeps every finite value; NaN / non-finite / nil is not a reward.
  double value = amount != nil ? amount.doubleValue : NAN;
  BOOL valid = amount != nil && isfinite(value);
  RNFullscreenRunOnMain(^{
    if (![self isCurrent:rewarded]) return;
    void (^cb)(NSString *, NSNumber *) = self->_callbacks.onUserEarnedReward;
    if (!cb) return;
    if (!valid) {
      [RNSLogger e:[NSString stringWithFormat:@"[StroeerRewarded] The SDK delivered a missing or non-finite reward amount (%@); no reward event emitted", amount]];
      return;
    }
    cb(type, @(value));
  });
}

@end
