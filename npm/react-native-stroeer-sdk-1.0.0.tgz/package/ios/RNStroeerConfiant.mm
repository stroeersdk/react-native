#import <React/RCTBridgeModule.h>
#import <React/RCTUtils.h>
#import <ReactCommon/RCTTurboModule.h>
#import <RNStroeerSpec/RNStroeerSpec.h>
#import <WebKit/WebKit.h>
#import <StroeerSDK/StroeerSDK-Swift.h>

#import "SLogger+RN.h"

static NSString *const kTag = @"[StroeerConfiant]";
static const int64_t kInitTimeoutSeconds = 60;

// Process-wide state, main-queue confined. ConfiantLoader is a process-wide singleton, so its
// attempt state must outlive any single module instance: bridgeless creates a NEW module
// instance after a JS reload, and that instance must not call initialize again on an
// already-initialized/initializing loader (the loader would never call back).
// The proper fix needs an SDK status API or an unconditional completion callback.
static NSNumber *gCachedResult;      // first SDK result; once set the loader is never called again
static BOOL gSdkAttemptRunning;      // SDK attempt not reported yet (survives a JS timeout/reload)
static BOOL gInitializeRequested;    // the SDK has read its test mode
static NSUInteger gAttemptToken;

@interface RNStroeerConfiant : NativeStroeerConfiantModuleSpecBase <NativeStroeerConfiantModuleSpec>
- (void)settlePendingForToken:(NSUInteger)token;
@end

/**
 * All state below is touched on the main queue only (methodQueue; SDK completions and the timeout
 * are hopped onto it).
 *
 * ConfiantLoader facts: it keeps ONE completion (a later initialize overwrites it), may invoke it
 * from a background Task and again for later internal attempts, and never invokes it when it is
 * already initialized or initializing. Hence the SDK attempt is tracked separately from the JS
 * promise, the first result is cached, and later invocations are ignored.
 */
// Only the first result of the running attempt counts; later callbacks are ignored. Updates the
// process-wide cache even if the module instance that started the attempt is gone.
static void RNStroeerConfiantOnSdkResult(BOOL success, NSUInteger token, RNStroeerConfiant *owner);

@implementation RNStroeerConfiant {
  RCTPromiseResolveBlock _pendingResolve;
  RCTPromiseRejectBlock _pendingReject;
  NSUInteger _pendingToken;       // attempt the pending promise belongs to; 0 = none
}

RCT_EXPORT_MODULE(StroeerConfiantModule)

+ (BOOL)requiresMainQueueSetup
{
  return YES;
}

- (dispatch_queue_t)methodQueue
{
  return dispatch_get_main_queue();
}

- (void)invalidate
{
  // Reject the JS promise; the SDK attempt itself keeps running process-wide and still updates
  // the process-wide cache when it reports.
  [self rejectPendingForToken:_pendingToken code:@"MODULE_INVALIDATED" message:@"StroeerConfiant module was invalidated"];
}

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:(const facebook::react::ObjCTurboModule::InitParams &)params
{
  return std::make_shared<facebook::react::NativeStroeerConfiantModuleSpecJSI>(params);
}

#pragma mark - NativeStroeerConfiantModuleSpec

- (void)enableTestMode
{
  if (gInitializeRequested) {
    [RNSLogger e:[NSString stringWithFormat:@"%@ enableTestMode ignored: initialize was already requested", kTag]];
    return;
  }
  [[ConfiantLoader shared] enableTestMode];
}

- (void)initialize:(NSString *)confiantPropertyId
      enableReload:(BOOL)enableReload
           resolve:(RCTPromiseResolveBlock)resolve
            reject:(RCTPromiseRejectBlock)reject
{
  NSString *trimmed = [confiantPropertyId stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
  if (trimmed.length == 0) {
    reject(@"INVALID_ARGUMENT", @"confiantPropertyId must not be blank", nil);
    return;
  }

  if (gCachedResult != nil) {
    resolve(gCachedResult);
    return;
  }

  if (gSdkAttemptRunning) {
    reject(@"ALREADY_INITIALIZING", @"Confiant initialization is already in progress", nil);
    return;
  }

  gInitializeRequested = YES;
  gSdkAttemptRunning = YES;
  NSUInteger token = ++gAttemptToken;
  _pendingResolve = resolve;
  _pendingReject = reject;
  _pendingToken = token;

  __weak RNStroeerConfiant *weakSelf = self;

  @try {
    [[ConfiantLoader shared] initializeWithConfiantPropertyId:confiantPropertyId
                                                 enableReload:enableReload
                                                   completion:^(BOOL success) {
      dispatch_async(dispatch_get_main_queue(), ^{
        RNStroeerConfiantOnSdkResult(success, token, weakSelf);
      });
    }];
  } @catch (NSException *exception) {
    gSdkAttemptRunning = NO;
    [self rejectPendingForToken:token code:@"INIT_FAILED" message:exception.reason ?: @"Confiant initialization failed"];
    return;
  }

  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, kInitTimeoutSeconds * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
    [weakSelf rejectPendingForToken:token code:@"INIT_TIMEOUT" message:@"Confiant did not report back in time"];
  });
}

#pragma mark - Private

- (void)settlePendingForToken:(NSUInteger)token
{
  if (_pendingToken == token && _pendingResolve) {
    RCTPromiseResolveBlock resolve = _pendingResolve;
    _pendingResolve = nil;
    _pendingReject = nil;
    _pendingToken = 0;
    resolve(gCachedResult);
  }
}

- (void)rejectPendingForToken:(NSUInteger)token code:(NSString *)code message:(NSString *)message
{
  if (_pendingToken != token || !_pendingReject) {
    return;
  }
  RCTPromiseRejectBlock reject = _pendingReject;
  _pendingResolve = nil;
  _pendingReject = nil;
  _pendingToken = 0;
  reject(code, message, nil);
}

@end

static void RNStroeerConfiantOnSdkResult(BOOL success, NSUInteger token, RNStroeerConfiant *owner)
{
  if (!gSdkAttemptRunning || token != gAttemptToken) {
    return;
  }
  gSdkAttemptRunning = NO;
  gCachedResult = @(success);
  [owner settlePendingForToken:token];
}
