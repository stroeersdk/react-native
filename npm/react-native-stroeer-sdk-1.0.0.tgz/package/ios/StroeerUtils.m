#import "StroeerUtils.h"
#import <React/RCTUtils.h>

@implementation StroeerUtils

+ (void)reject:(RCTPromiseRejectBlock)reject withUserInfo:(NSMutableDictionary *)userInfo {
  NSString *code = [userInfo[@"code"] respondsToSelector:@selector(stringValue)]
    ? [userInfo[@"code"] stringValue]
    : @"UNKNOWN";
  NSString *message = userInfo[@"message"] ?: @"Unknown error";
  reject(code, message, nil); // nil to suppress nativeStackIOS
}

+ (UIWindow *_Nullable)activeKeyWindow
{
  for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
    if (scene.activationState != UISceneActivationStateForegroundActive) continue;
    if (![scene isKindOfClass:[UIWindowScene class]]) continue;

    UIWindowScene *ws = (UIWindowScene *)scene;
    for (UIWindow *w in ws.windows) {
      if (w.isKeyWindow) {
        return w;
      }
    }
  }
  // Fallback: first window in any foreground scene
  for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
    if (![scene isKindOfClass:[UIWindowScene class]]) continue;
    UIWindowScene *ws = (UIWindowScene *)scene;
    UIWindow *w = ws.windows.firstObject;
    if (w) return w;
  }
  return nil;
}

+ (UIViewController *_Nullable)presentingViewController
{
  // 1) Best for RN apps
  UIViewController *vc = RCTPresentedViewController();
  if (vc) {
    // Still normalize it (container/presented)
  } else {
    // 2) Scene-safe key window root VC
    UIWindow *keyWindow = [self activeKeyWindow];
    vc = keyWindow.rootViewController;
  }

  if (!vc) return nil;

  // 3) Resolve to the best presenter (loop until stable)
  BOOL changed = YES;
  while (changed && vc) {
    changed = NO;

    // Presented VC wins
    if (vc.presentedViewController) {
      vc = vc.presentedViewController;
      changed = YES;
      continue;
    }

    // Container controllers
    if ([vc isKindOfClass:[UINavigationController class]]) {
      UIViewController *visible = ((UINavigationController *)vc).visibleViewController;
      if (visible && visible != vc) {
        vc = visible;
        changed = YES;
        continue;
      }
    }

    if ([vc isKindOfClass:[UITabBarController class]]) {
      UIViewController *selected = ((UITabBarController *)vc).selectedViewController;
      if (selected && selected != vc) {
        vc = selected;
        changed = YES;
        continue;
      }
    }

    if ([vc isKindOfClass:[UISplitViewController class]]) {
      UIViewController *last = ((UISplitViewController *)vc).viewControllers.lastObject;
      if (last && last != vc) {
        vc = last;
        changed = YES;
        continue;
      }
    }
  }

  return vc;
}

@end
