#import "RNStroeerBannerComponentView.h"

#import <react/renderer/components/RNStroeerSpec/ComponentDescriptors.h>
#import <react/renderer/components/RNStroeerSpec/EventEmitters.h>
#import <react/renderer/components/RNStroeerSpec/Props.h>
#import <react/renderer/components/RNStroeerSpec/RCTComponentViewHelpers.h>

#import "SLogger+RN.h"

#import <WebKit/WebKit.h>
#import <StroeerSDK/StroeerSDK-Swift.h>
#import <React/UIView+React.h>

using namespace facebook::react;

static NSString *const kErrInvalidArgument = @"INVALID_ARGUMENT";
static NSString *const kErrSetupFailed = @"SETUP_FAILED";
static NSString *const kErrLoadFailed = @"LOAD_FAILED";

static NSString *RNBannerString(const std::string &s)
{
  return [NSString stringWithUTF8String:s.c_str()] ?: @"";
}

@interface RNStroeerBannerComponentView () <StroeerBannerViewDelegate>
@end

@implementation RNStroeerBannerComponentView {
  // Pending config: written by -updateProps:oldProps:, committed in -finalizeUpdates:.
  BOOL _hasPending;
  NSString *_pendingSlot;
  NSString *_pendingContentUrl;
  NSDictionary<NSString *, NSString *> *_pendingTargeting;
  BOOL _pendingTargetingValid;

  // Committed config (what the current banner / attempt belongs to).
  BOOL _hasCommitted;
  NSString *_slot;
  NSString *_contentUrl;
  NSDictionary<NSString *, NSString *> *_targeting;
  BOOL _targetingValid;

  StroeerBannerView *_banner;
  __weak UIViewController *_presenter;
  BOOL _attempted;      // load (or an INVALID_ARGUMENT / SETUP_FAILED report) done for the committed config
  BOOL _loadScheduled;  // a posted load block is pending
  BOOL _disposed;
  NSUInteger _generation;  // bumped on every config change / teardown
  NSUInteger _loadToken;   // bumped to cancel only the pending scheduled load
  NSUInteger _presenterRetries;  // bounded wait for a presenter view controller
  BOOL _retryArmed;
}

+ (ComponentDescriptorProvider)componentDescriptorProvider
{
  return concreteComponentDescriptorProvider<StroeerBannerViewComponentDescriptor>();
}

// The SDK leaves Auto Layout constraints on its superview and delivers async refresh callbacks,
// so a banner view must never be handed to another JS component through the recycle pool.
+ (BOOL)shouldBeRecycled
{
  return NO;
}

- (instancetype)initWithFrame:(CGRect)frame
{
  if (self = [super initWithFrame:frame]) {
    static const auto defaultProps = std::make_shared<const StroeerBannerViewProps>();
    _props = defaultProps;
    _pendingTargeting = @{};
    _pendingTargetingValid = YES;
    // The Fabric host is typically 0x0 until JS applies the size from onAdLoaded. Do not clip,
    // so the SDK banner (own size + centering constraints) stays visible/measurable meanwhile.
    self.clipsToBounds = NO;
    _targeting = @{};
    _targetingValid = YES;
  }
  return self;
}

#pragma mark - Props

- (void)updateProps:(Props::Shared const &)props oldProps:(Props::Shared const &)oldProps
{
  const auto &newProps = static_cast<const StroeerBannerViewProps &>(*props);

  _hasPending = YES;
  _pendingSlot = RNBannerString(newProps.publisherSlotName);
  // nil and "" are equivalent.
  _pendingContentUrl = newProps.contentUrl.empty() ? nil : RNBannerString(newProps.contentUrl);

  // customTargeting is UnsafeMixed (folly::dynamic): null/absent -> empty (valid); an object of
  // string values -> copied map; anything else -> invalid.
  const folly::dynamic &targeting = newProps.customTargeting;
  if (targeting.isNull()) {
    _pendingTargeting = @{};
    _pendingTargetingValid = YES;
  } else if (targeting.isObject()) {
    NSMutableDictionary<NSString *, NSString *> *map = [NSMutableDictionary dictionary];
    BOOL valid = YES;
    for (const auto &item : targeting.items()) {
      if (!item.first.isString() || !item.second.isString()) {
        valid = NO;
        break;
      }
      map[RNBannerString(item.first.getString())] = RNBannerString(item.second.getString());
    }
    _pendingTargeting = valid ? [map copy] : @{};
    _pendingTargetingValid = valid;
  } else {
    _pendingTargeting = @{};
    _pendingTargetingValid = NO;
  }

  [super updateProps:props oldProps:oldProps];
}

- (BOOL)pendingDiffersFromCommitted
{
  if (!_hasCommitted) {
    return YES;
  }
  return _pendingTargetingValid != _targetingValid ||
      ![_pendingSlot ?: @"" isEqualToString:_slot ?: @""] ||
      ![_pendingContentUrl ?: @"" isEqualToString:_contentUrl ?: @""] ||
      ![_pendingTargeting isEqualToDictionary:_targeting];
}

- (void)finalizeUpdates:(RNComponentViewUpdateMask)updateMask
{
  [super finalizeUpdates:updateMask];

  if (_disposed || !_hasPending) {
    return;
  }

  if ([self pendingDiffersFromCommitted]) {
    _hasCommitted = YES;
    _slot = _pendingSlot;
    _contentUrl = _pendingContentUrl;
    _targeting = _pendingTargeting;
    _targetingValid = _pendingTargetingValid;

    // Bump the generation first so any in-flight callback of the old banner is ignored.
    _generation++;
    _loadToken++;
    _loadScheduled = NO;
    _retryArmed = NO;
    _presenterRetries = 0;
    [self destroyBanner];
    _attempted = NO;
  }

  // Identical config (style / size re-renders): reconcile only, never reload.
  [self reconcile];
}

#pragma mark - Reconcile

- (void)reconcile
{
  if (_disposed || !_hasCommitted || self.window == nil || _attempted) {
    return;
  }

  if (_slot.length == 0 || !_targetingValid) {
    _attempted = YES;
    [self emitFailureWithCode:kErrInvalidArgument
                      message:@"Invalid banner configuration: publisherSlotName must be non-empty and customTargeting must be a map of strings"];
    return;
  }

  if (_banner == nil) {
    UIViewController *presenter = [self findViewController];
    if (presenter == nil) {
      // Wait (no event, like Android): bounded retry while attached, also retried on the
      // next attach / transaction.
      [self armPresenterRetry];
      return;
    }

    @try {
      StroeerBannerView *banner = [[StroeerBannerView alloc] initWithAdSlotId:_slot
                                                       publisherViewController:presenter
                                                             publisherDelegate:self];
      // Configure before load, mirroring the Android bannerView.bannerConfig.customTargeting.
      // -contentUrl / -customTargeting are the ObjC-visible passthroughs onto
      // StroeerBannerView.bannerConfiguration (BannerAdConfiguration : AdConfiguration), which
      // is not itself exposed to ObjC. The initializer does not start the request.
      if (_contentUrl != nil) {
        banner.contentUrl = _contentUrl;
      }
      if (_targeting.count > 0) {
        banner.customTargeting = _targeting;
        [RNSLogger d:[NSString stringWithFormat:@"[RNStroeerBannerComponentView] Added custom targeting: %@ for %@", _targeting, _slot]];
      }

      // Note: we deliberately do NOT set the banner's frame. StroeerBannerView sets
      // translatesAutoresizingMaskIntoConstraints = NO and installs its own centerX/centerY
      // constraints against its superview (didMoveToSuperview) plus width/height constraints
      // (applySize); assigning a frame would fight Auto Layout. The container is sized by JS
      // from the width/height reported in onAdLoaded.
      _banner = banner;
      _presenter = presenter;
      [self addSubview:banner];
    } @catch (NSException *exception) {
      _attempted = YES;
      [self destroyBanner];
      [self emitFailureWithCode:kErrSetupFailed message:exception.reason ?: @"Failed to set up banner"];
      return;
    }
  }

  _presenterRetries = 0;
  if (_loadScheduled) {
    return;
  }
  _loadScheduled = YES;

  // Post the load so it runs after the current mount transaction / layout pass.
  NSUInteger generation = _generation;
  NSUInteger token = _loadToken;
  StroeerBannerView *scheduledBanner = _banner;
  __weak RNStroeerBannerComponentView *weakSelf = self;
  dispatch_async(dispatch_get_main_queue(), ^{
    RNStroeerBannerComponentView *strongSelf = weakSelf;
    if (!strongSelf) {
      return;
    }
    [strongSelf performScheduledLoadWithBanner:scheduledBanner generation:generation token:token];
  });
}

- (void)performScheduledLoadWithBanner:(StroeerBannerView *)banner generation:(NSUInteger)generation token:(NSUInteger)token
{
  if (_disposed || generation != _generation || token != _loadToken || _banner != banner) {
    return;
  }
  _loadScheduled = NO;

  if (self.window == nil) {
    // Detached; reconcile again on the next attach.
    return;
  }
  UIViewController *current = [self findViewController];
  if (current == nil || current != _presenter) {
    // The SDK banner keeps the presenter it was constructed with. If the presenter changed (or
    // went away) the prepared banner is stale: drop it and prepare a new one for the current one.
    // Mirrors Android's Activity-identity check.
    _generation++;
    [self destroyBanner];
    [self reconcile];
    return;
  }

  _attempted = YES;
  @try {
    [banner load];
  } @catch (NSException *exception) {
    [self emitFailureWithCode:kErrSetupFailed message:exception.reason ?: @"Failed to load banner"];
  }
}

- (void)armPresenterRetry
{
  if (_retryArmed || _disposed) {
    return;
  }
  if (_presenterRetries >= 20) {
    if (_presenterRetries == 20) {
      _presenterRetries++;
      [RNSLogger i:[NSString stringWithFormat:@"[RNStroeerBannerComponentView] No presenter view controller found for %@; waiting for the next attach / update", _slot]];
    }
    return;
  }
  _presenterRetries++;
  _retryArmed = YES;
  NSUInteger generation = _generation;
  NSUInteger token = _loadToken;
  __weak RNStroeerBannerComponentView *weakSelf = self;
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(250 * NSEC_PER_MSEC)), dispatch_get_main_queue(), ^{
    RNStroeerBannerComponentView *strongSelf = weakSelf;
    if (!strongSelf) {
      return;
    }
    strongSelf->_retryArmed = NO;
    if (strongSelf->_disposed || generation != strongSelf->_generation || token != strongSelf->_loadToken) {
      return;
    }
    [strongSelf reconcile];
  });
}

/**
 * Native layout pass over the HOST, not just the SDK child: -layoutIfNeeded on the child does
 * not lay out its superview, and the SDK banner positions itself with its own size + centering
 * constraints against this host. The host is typically 0x0 until JS applies the size from
 * onAdLoaded, so the load is never blocked on the host size (that would deadlock) and the
 * host is not clipping. The banner's constraints must not resize the Fabric host (its frame is
 * owned by Yoga). Mirrors Android's relayoutBanner workaround for GAM viewability.
 */
- (void)relayoutBanner
{
  if (_banner == nil) {
    return;
  }
  [_banner setNeedsLayout];
  [self setNeedsLayout];
  [self layoutIfNeeded];
  [_banner layoutIfNeeded];
}

- (void)destroyBanner
{
  StroeerBannerView *banner = _banner;
  _banner = nil;
  _presenter = nil;
  if (banner == nil) {
    return;
  }
  [banner removeFromSuperview];
  [banner destroy];
}

#pragma mark - Presenter

- (UIViewController *)findViewController
{
  UIViewController *vc = self.reactViewController;

  if (!vc) {
    // Nearest VC in responder chain
    UIResponder *responder = self;
    while ((responder = responder.nextResponder)) {
      if ([responder isKindOfClass:[UIViewController class]]) {
        vc = (UIViewController *)responder;
        break;
      }
    }
  }

  if (!vc) {
    // No reliable VC
    return nil;
  }

  // Resolve to the best presenter
  BOOL changed = YES;
  while (changed && vc) {
    changed = NO;

    // Presented VC wins
    if (vc.presentedViewController) {
      vc = vc.presentedViewController;
      changed = YES;
      continue;
    }

    // Container controllers
    if ([vc isKindOfClass:[UINavigationController class]]) {
      UIViewController *visible = ((UINavigationController *)vc).visibleViewController;
      if (visible && visible != vc) {
        vc = visible;
        changed = YES;
        continue;
      }
    }

    if ([vc isKindOfClass:[UITabBarController class]]) {
      UIViewController *selected = ((UITabBarController *)vc).selectedViewController;
      if (selected && selected != vc) {
        vc = selected;
        changed = YES;
        continue;
      }
    }

    if ([vc isKindOfClass:[UISplitViewController class]]) {
      UIViewController *last = ((UISplitViewController *)vc).viewControllers.lastObject;
      if (last && last != vc) {
        vc = last;
        changed = YES;
        continue;
      }
    }
  }

  return vc;
}

#pragma mark - Lifecycle

- (void)didMoveToWindow
{
  [super didMoveToWindow];

  if (_disposed) {
    return;
  }

  if (self.window != nil) {
    _presenterRetries = 0;
    [self relayoutBanner];
    [self reconcile];
  } else {
    // Detach: cancel only the pending scheduled load. Never destroy or reload on
    // detach/reattach; the banner is torn down in -invalidate or on a config change.
    _loadToken++;
    _loadScheduled = NO;
    _retryArmed = NO;
  }
}

- (void)invalidate
{
  _disposed = YES;
  _generation++;
  _loadToken++;
  _loadScheduled = NO;
  _retryArmed = NO;
  [self destroyBanner];
  // RCTViewComponentView does not implement -invalidate; only forward if a superclass does.
  if ([RCTViewComponentView instancesRespondToSelector:@selector(invalidate)]) {
    [super invalidate];
  }
}

- (void)dealloc
{
  // Defensive only: -invalidate normally already ran. Capture only the banner, never self.
  StroeerBannerView *banner = _banner;
  _banner = nil;
  if (banner == nil) {
    return;
  }
  void (^teardown)(void) = ^{
    [banner removeFromSuperview];
    [banner destroy];
  };
  if ([NSThread isMainThread]) {
    teardown();
  } else {
    dispatch_async(dispatch_get_main_queue(), teardown);
  }
}

#pragma mark - Events

- (std::shared_ptr<const StroeerBannerViewEventEmitter>)emitter
{
  return std::static_pointer_cast<const StroeerBannerViewEventEmitter>(_eventEmitter);
}

- (void)emitFailureWithCode:(NSString *)code message:(NSString *)message
{
  auto emitter = [self emitter];
  if (!emitter) {
    return;
  }
  StroeerBannerViewEventEmitter::OnAdFailedToLoad event{
      .publisherSlotName = std::string(_slot.UTF8String ?: ""),
      .error = {.code = std::string(code.UTF8String ?: ""), .message = std::string(message.UTF8String ?: "")}};
  emitter->onAdFailedToLoad(std::move(event));
}

/**
 * Runs `block` on the main queue only if the callback still belongs to the live banner of the
 * current generation. Stale callbacks (old banner, torn down view) are ignored.
 */
- (void)dispatchForBanner:(StroeerBannerView *)banner name:(NSString *)name block:(void (^)(RNStroeerBannerComponentView *view))block
{
  NSUInteger generation = _generation;
  __weak RNStroeerBannerComponentView *weakSelf = self;
  dispatch_async(dispatch_get_main_queue(), ^{
    RNStroeerBannerComponentView *strongSelf = weakSelf;
    if (!strongSelf || strongSelf->_disposed || generation != strongSelf->_generation || strongSelf->_banner != banner) {
      [RNSLogger d:[NSString stringWithFormat:@"[RNStroeerBannerComponentView] Ignoring stale %@ callback", name]];
      return;
    }
    block(strongSelf);
  });
}

// Sizes in points. -getBannerSize is the SDK's authoritative size (bannerConfiguration.adSize).
// StroeerBannerView does NOT override -intrinsicContentSize (it sizes itself with Auto Layout
// constraints), so intrinsicContentSize is UIViewNoIntrinsicMetric (-1) and must not be used.
- (BOOL)readSize:(CGSize *)outSize source:(NSString **)outSource banner:(StroeerBannerView *)banner
{
  [self relayoutBanner];
  CGSize size = [banner getBannerSize];
  *outSize = size;
  *outSource = [banner getSource].adSubSource ?: @"";
  return size.width > 0.0 && size.height > 0.0;
}

- (void)emitSizedEventLoaded:(BOOL)loaded banner:(StroeerBannerView *)banner
{
  auto emitter = [self emitter];
  if (!emitter) {
    return;
  }
  CGSize size = CGSizeZero;
  NSString *source = @"";
  BOOL valid = [self readSize:&size source:&source banner:banner];

  if (loaded && !valid) {
    [RNSLogger i:[NSString stringWithFormat:@"[RNStroeerBannerComponentView] Banner loaded with invalid size %.2fx%.2f", size.width, size.height]];
    [self emitFailureWithCode:kErrLoadFailed message:@"Banner loaded with invalid size"];
    return;
  }
  if (!loaded && !valid) {
    // Impression with an unusable size: nothing sensible to report.
    return;
  }

  std::string slot(_slot.UTF8String ?: "");
  if (loaded) {
    emitter->onAdLoaded({slot, size.width, size.height, std::string(source.UTF8String ?: "")});
  } else {
    emitter->onAdImpression({slot, size.width, size.height, std::string(source.UTF8String ?: "")});
  }
}

#pragma mark - StroeerBannerViewDelegate

- (void)bannerViewDidReceiveAd:(StroeerBannerView *)bannerView
{
  [self dispatchForBanner:bannerView name:@"didReceiveAd" block:^(RNStroeerBannerComponentView *view) {
    [view emitSizedEventLoaded:YES banner:bannerView];
  }];
}

- (void)bannerView:(StroeerBannerView *)bannerView didFailToReceiveAdWithError:(NSError *)error
{
  // A refresh failure keeps the existing creative: do not destroy / reload here.
  NSString *message = error.localizedDescription ?: @"Unknown error";
  [self dispatchForBanner:bannerView name:@"didFailToReceiveAd" block:^(RNStroeerBannerComponentView *view) {
    [view emitFailureWithCode:kErrLoadFailed message:message];
  }];
}

- (void)bannerViewWillPresentScreen:(StroeerBannerView *)bannerView
{
  [self dispatchForBanner:bannerView name:@"willPresentScreen" block:^(RNStroeerBannerComponentView *view) {
    auto emitter = [view emitter];
    if (emitter) {
      emitter->onAdOpened({std::string(view->_slot.UTF8String ?: "")});
    }
  }];
}

- (void)bannerViewWillDismissScreen:(StroeerBannerView *)bannerView
{
  // Not in use
}

- (void)bannerViewDidDismissScreen:(StroeerBannerView *)bannerView
{
  [self dispatchForBanner:bannerView name:@"didDismissScreen" block:^(RNStroeerBannerComponentView *view) {
    auto emitter = [view emitter];
    if (emitter) {
      emitter->onAdClosed({std::string(view->_slot.UTF8String ?: "")});
    }
  }];
}

- (void)bannerViewDidRecordClick:(StroeerBannerView *)bannerView
{
  [self dispatchForBanner:bannerView name:@"didRecordClick" block:^(RNStroeerBannerComponentView *view) {
    auto emitter = [view emitter];
    if (emitter) {
      emitter->onAdClicked({std::string(view->_slot.UTF8String ?: "")});
    }
  }];
}

- (void)bannerViewDidRecordImpression:(StroeerBannerView *)bannerView
{
  // Size/source are re-read: a refreshed creative can render at a different size than the one
  // reported by -bannerViewDidReceiveAd:, which would leave the RN container stale (matches
  // Android, which also re-reports on impression).
  [self dispatchForBanner:bannerView name:@"didRecordImpression" block:^(RNStroeerBannerComponentView *view) {
    [view emitSizedEventLoaded:NO banner:bannerView];
  }];
}

@end
