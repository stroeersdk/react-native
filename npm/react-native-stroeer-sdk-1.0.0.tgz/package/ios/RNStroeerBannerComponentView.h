#import <React/RCTViewComponentView.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Fabric component view of the banner (JS component name "StroeerBannerView"; mapped through
 * codegenConfig.ios.componentProvider in package.json). Fully prop driven: props only update a
 * pending config which is committed once per transaction in -finalizeUpdates:, and the view
 * decides when to load. Mirrors the Android StroeerBannerContainer.
 */
@interface RNStroeerBannerComponentView : RCTViewComponentView

@end

NS_ASSUME_NONNULL_END
