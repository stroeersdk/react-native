//
//  SLogger+RN.m
//  React Native bridge for StroeerSDK SLogger
//

#import "SLogger+RN.h"
@import StroeerSDK;

// Use runtime to get the Swift class
#define SLoggerClass NSClassFromString(@"StroeerSDK.SLogger")

@implementation RNSLogger

typedef void (*LogFunc)(id, SEL, NSString *);

+ (void)d:(NSString *)message {
    [self callSelector:@selector(d:) message:message];
}

+ (void)i:(NSString *)message {
    [self callSelector:@selector(i:) message:message];
}

+ (void)e:(NSString *)message {
    [self callSelector:@selector(e:) message:message];
}

+ (void)callSelector:(SEL)selector message:(NSString *)message {
    if (!SLoggerClass || ![SLoggerClass respondsToSelector:selector]) {
        // Fallback to NSLog if SLogger is not available
        NSString *level = @"INFO";
        if (selector == @selector(d:)) {
            level = @"DEBUG";
        } else if (selector == @selector(e:)) {
            level = @"ERROR";
        }
        NSLog(@"[%@] %@", level, message);
        return;
    }

    // Optional: enforce main thread if needed
    dispatch_async(dispatch_get_main_queue(), ^{
        LogFunc func = (LogFunc)[SLoggerClass methodForSelector:selector];
        func(SLoggerClass, selector, message);
    });
}

@end
