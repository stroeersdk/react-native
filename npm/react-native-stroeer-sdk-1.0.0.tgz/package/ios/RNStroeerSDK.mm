#import <React/RCTBridgeModule.h>
#import <React/RCTUtils.h>
#import <ReactCommon/RCTTurboModule.h>
#import <RNStroeerSpec/RNStroeerSpec.h>

#import <WebKit/WebKit.h>
#import <StroeerSDK/StroeerSDK-Swift.h>

#import "SLogger+RN.h"

#pragma mark - Targeting helpers

// Normalises the JS object into the [String: [String]] shape setGlobalCustomTargeting wants,
// like Android: keys pass through unchanged (the SDK itself special-cases "user" and "context"
// and filters the values). Only arrays whose members are all strings are accepted; any other
// entry (non-string/empty key, scalar, mixed array) is skipped whole. Values keep their exact
// text and empty arrays are kept.
static NSDictionary<NSString *, NSArray<NSString *> *> *RNTargetingMapFromDictionary(NSDictionary *targeting)
{
  NSMutableDictionary<NSString *, NSArray<NSString *> *> *map = [NSMutableDictionary dictionary];
  for (id rawKey in targeting) {
    if (![rawKey isKindOfClass:[NSString class]] || [(NSString *)rawKey length] == 0) {
      continue;
    }
    id value = targeting[rawKey];
    if (![value isKindOfClass:[NSArray class]]) {
      continue;
    }
    BOOL allStrings = YES;
    for (id item in (NSArray *)value) {
      if (![item isKindOfClass:[NSString class]]) {
        allStrings = NO;
        break;
      }
    }
    if (allStrings) {
      map[(NSString *)rawKey] = (NSArray<NSString *> *)value;
    }
  }
  return map;
}

// Shape of NativeSlotNames in src/specs/NativeStroeerSDKModule.ts.
static NSDictionary *RNSlotNamesFromConfiguration(Configuration *configuration)
{
  return @{
    @"bannerSlots" : [configuration getBannerNames],
    @"interstitialSlots" : [configuration getInterstitialNames],
  };
}

#pragma mark - Pending promise

// A promise that settles exactly once, whichever of the SDK completion or invalidate() gets there
// first. Only touched on the main queue.
@interface RNSDKPendingCall : NSObject
- (instancetype)initWithResolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject;
- (void)resolveWith:(id)value;
- (void)rejectWithCode:(NSString *)code message:(NSString *)message;
@end

@implementation RNSDKPendingCall {
  RCTPromiseResolveBlock _resolve;
  RCTPromiseRejectBlock _reject;
  BOOL _settled;
}

- (instancetype)initWithResolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  if ((self = [super init])) {
    _resolve = [resolve copy];
    _reject = [reject copy];
  }
  return self;
}

- (void)resolveWith:(id)value
{
  if (_settled) return;
  _settled = YES;
  _resolve(value);
}

- (void)rejectWithCode:(NSString *)code message:(NSString *)message
{
  if (_settled) return;
  _settled = YES;
  _reject(code, message, nil);
}

@end

// Timeout for waiting on a freshly loaded configuration (same as the SDK's default).
static const NSTimeInterval kConfigTimeoutSeconds = 10.0;

typedef void (^RNSDKOperation)(void (^done)(void));

@interface RNStroeerSDK : NativeStroeerSDKModuleSpecBase <NativeStroeerSDKModuleSpec>
@end

@implementation RNStroeerSDK {
  // Everything below is only touched on the main queue (see methodQueue).
  BOOL _invalidated;
  // Serialization chain shared by setApplicationName and resetAndLoadConfiguration, the
  // counterpart of Android's single lock: a reset must never interleave with a standalone
  // setApplicationName. Operations run one at a time in FIFO order; each calls `done` when
  // finished, which starts the next one.
  NSMutableArray<RNSDKOperation> *_queue;
  BOOL _operationRunning;
  // Every promise not yet settled, so invalidate() can reject them.
  NSMutableSet<RNSDKPendingCall *> *_pending;
}

RCT_EXPORT_MODULE(StroeerSDK)

+ (BOOL)requiresMainQueueSetup
{
  return YES;
}

- (dispatch_queue_t)methodQueue
{
  return dispatch_get_main_queue();
}

- (instancetype)init
{
  if ((self = [super init])) {
    _queue = [NSMutableArray array];
    _pending = [NSMutableSet set];
  }
  return self;
}

- (void)invalidate
{
  // Same contract as Android's invalidate(): in-flight and queued promises are rejected with
  // MODULE_INVALIDATED, and late SDK completions become no-ops (settle-once).
  void (^work)(void) = ^{
    self->_invalidated = YES;
    [self->_queue removeAllObjects];
    for (RNSDKPendingCall *call in [self->_pending allObjects]) {
      [call rejectWithCode:@"MODULE_INVALIDATED" message:@"StroeerSDK module was invalidated"];
    }
    [self->_pending removeAllObjects];
  };
  if ([NSThread isMainThread]) {
    work();
  } else {
    dispatch_async(dispatch_get_main_queue(), work);
  }
}

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:(const facebook::react::ObjCTurboModule::InitParams &)params
{
  return std::make_shared<facebook::react::NativeStroeerSDKModuleSpecJSI>(params);
}

#pragma mark - Internals

// Registers a promise; returns nil (after rejecting) when the module is already invalidated.
- (RNSDKPendingCall *)beginCall:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNSDKPendingCall *call = [[RNSDKPendingCall alloc] initWithResolve:resolve reject:reject];
  if (_invalidated) {
    [call rejectWithCode:@"MODULE_INVALIDATED" message:@"StroeerSDK module was invalidated"];
    return nil;
  }
  [_pending addObject:call];
  return call;
}

- (void)resolveCall:(RNSDKPendingCall *)call value:(id)value
{
  [_pending removeObject:call];
  [call resolveWith:value];
}

- (void)rejectCall:(RNSDKPendingCall *)call code:(NSString *)code message:(NSString *)message
{
  [_pending removeObject:call];
  [call rejectWithCode:code message:message];
}

- (void)enqueueOperation:(RNSDKOperation)operation
{
  [_queue addObject:[operation copy]];
  [self runNextOperation];
}

- (void)runNextOperation
{
  if (_operationRunning || _queue.count == 0) {
    return;
  }
  RNSDKOperation operation = _queue.firstObject;
  [_queue removeObjectAtIndex:0];
  _operationRunning = YES;

  __block BOOL finished = NO;
  void (^done)(void) = ^{
    // Completions may arrive from a Swift task thread; always continue on the main queue.
    dispatch_async(dispatch_get_main_queue(), ^{
      if (finished) return;
      finished = YES;
      self->_operationRunning = NO;
      [self runNextOperation];
    });
  };
  operation(done);
}

// Waits for the configuration and settles `call` with the slot names, or CONFIG_NOT_LOADED.
// `done` (optional) is invoked once the wait is over.
- (void)awaitSlotNamesForCall:(RNSDKPendingCall *)call failureMessage:(NSString *)failureMessage done:(void (^)(void))done
{
  // getConfigAsync returns the loaded config immediately, otherwise triggers a load and waits
  // up to the timeout; nil means it never became available (or was reset meanwhile).
  [ConfigurationManager.shared getConfigAsyncWithTimeoutSeconds:kConfigTimeoutSeconds
                                              completionHandler:^(Configuration *configuration) {
    // The Swift async continuation gives no main-queue guarantee; hop before settling.
    dispatch_async(dispatch_get_main_queue(), ^{
      if (configuration == nil) {
        [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] %@", failureMessage]];
        [self rejectCall:call code:@"CONFIG_NOT_LOADED" message:failureMessage];
      } else {
        @try {
          [self resolveCall:call value:RNSlotNamesFromConfiguration(configuration)];
        } @catch (NSException *exception) {
          [self rejectCall:call code:@"SDK_ERROR" message:exception.reason ?: @"Failed to read slot names"];
        }
      }
      if (done) done();
    });
  }];
}

static BOOL RNIsBlank(NSString *string)
{
  return string == nil || [[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length] == 0;
}

#pragma mark - NativeStroeerSDKModuleSpec (promises)

- (void)setApplicationName:(NSString *)applicationName
                   resolve:(RCTPromiseResolveBlock)resolve
                    reject:(RCTPromiseRejectBlock)reject
{
  RNSDKPendingCall *call = [self beginCall:resolve reject:reject];
  if (!call) return;
  if (RNIsBlank(applicationName)) {
    [self rejectCall:call code:@"INVALID_ARGUMENT" message:@"applicationName must not be blank"];
    return;
  }
  // Goes through the shared chain so it cannot interleave with a resetAndLoadConfiguration.
  [self enqueueOperation:^(void (^done)(void)) {
    @try {
      // Resolves once the SDK setup has started, not once the configuration is loaded.
      [Stroeer setupWithAppName:applicationName];
      [self resolveCall:call value:nil];
    } @catch (NSException *exception) {
      [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] setApplicationName failed: %@", exception.reason]];
      [self rejectCall:call code:@"SDK_ERROR" message:exception.reason ?: @"setApplicationName failed"];
    }
    done();
  }];
}

- (void)resetAndLoadConfiguration:(NSString *)applicationName
                          resolve:(RCTPromiseResolveBlock)resolve
                           reject:(RCTPromiseRejectBlock)reject
{
  RNSDKPendingCall *call = [self beginCall:resolve reject:reject];
  if (!call) return;
  if (RNIsBlank(applicationName)) {
    [self rejectCall:call code:@"INVALID_ARGUMENT" message:@"applicationName must not be blank"];
    return;
  }
  [self enqueueOperation:^(void (^done)(void)) {
    // Mirrors Android: reset -> setApplicationName -> await the config. Unlike Android there is
    // no fixed delay: the SDK's awaitable getConfigAsync (completion-handler form in ObjC)
    // loads the new configuration and returns it, or nil on timeout / reset.
    [RNSLogger d:@"[StroeerSDK] Reloading configuration"];
    @try {
      [ConfigurationManager.shared reset];
      [Stroeer setupWithAppName:applicationName];
    } @catch (NSException *exception) {
      [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] resetAndLoadConfiguration failed: %@", exception.reason]];
      [self rejectCall:call code:@"SDK_ERROR" message:exception.reason ?: @"resetAndLoadConfiguration failed"];
      done();
      return;
    }
    [self awaitSlotNamesForCall:call
                 failureMessage:[NSString stringWithFormat:@"Configuration not loaded for: %@", applicationName]
                           done:done];
  }];
}

- (void)clearConfigurationCache:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNSDKPendingCall *call = [self beginCall:resolve reject:reject];
  if (!call) return;
  // iOS has no non-destructive refresh API: Stroeer.clearConfigurationCache is
  // ConfigurationManager.reset(), which drops the loaded and persisted config and requests no
  // reload. So a "refresh request" is reset + re-setup with the current app name, which makes
  // the SDK load a fresh configuration in the background. Queued on the shared chain so it
  // cannot interleave with setApplicationName / resetAndLoadConfiguration. Resolves once the
  // refresh has been REQUESTED (the load is not awaited). Never touches consent.
  [self enqueueOperation:^(void (^done)(void)) {
    @try {
      NSString *appName = [ConfigurationManager.shared getAppName];
      [Stroeer.instance clearConfigurationCache];
      if (appName.length > 0) {
        [Stroeer setupWithAppName:appName];
      }
      [self resolveCall:call value:nil];
    } @catch (NSException *exception) {
      [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] clearConfigurationCache failed: %@", exception.reason]];
      [self rejectCall:call code:@"SDK_ERROR" message:exception.reason ?: @"clearConfigurationCache failed"];
    }
    done();
  }];
}

- (void)getSlotNames:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNSDKPendingCall *call = [self beginCall:resolve reject:reject];
  if (!call) return;
  // Await the config rather than reading getConfig, which is only a snapshot and would be nil
  // purely because initialisation is still in flight.
  [self awaitSlotNamesForCall:call failureMessage:@"Configuration not loaded" done:nil];
}

- (void)getConfiguration:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNSDKPendingCall *call = [self beginCall:resolve reject:reject];
  if (!call) return;
  @try {
    // null (never a "not loaded" string) when no configuration is loaded.
    NSString *json = [ConfigurationManager.shared isLoaded] ? [ConfigurationManager.shared toJsonString] : nil;
    [self resolveCall:call value:json.length > 0 ? json : nil];
  } @catch (NSException *exception) {
    [self rejectCall:call code:@"SDK_ERROR" message:exception.reason ?: @"getConfiguration failed"];
  }
}

#pragma mark - NativeStroeerSDKModuleSpec (void)

// Void methods never throw into JS: SDK exceptions are caught and logged.

- (void)setContentUrl:(NSString *)url
{
  @try {
    [Stroeer setGlobalContentUrlWithUrl:url];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] setContentUrl failed: %@", exception.reason]];
  }
}

- (void)setGlobalCustomTargeting:(NSDictionary *)targeting
{
  @try {
    NSDictionary<NSString *, NSArray<NSString *> *> *map = RNTargetingMapFromDictionary(targeting);
    if (map.count == 0) {
      return;
    }
    [Stroeer setGlobalCustomTargetingWithTargeting:map];
    // Never log targeting values.
    [RNSLogger d:[NSString stringWithFormat:@"[StroeerSDK] Global custom targeting set (%lu keys)", (unsigned long)map.count]];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] setGlobalCustomTargeting failed: %@", exception.reason]];
  }
}

- (void)disableErrorLog:(BOOL)disable
{
  @try {
    // Downgrades SDK error logs to info rather than dropping them (same as Android).
    [ConfigurationManager setDisableErrorLog:disable];
    [RNSLogger d:[NSString stringWithFormat:@"[StroeerSDK] disableErrorLog set to %@", disable ? @"YES" : @"NO"]];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] disableErrorLog failed: %@", exception.reason]];
  }
}

- (void)enableTestForIOCampaigns:(BOOL)enable
{
  @try {
    // Toggles app.ext.data.keyvalues.demo = ["mobilesdktest"] in the OpenRTB JSON, like Android.
    // `OrtbJson` is the SDK's Objective-C bridge over OrtbJsonHelper.
    NSArray<NSString *> *path = @[ @"app", @"ext", @"data", @"keyvalues", @"demo" ];
    if (enable) {
      [OrtbJson addOrUpdate:@[ @"mobilesdktest" ] path:path];
    } else {
      [OrtbJson removeWithPath:path];
    }
    [OrtbJson apply];
    [RNSLogger d:[NSString stringWithFormat:@"[StroeerSDK] enableTestForIOCampaigns set to %@", enable ? @"YES" : @"NO"]];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] enableTestForIOCampaigns failed: %@", exception.reason]];
  }
}

- (void)forcePrebidRendering:(BOOL)enable
{
  @try {
    [ConfigurationManager setForcePrebidRendering:enable];
    [RNSLogger d:[NSString stringWithFormat:@"[StroeerSDK] forcePrebidRendering set to %@", enable ? @"YES" : @"NO"]];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] forcePrebidRendering failed: %@", exception.reason]];
  }
}

- (void)enableDebugMode
{
  @try {
    [Stroeer enableDebugMode];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] enableDebugMode failed: %@", exception.reason]];
  }
}

- (void)enableInspectionMode
{
  @try {
    [Stroeer enableInspectionMode];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerSDK] enableInspectionMode failed: %@", exception.reason]];
  }
}

@end
