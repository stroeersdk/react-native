#import <React/RCTBridgeModule.h>
#import <ReactCommon/RCTTurboModule.h>
#import <RNStroeerSpec/RNStroeerSpec.h>

#import <WebKit/WebKit.h>
#import <StroeerSDK/StroeerSDK-Swift.h>

#import "SLogger+RN.h"

/**
 * Identity TurboModule. setCustomInfo hands the SDK a FRESH IdentityCustomInfo on every call:
 * omitted fields are nil and nothing is merged with a previous call.
 *
 * SDK limitation: the ID5 provider only ever SETS the non-nil fields on its request builder
 * (ID5Manager.setCustomInfo) and never clears them, so a field omitted in a later call keeps the
 * previously applied value, and applied identity data cannot be removed until the SDK offers a
 * reset API. The same limitation exists on Android.
 *
 * Identity values are personal data: they are never logged.
 */
@interface RNStroeerIdentity : NativeStroeerIdentityModuleSpecBase <NativeStroeerIdentityModuleSpec>
@end

@implementation RNStroeerIdentity

RCT_EXPORT_MODULE(StroeerIdentityModule)

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

// IdentityManager stores the object without a lock; keep every access on one queue.
- (dispatch_queue_t)methodQueue
{
  return dispatch_get_main_queue();
}

- (void)setCustomInfo:(JS::NativeStroeerIdentityModule::NativeIdentityCustomInfo &)info
{
  @try {
    IdentityCustomInfo *customInfo = [[IdentityCustomInfo alloc] init];
    customInfo.email = info.email();
    customInfo.phone = info.phone();
    customInfo.puid = info.puid();
    customInfo.regionCode = info.regionCode();
    customInfo.cityCode = info.cityCode();
    [[IdentityManager shared] setCustomInfo:customInfo];
  } @catch (NSException *exception) {
    [RNSLogger e:[NSString stringWithFormat:@"[StroeerIdentity] Error setting custom info: %@", exception.reason]];
  }
}

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:(const facebook::react::ObjCTurboModule::InitParams &)params
{
  return std::make_shared<facebook::react::NativeStroeerIdentityModuleSpecJSI>(params);
}

@end
