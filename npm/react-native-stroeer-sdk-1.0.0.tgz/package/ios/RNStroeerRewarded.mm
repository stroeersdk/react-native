#import <React/RCTBridgeModule.h>
#import <React/RCTUtils.h>
#import <ReactCommon/RCTTurboModule.h>
#import <RNStroeerSpec/RNStroeerSpec.h>

#import "RNFullscreenAdController.h"
#import "RNFullscreenSdkAdapter.h"
#import "SLogger+RN.h"

@interface RNStroeerRewarded : NativeStroeerRewardedModuleSpecBase <NativeStroeerRewardedModuleSpec, RNFullscreenAdEvents>
@end

@implementation RNStroeerRewarded {
  RNFullscreenAdController *_controller;
}

RCT_EXPORT_MODULE(StroeerRewarded)

+ (BOOL)requiresMainQueueSetup
{
  return YES;
}

- (dispatch_queue_t)methodQueue
{
  return dispatch_get_main_queue();
}

- (instancetype)init
{
  if ((self = [super init])) {
    _controller = [[RNFullscreenAdController alloc] initWithLogTag:@"[StroeerRewarded]"
                                                    adapterFactory:^id<RNFullscreenSdkAdapter> {
                                                      return [RNRewardedSdkAdapter new];
                                                    }
                                                            events:self];
  }
  return self;
}

- (void)invalidate
{
  [_controller invalidate];
}

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:(const facebook::react::ObjCTurboModule::InitParams &)params
{
  return std::make_shared<facebook::react::NativeStroeerRewardedModuleSpecJSI>(params);
}

#pragma mark - NativeStroeerRewardedModuleSpec

- (void)createAd:(NSString *)publisherSlotName resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  [_controller createWithSlot:publisherSlotName resolve:resolve reject:reject];
}

- (void)load:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  [_controller load:adId resolve:resolve reject:reject];
}

- (void)show:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  [_controller show:adId resolve:resolve reject:reject];
}

- (void)isReady:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  resolve(@([_controller isReady:adId]));
}

- (void)destroy:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  [_controller destroy:adId resolve:resolve reject:reject];
}

#pragma mark - RNFullscreenAdEvents

// A missing emitter callback (JS not attached yet / module torn down) must not crash.
- (BOOL)canEmit:(NSString *)name
{
  if (_eventEmitterCallback) return YES;
  [RNSLogger e:[NSString stringWithFormat:@"[StroeerRewarded] No event emitter attached; dropping %@", name]];
  return NO;
}

- (void)onAdLoaded:(NSString *)adId
{
  if ([self canEmit:@"onAdLoaded"]) [self emitOnAdLoaded:@{@"adId" : adId}];
}

- (void)onAdShowed:(NSString *)adId
{
  if ([self canEmit:@"onAdShowed"]) [self emitOnAdShowed:@{@"adId" : adId}];
}

- (void)onAdDismissed:(NSString *)adId
{
  if ([self canEmit:@"onAdDismissed"]) [self emitOnAdDismissed:@{@"adId" : adId}];
}

- (void)onAdClicked:(NSString *)adId
{
  if ([self canEmit:@"onAdClicked"]) [self emitOnAdClicked:@{@"adId" : adId}];
}

- (void)onAdImpression:(NSString *)adId
{
  if ([self canEmit:@"onAdImpression"]) [self emitOnAdImpression:@{@"adId" : adId}];
}

- (void)onAdFailedToLoad:(NSString *)adId code:(NSString *)code message:(NSString *)message
{
  if ([self canEmit:@"onAdFailedToLoad"]) {
    [self emitOnAdFailedToLoad:@{@"adId" : adId, @"error" : @{@"code" : code, @"message" : message}}];
  }
}

- (void)onAdFailedToShow:(NSString *)adId code:(NSString *)code message:(NSString *)message
{
  if ([self canEmit:@"onAdFailedToShow"]) {
    [self emitOnAdFailedToShow:@{@"adId" : adId, @"error" : @{@"code" : code, @"message" : message}}];
  }
}

- (void)onUserEarnedReward:(NSString *)adId type:(NSString *)type amount:(double)amount
{
  if ([self canEmit:@"onUserEarnedReward"]) {
    [self emitOnUserEarnedReward:@{@"adId" : adId, @"reward" : @{@"type" : type, @"amount" : @(amount)}}];
  }
}

@end
