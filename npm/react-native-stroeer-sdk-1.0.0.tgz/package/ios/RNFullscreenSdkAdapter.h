#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Normalized SDK callbacks of one full screen ad instance. The blocks are invoked on the main
/// thread. `onUserEarnedReward` is only used by rewarded ads.
@interface RNFullscreenSdkCallbacks : NSObject
@property (nonatomic, copy, nullable) void (^onLoaded)(void);
@property (nonatomic, copy, nullable) void (^onFailedToLoad)(NSString *_Nullable message);
@property (nonatomic, copy, nullable) void (^onShowed)(void);
@property (nonatomic, copy, nullable) void (^onFailedToShow)(NSString *_Nullable message);
@property (nonatomic, copy, nullable) void (^onDismissed)(void);
@property (nonatomic, copy, nullable) void (^onClicked)(void);
@property (nonatomic, copy, nullable) void (^onImpression)(void);
@property (nonatomic, copy, nullable) void (^onUserEarnedReward)(NSString *_Nullable type, NSNumber *_Nullable amount);
@end

/// Owns exactly one SDK ad instance (never reused) and is its strong delegate: the SDK only
/// holds its publisher delegate weakly.
@protocol RNFullscreenSdkAdapter <NSObject>
- (void)loadWithSlot:(NSString *)slot callbacks:(RNFullscreenSdkCallbacks *)callbacks;
- (void)showWithViewController:(UIViewController *)viewController;
/// Drops the SDK instance and silences every later callback. Idempotent.
- (void)destroy;
@end

typedef id<RNFullscreenSdkAdapter> _Nonnull (^RNFullscreenSdkAdapterFactory)(void);

@interface RNInterstitialSdkAdapter : NSObject <RNFullscreenSdkAdapter>
@end

@interface RNRewardedSdkAdapter : NSObject <RNFullscreenSdkAdapter>
@end

NS_ASSUME_NONNULL_END
