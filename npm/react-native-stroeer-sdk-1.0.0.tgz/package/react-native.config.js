module.exports = {
  dependency: {
    platforms: {
      android: {
        packageImportPath: 'import com.stroeer.rn.StroeerPackage;',
        packageInstance: 'new StroeerPackage()',
      },
    },
  },
};
