[Integration Guide](https://github.com/stroeersdk/react-native/blob/main/docs/1.0/Integration.md) (public)

[Public Repository](https://github.com/stroeersdk/react-native) (published packages, docs, example apps)

# Ströer SDK for React Native

**Version:** 1.0.0 | **React Native:** 0.82.1 (New Architecture) | **Min SDK:** 24 | **Target SDK:** 36 | **iOS:** 15.1 | **Java:** 17

React Native bridge (npm package `react-native-stroeer-sdk`) for the Ströer advertising SDK. Supports
banner, interstitial and rewarded ads on Android and iOS, plus Confiant ad-quality monitoring and
identity data.

## Modules

| JS API | Android (`com.stroeer.rn`) | iOS | Description |
|---|---|---|---|
| `StroeerSDK` | `StroeerModule` | `RNStroeerSDK` | Setup, configuration, targeting, debugging |
| `StroeerBannerAd` | `StroeerBannerViewManager` | `RNStroeerBannerComponentView` | Banner Fabric component |
| `StroeerInterstitial`, `useStroeerInterstitial`, `StroeerInterstitialAd` | `StroeerInterstitialModule` | `RNStroeerInterstitial` | Interstitial ad handles, hook and headless component |
| `StroeerRewarded`, `useStroeerRewarded`, `StroeerRewardedAd` | `StroeerRewardedModule` | `RNStroeerRewarded` | Rewarded ad handles, hook and headless component |
| `StroeerConfiant` | `StroeerConfiantModule` | `RNStroeerConfiant` | Confiant ad-quality monitoring |
| `StroeerIdentity` | `StroeerIdentityModule` | `RNStroeerIdentity` | Identity data (ID5) |
| `StroeerConsentModule` | disabled | — | CMP wrapper; not available yet |

Every module is a codegen TurboModule (specs in `src/specs/`); the banner is a Fabric component.
Interstitial and rewarded share `FullscreenAdController` / `RNFullscreenAdController` on the native
side and `src/fullscreen/` in JS.

Native SDKs:

| Platform | Dependency | Source |
|---|---|---|
| Android | `com.stroeer.ads:core:1.0.0-rc3` | `https://stroeersdk.github.io/android/maven` |
| iOS | `StroeerSDK` pod `1.0.0-rc.3` | `https://stroeersdk.github.io/iOS/CocoaPods/StroeerSDK.podspec` |

## Build Commands

```bash
yarn                          # Install dependencies (Yarn 4 via Corepack)
yarn prepare                  # Build lib/ (commonjs, module, typescript) with react-native-builder-bob
yarn test                     # Jest unit tests
yarn typecheck                # TypeScript type checking
yarn lint                     # ESLint
yarn clean                    # Delete build output (android, ios, lib, example builds)

yarn example start            # Start Metro for the example app
yarn example android          # Run the example app on Android
yarn example ios              # Run the example app on iOS

cd example/android && ./gradlew :react-native-stroeer-sdk:test   # Android unit tests
cd example/android && ./gradlew :app:assembleRelease             # Release APK of the example app
```

`android/` has no `settings.gradle`, so the library's Android code is built and tested through the
example app's Gradle build.

The build number is read from `build_number.txt`; the version from `package.json`. The version in
the repo stays `0.0.0`: the release workflow writes the release version into `package.json` for
the build only.

## Project Structure

| Path | Contents |
|---|---|
| `src/` | TypeScript API; codegen specs in `src/specs/` |
| `android/` | Kotlin bridge (`com.stroeer.rn`) and its Robolectric unit tests |
| `ios/` | Objective-C++ bridge (`RNStroeer*`) |
| `example/` | Example app (yarn workspace `react-native-stroeer-sdk-example`) |
| `lib/` | Build output of `yarn prepare` (not in git) |

# Example App

The example app tests banner, interstitial and rewarded ad units with production configuration,
so a physical device shows real ads.

Application name, slot names and debug options can be changed on the Configuration page and are
stored with Save. Slot names apply the next time an ad screen loads; the application name is read
at app start, so restart the app after changing it. Application logs can be seen on the Logs page.

The main screen also writes fake IAB TCF consent for testing ("Fake Consent"). "Clear Consent"
needs the CMP module, which is not available yet.

# GitHub Actions Workflows

Workflows live in `.github/workflows/`. Runners use `ubuntu-latest` and the latest Node LTS.

## 1. Build & Release

- **Filename**: `.github/workflows/Build_Release.yml`
- **Triggers**: `push` to `master`, `workflow_dispatch`

### Purpose
Orchestrates the reusable workflows in sequence:
- **bump** – increment and commit the build number (`Build_Prepare.yml`)
- **tests** – type check, lint, Jest and Android unit tests (`Build_Test_Lint.yml`)
- **package** – build and pack the npm tarball (`Build_Package.yml`), only if tests pass

No git tags or GitHub Releases are created.

- `nobuild` in the commit message skips the whole pipeline (the bump commit uses it).
- `skiptests` in the commit message, or the `skip_tests` input of a manual run, skips the tests.

## 2. Tests & Lint

- **Filename**: `.github/workflows/Build_Test_Lint.yml`
- **Triggers**: `workflow_dispatch`, `workflow_call`

### Purpose
Runs `yarn typecheck`, `yarn lint`, `yarn prepare` and `yarn test`, and in a separate job the
Android unit tests (`:react-native-stroeer-sdk:testDebugUnitTest`). Android test reports are kept
for 3 days.

## 3. Prepare

- **Filename**: `.github/workflows/Build_Prepare.yml`
- **Triggers**: `workflow_dispatch`, `workflow_call`

### Purpose
Reads and increments `build_number.txt`, commits it back with a `nobuild:` message and outputs the
new number.

## 4. Package

- **Filename**: `.github/workflows/Build_Package.yml`
- **Triggers**: `workflow_dispatch`, `workflow_call`

### Purpose
Builds the package and uploads `react-native-stroeer-sdk-<version>-<buildNum>.tgz` as a workflow
artifact (60 days). Takes an optional `build_number` input (defaults to `build_number.txt`). Does
not bump the build number, tag or release.

## 5. Release (public repo)

- **Filename**: `.github/workflows/Release_Public.yml`
- **Triggers**: `workflow_dispatch`, `workflow_call`

### Purpose
Builds and packs the SDK with the release version and pushes
`npm/react-native-stroeer-sdk-<version>.tgz` into https://github.com/stroeersdk/react-native.
Consumers install it from GitHub Pages:

```bash
npm install https://stroeersdk.github.io/react-native/npm/react-native-stroeer-sdk-<version>.tgz
```

### Inputs
- `version`: release version, e.g. `1.0.0` (defaults to `package.json`; `0.0.0` is rejected).
- `rc`: release candidate number; publishes `<version>-rc<n>`.

Published versions are immutable: the run fails if the target already holds the version. No tags
or GitHub Releases are created; the commit message records the version and the build number.

### Requirements
- `RELEASE_DEPLOY_TOKEN` — a personal access token with Contents read and write access to
  `stroeersdk/react-native`. It is only passed to the final `git push`.

### Usage
```yaml
jobs:
  release:
    uses: ./.github/workflows/Release_Public.yml
    with:
      version: 1.0.0
    secrets: inherit
```

## 6. Build APK

- **Filename**: `.github/workflows/Build_APK.yml`
- **Trigger**: `workflow_dispatch`

### Purpose
Builds the release APK of the example app (`StroeerRNTestApp-<version>.<buildNum>.apk`, signed
with the example's debug keystore) and uploads it as a workflow artifact (7 days). An optional
`version` input sets the version in the APK name.

# Change log
### [1.0.0] (07.Oct.2026)

#### New
- Rebranded the SDK as StröerSDK.
- Changed the package name to `com.stroeer.ads`. (Android)
- Updated the library repository: GitHub – StröerSDK Android. (Android)
- Added a Jetpack Compose wrapper (`com.stroeer.compose`). (Android)
- Configuration is now revalidated using an ETag instead of being re-downloaded on every refresh. (Android)
- The React Native bridge is now built for the New Architecture only (React Native 0.82): every module is a codegen TurboModule and the banner is a Fabric component.
- Interstitial and rewarded ads are now ad handles (`create` → `load` → `show` → `destroy`). Several ads can be loaded at the same time, and hooks and components each own their ad, so they no longer replace each other's listeners.
- Every banner, interstitial and rewarded event is logged by the native SDK. (Android)

#### Fixed
- Corrected the precedence of key-values and `contentUrl` for GAM. Key-values from remote configuration are now also included in Prebid requests. (Android)
- Ad size is now rechecked at impression time, as the size of some banners is determined only when the impression occurs. (Android)
- The SDK no longer adds an app-name label to the merged manifest. (Android)
- Banner: `onAdLoaded` is no longer lost when an impression follows immediately, and every load failure is now reported to `onAdFailedToLoad`.
- Interstitial and rewarded ads no longer show automatically after loading, and `show()` now resolves once the ad is actually presented.
- Rewarded: loading again after a failed load works, and a reward that arrives after the ad is dismissed is still delivered.
- `clearConfigurationCache()` no longer clears the app's default shared preferences (including consent); it now only requests a fresh configuration.
- User and context targeting is now sent to Prebid in the correct place; GAM receives the same key-values as before.
- Release JS bundling of the example app works again in the monorepo.
- Fixed various minor bugs.

#### Changed
- The SDK version reported to GAM and Prebid now follows the new versioning scheme (major + 20). (Android)
- Removed the OkHttp dependency. (Android)
- SDK libraries are now obfuscated. (Android)
- Updated third-party library versions (Android):
  - Prebid Mobile: 3.3.4
  - SourcePoint: 7.15.13
  - Google Mobile Ads SDK: 24.6.0 (publishers can upgrade to a later version)
  - Kotlin: 2.1.0 (publishers can upgrade to a later version)
- The iOS native SDK is now the `StroeerSDK` pod (1.0.0-rc.3), which replaces `YieldloveAdIntegration`. It is installed from `https://stroeersdk.github.io/iOS/CocoaPods/StroeerSDK.podspec` with the subspecs `Core` (default) and `Consent`. (iOS)
- Updated third-party library versions (iOS):
  - Prebid Mobile: 3.4.1
  - Google Mobile Ads SDK: 13.7.0
  - ConsentViewController (SourcePoint): ~> 7.12
- Errors are now reported as `{ code, message }`. A missing native module is reported with the code `MODULE_UNAVAILABLE`.
- Jetifier is no longer required. (Android)

#### Breaking changes (React Native API)
- **Banner (`StroeerBannerAd`)**: loading is driven by props. It reloads when `publisherSlotName`, `contentUrl` or `customTargeting` change in value; change the React `key` to force a reload. `onAdFailedToLoad` receives `{ code, message }`. The `destroyWhenDetached` prop is removed.
- **Interstitial and rewarded**: use `const ad = await StroeerInterstitial.create(slot)` (or `StroeerRewarded.create(slot)`), then `ad.subscribe(...)`, `ad.load()`, `ad.show()` and `ad.destroy()`. `setLoadAfterReady`, `setListeners` and `removeAllListeners` are removed. `useStroeerInterstitial` / `useStroeerRewarded` and the `StroeerInterstitialAd` / `StroeerRewardedAd` components (controlled through a ref) are kept on the new API.
- **StroeerSDK**:
  - `setUserTargeting`, `setContextTargeting`, `setContextDataTargeting` and `setCustomTargeting` are replaced by `setGlobalCustomTargeting({ user: [...], context: [...], <key>: [...] })`.
  - `reloadConfigurationAndGetSlotNames` is renamed to `resetAndLoadConfiguration`.
  - `setApplicationName` and `clearConfigurationCache` return Promises.
  - `getSlotNames` rejects with `CONFIG_NOT_LOADED` instead of resolving `null`, and `getConfiguration` resolves `null` when no configuration is loaded.
- **StroeerIdentity**: `setEmail`, `setPhone`, `setPuid`, `setRegionCode`, `setCityCode` and `apply` are replaced by `setCustomInfo({ email, phone, puid, regionCode, cityCode })`.
- **StroeerConfiant**: `initialize` resolves only once; a second call while it is running rejects with `ALREADY_INITIALIZING`.
- **IabTestConsent** is removed from the library; it is test tooling and now lives in the example app.
