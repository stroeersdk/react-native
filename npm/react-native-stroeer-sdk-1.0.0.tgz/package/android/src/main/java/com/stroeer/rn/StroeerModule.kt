package com.stroeer.rn

import android.content.Context
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.ReadableType
import com.facebook.react.bridge.UiThreadUtil
import com.facebook.react.bridge.WritableArray
import com.facebook.react.bridge.WritableMap
import com.stroeer.ads.StroeerSDK
import com.stroeer.ads.config.ConfigurationManager
import com.stroeer.ads.utilities.json.OrtbJsonHelper
import com.stroeer.ads.utilities.logging.Logger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import java.util.concurrent.atomic.AtomicBoolean

/** Banner and interstitial slot names of the loaded configuration. */
internal data class SlotNameLists(val banners: List<String>, val interstitials: List<String>)

/**
 * The part of the SDK this module talks to. The SDK's setup touches Prebid, WebView and
 * unsynchronized configuration flags, so every call is made on the main thread by the module.
 */
internal interface SdkFacade {
    fun setApplicationName(applicationName: String)
    fun resetConfiguration()
    /** Waits for the configuration (bounded by the SDK's own timeout); null when it is not loaded. */
    suspend fun awaitSlotNames(): SlotNameLists?
    /** The pretty JSON of the loaded configuration, null when it is not loaded. */
    fun configurationJson(): String?
    fun clearConfigurationCache()
    fun setContentUrl(url: String)
    fun setGlobalCustomTargeting(targeting: Map<String, List<String>>)
    fun disableErrorLog(disable: Boolean)
    fun enableTestForIOCampaigns(enable: Boolean)
    fun forcePrebidRendering(enable: Boolean)
    fun enableDebugMode()
    fun enableInspectionMode()
}

internal class DefaultSdkFacade(private val context: Context) : SdkFacade {
    override fun setApplicationName(applicationName: String) =
        StroeerSDK.setApplicationName(context, applicationName)

    override fun resetConfiguration() = ConfigurationManager.getInstance().reset()

    override suspend fun awaitSlotNames(): SlotNameLists? =
        ConfigurationManager.getInstance().getConfigAsync()?.let {
            SlotNameLists(it.getBannerNames(), it.getInterstitialNames())
        }

    // toString() answers the literal "Configuration not loaded" when nothing is loaded.
    override fun configurationJson(): String? =
        ConfigurationManager.getInstance().let { if (it.isLoaded) it.toString() else null }

    override fun clearConfigurationCache() = StroeerSDK.clearConfigurationCache()
    override fun setContentUrl(url: String) = StroeerSDK.setContentUrl(url)
    override fun setGlobalCustomTargeting(targeting: Map<String, List<String>>) =
        StroeerSDK.setGlobalCustomTargeting(targeting)

    override fun disableErrorLog(disable: Boolean) {
        ConfigurationManager.disableErrorLog = disable
    }

    override fun enableTestForIOCampaigns(enable: Boolean) {
        if (enable) {
            OrtbJsonHelper.addOrUpdate(JSONArray().put("mobilesdktest"), "app", "ext", "data", "keyvalues", "demo")
        } else {
            OrtbJsonHelper.remove("app", "ext", "data", "keyvalues", "demo")
        }
        OrtbJsonHelper.apply()
    }

    override fun forcePrebidRendering(enable: Boolean) {
        ConfigurationManager.forcePrebidRendering = enable
    }

    override fun enableDebugMode() = StroeerSDK.enableDebugMode()
    override fun enableInspectionMode() = StroeerSDK.enableInspectionMode()
}

/**
 * Core SDK TurboModule. All SDK-facing work runs on the main thread. Void methods never throw:
 * SDK failures are logged (never with targeting values). Promise methods settle exactly once;
 * invalidating the module cancels in-flight work and rejects pending promises with
 * MODULE_INVALIDATED.
 */
class StroeerModule internal constructor(
    reactContext: ReactApplicationContext,
    private val sdk: SdkFacade,
    private val scope: CoroutineScope,
    private val runOnMainThread: (() -> Unit) -> Unit,
    private val mapFactory: () -> WritableMap,
    private val arrayFactory: () -> WritableArray
) : NativeStroeerSDKModuleSpec(reactContext) {

    constructor(reactContext: ReactApplicationContext) : this(
        reactContext,
        sdk = DefaultSdkFacade(reactContext),
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate),
        runOnMainThread = { task -> if (UiThreadUtil.isOnUiThread()) task() else UiThreadUtil.runOnUiThread(task) },
        mapFactory = { Arguments.createMap() },
        arrayFactory = { Arguments.createArray() }
    )

    companion object {
        const val NAME = NativeStroeerSDKModuleSpec.NAME
        const val INVALID_ARGUMENT = "INVALID_ARGUMENT"
        const val SDK_ERROR = "SDK_ERROR"
        const val CONFIG_NOT_LOADED = "CONFIG_NOT_LOADED"
        const val MODULE_INVALIDATED = "MODULE_INVALIDATED"
        private const val TAG = "[StroeerModule]"

        /**
         * Keeps entries whose key is non-empty and whose value is an array; non-string items are
         * dropped. Never logs keys' values.
         */
        internal fun toTargeting(map: ReadableMap?): Map<String, List<String>> {
            val result = LinkedHashMap<String, List<String>>()
            if (map == null) return result
            var skipped = 0
            val keys = map.keySetIterator()
            while (keys.hasNextKey()) {
                val key = keys.nextKey()
                if (key.isEmpty() || map.getType(key) != ReadableType.Array) {
                    skipped++
                    continue
                }
                val array = map.getArray(key)
                if (array == null) {
                    skipped++
                    continue
                }
                val values = ArrayList<String>(array.size())
                for (i in 0 until array.size()) {
                    if (array.getType(i) == ReadableType.String) {
                        array.getString(i)?.let { values.add(it) }
                    } else {
                        skipped++
                    }
                }
                result[key] = values
            }
            if (skipped > 0) Logger.e("$TAG Skipped $skipped invalid targeting entries")
            return result
        }
    }

    // Serializes every call that changes the application name or resets the configuration
    // (setApplicationName, resetAndLoadConfiguration), so a reset's await sees its own name.
    // getSlotNames and clearConfigurationCache stay outside: they only read or request a refresh
    // and do not change which application the configuration belongs to.
    private val configMutex = Mutex()
    @Volatile private var invalidated = false

    // --- Promise methods ---

    override fun setApplicationName(applicationName: String, promise: Promise) {
        launchPromise(promise) {
            requireNotBlank(applicationName)
            // Same mutex as resetAndLoadConfiguration: it must not interleave with a reset/load.
            configMutex.withLock { sdkCall("set the application name") { sdk.setApplicationName(applicationName) } }
            null
        }
    }

    override fun resetAndLoadConfiguration(applicationName: String, promise: Promise) {
        launchPromise(promise) {
            requireNotBlank(applicationName)
            val names = configMutex.withLock {
                sdkCall("reset the configuration") { sdk.resetConfiguration() }
                sdkCall("set the application name") { sdk.setApplicationName(applicationName) }
                sdkAwait("load the configuration")
            }
            slotNamesMap(names)
        }
    }

    override fun clearConfigurationCache(promise: Promise) {
        launchPromise(promise) {
            sdkCall("clear the configuration cache") { sdk.clearConfigurationCache() }
            null
        }
    }

    override fun getSlotNames(promise: Promise) {
        launchPromise(promise) { slotNamesMap(sdkAwait("get the slot names")) }
    }

    override fun getConfiguration(promise: Promise) {
        launchPromise(promise) { sdkCall("read the configuration") { sdk.configurationJson() } }
    }

    // --- Void methods ---

    override fun setContentUrl(url: String) = fireAndForget("setContentUrl") { sdk.setContentUrl(url) }

    override fun setGlobalCustomTargeting(targeting: ReadableMap) = fireAndForget("setGlobalCustomTargeting") {
        sdk.setGlobalCustomTargeting(toTargeting(targeting))
    }

    override fun disableErrorLog(disable: Boolean) = fireAndForget("disableErrorLog") { sdk.disableErrorLog(disable) }

    override fun enableTestForIOCampaigns(enable: Boolean) =
        fireAndForget("enableTestForIOCampaigns") { sdk.enableTestForIOCampaigns(enable) }

    override fun forcePrebidRendering(enable: Boolean) =
        fireAndForget("forcePrebidRendering") { sdk.forcePrebidRendering(enable) }

    override fun enableDebugMode() = fireAndForget("enableDebugMode") { sdk.enableDebugMode() }

    override fun enableInspectionMode() = fireAndForget("enableInspectionMode") { sdk.enableInspectionMode() }

    override fun invalidate() {
        invalidated = true
        scope.cancel()
        super.invalidate()
    }

    // --- Helpers ---

    /** Error with a code, rejected as is. */
    private class CodedException(val code: String, message: String, cause: Throwable? = null) :
        Exception(message, cause)

    private fun requireNotBlank(applicationName: String) {
        if (applicationName.isBlank()) throw CodedException(INVALID_ARGUMENT, "applicationName is blank")
    }

    private inline fun <T> sdkCall(what: String, block: () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Logger.e("$TAG Failed to $what: ${e.message}")
            throw CodedException(SDK_ERROR, e.message ?: "Failed to $what", e)
        }

    private suspend fun sdkAwait(what: String): SlotNameLists =
        sdkCall(what) { sdk.awaitSlotNames() } ?: throw CodedException(CONFIG_NOT_LOADED, "Configuration not loaded")

    private fun slotNamesMap(names: SlotNameLists): WritableMap {
        val result = mapFactory()
        result.putArray("bannerSlots", arrayFactory().also { array -> names.banners.forEach { array.pushString(it) } })
        result.putArray(
            "interstitialSlots",
            arrayFactory().also { array -> names.interstitials.forEach { array.pushString(it) } }
        )
        return result
    }

    private fun fireAndForget(name: String, task: () -> Unit) {
        runOnMainThread {
            if (invalidated) return@runOnMainThread
            try {
                task()
            } catch (e: Exception) {
                Logger.e("$TAG $name failed: ${e.message}")
            }
        }
    }

    /** Runs [block] on the main thread; settles [promise] exactly once with its result or error. */
    private fun launchPromise(promise: Promise, block: suspend () -> Any?) {
        val settled = AtomicBoolean(false)
        fun settle(action: () -> Unit) {
            if (settled.compareAndSet(false, true)) action()
        }
        runOnMainThread {
            if (invalidated) {
                settle { promise.reject(MODULE_INVALIDATED, "The StroeerSDK module was invalidated") }
                return@runOnMainThread
            }
            scope.launch {
                try {
                    val value = block()
                    // invalidate() may have run after block() returned.
                    if (invalidated || !isActive) throw CancellationException("invalidated")
                    settle { promise.resolve(value) }
                } catch (e: CancellationException) {
                    settle { promise.reject(MODULE_INVALIDATED, "The StroeerSDK module was invalidated") }
                    throw e
                } catch (e: CodedException) {
                    settle {
                        val cause = e.cause
                        if (cause == null) promise.reject(e.code, e.message) else promise.reject(e.code, e.message, cause)
                    }
                } catch (e: Exception) {
                    Logger.e("$TAG Unexpected error: ${e.message}")
                    settle { promise.reject(SDK_ERROR, e.message ?: "Unexpected error", e) }
                }
            }
        }
    }
}
