package com.stroeer.rn

import android.app.Activity
import android.content.Context
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import com.facebook.react.bridge.Dynamic
import com.facebook.react.bridge.LifecycleEventListener
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.ReadableType
import com.stroeer.ads.utilities.logging.Logger
import java.lang.ref.WeakReference
import kotlin.math.roundToInt

/**
 * Converts the codegen `customTargeting` value into a plain map right away: the Dynamic must not
 * be retained beyond the prop update. Returns null when the value is invalid (not a map of
 * strings), which makes the banner config invalid. A missing value (null) means no targeting.
 */
internal fun parseCustomTargeting(value: Dynamic?): Map<String, String>? {
    if (value == null) return emptyMap()
    return when (value.type) {
        ReadableType.Null -> emptyMap()
        ReadableType.Map -> {
            val map = value.asMap() ?: return emptyMap()
            val result = LinkedHashMap<String, String>()
            for (entry in map.entryIterator) {
                val entryValue = entry.value as? String ?: return null
                result[entry.key] = entryValue
            }
            result
        }
        else -> null
    }
}

/**
 * Host view of a banner ad. Props arrive through [setSlotName] / [setContentUrl] /
 * [setCustomTargeting] and are applied together by [commitConfig] once per Fabric transaction.
 *
 * A load starts when the committed config differs from the one already attempted, the view is
 * attached and a running Activity is available. A new load replaces the SDK banner (the SDK view is
 * dead after destroy). Every SDK banner belongs to a generation; the generation is bumped BEFORE the
 * old banner is destroyed, so any late callback of an older banner is ignored.
 *
 * A missing Activity is a recoverable wait, not a failure: nothing is emitted and the config stays
 * unattempted until a retry trigger (attachment, [commitConfig], or host resume) finds a running
 * Activity. A config counts as attempted only right before the SDK load call, or when it was
 * rejected for good (invalid configuration, setup failure); an attempted config is never reloaded
 * by a trigger. If the Activity disappears while the load is posted, the prepared banner is
 * discarded and the config is reconciled again.
 *
 * The load itself runs from a single posted runnable once the container is attached and has been
 * laid out (container layout is a prerequisite; it does not guarantee Active View viewability).
 * Detaching cancels the runnable but keeps the prepared banner; reattaching, a layout pass, a
 * commit or a host resume schedules it again.
 *
 * Detaching neither destroys nor reloads: the banner survives detach/reattach and is only
 * destroyed on replacement or [dispose]. All state and SDK calls are on the main thread.
 */
class StroeerBannerContainer internal constructor(
    context: Context,
    private val activityProvider: () -> Activity?,
    private val eventSink: (viewId: Int, payload: BannerEventPayload) -> Unit,
    private val adapterFactory: BannerSdkAdapterFactory
) : FrameLayout(context) {

    private data class Config(
        val slotName: String,
        val contentUrl: String,
        val customTargeting: Map<String, String>,
        val valid: Boolean
    )

    // Pending props, applied by commitConfig().
    private var pendingSlotName: String = ""
    private var pendingContentUrl: String = ""
    private var pendingTargeting: Map<String, String>? = emptyMap()

    private var committedConfig: Config? = null

    // The config a load was last attempted for (successful or not): never retried by itself.
    // Set immediately before the SDK load call, or when the config is rejected terminally.
    private var attemptedConfig: Config? = null

    // A banner created for a config whose load has not run yet. While it exists, reconcile() must
    // not create a second banner. It survives detachment; only the scheduled runnable is cancelled.
    // At most one runnable is scheduled at a time.
    private class PendingLoad(
        val config: Config,
        val generation: Int,
        val adapter: BannerSdkAdapter,
        val callbacks: BannerSdkCallbacks,
        val activity: WeakReference<Activity>
    ) {
        var scheduled: Runnable? = null
    }

    private var pendingLoad: PendingLoad? = null

    private var generation = 0
    private var adapter: BannerSdkAdapter? = null

    // Strong reference: the SDK holds its listener only weakly.
    private var callbacks: BannerSdkCallbacks? = null
    private var disposed = false

    // Retries a wait for an Activity when the host resumes. Never reloads an attempted config.
    private val lifecycleListener = object : LifecycleEventListener {
        override fun onHostResume() {
            if (!disposed) reconcile()
        }

        override fun onHostPause() {}

        override fun onHostDestroy() {}
    }

    init {
        (context as? ReactContext)?.addLifecycleEventListener(lifecycleListener)
    }

    fun setSlotName(value: String?) {
        pendingSlotName = value ?: ""
    }

    fun setContentUrl(value: String?) {
        pendingContentUrl = value ?: ""
    }

    /** null marks the targeting as invalid. */
    fun setCustomTargeting(value: Map<String, String>?) {
        pendingTargeting = value
    }

    fun commitConfig() {
        if (disposed) return

        val targeting = pendingTargeting
        val config = Config(
            slotName = pendingSlotName,
            contentUrl = pendingContentUrl,
            customTargeting = targeting ?: emptyMap(),
            valid = targeting != null && pendingSlotName.isNotEmpty()
        )
        if (config == committedConfig) {
            // Nothing new to load, but an earlier wait for an Activity may be resolvable now.
            reconcile()
            return
        }

        committedConfig = config

        // Obsolete work is invalidated immediately, attached or not: a pending posted load and the
        // callbacks of the old banner must not stay valid. Only creating and loading the
        // replacement waits for attachment (see reconcile()).
        invalidateCurrentBanner()
        attemptedConfig = null
        reconcile()
    }

    private fun invalidateCurrentBanner() {
        // Bump the generation before destroying the old banner so its late callbacks are ignored.
        generation++
        cancelScheduledLoad()
        pendingLoad = null
        destroyCurrentAdapter()
        removeAllViews()
        callbacks = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // Layout requests were skipped while detached; rerun them for the current creative.
        adapter?.let { relayoutBanner(it, generation) }
        reconcile()
        schedulePendingLoad()
    }

    override fun onDetachedFromWindow() {
        // Cancel the scheduled load but keep the pending state: reattaching schedules it again.
        cancelScheduledLoad()
        super.onDetachedFromWindow()
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        // The load waits for the first container layout; the check runs after this pass completes.
        schedulePendingLoad()
    }

    private fun cancelScheduledLoad() {
        val runnable = pendingLoad?.scheduled ?: return
        pendingLoad?.scheduled = null
        removeCallbacks(runnable)
    }

    /** Posts the pending load unless one is already scheduled. */
    private fun schedulePendingLoad() {
        if (disposed || !isAttachedToWindow) return
        val pending = pendingLoad ?: return
        if (pending.scheduled != null) return
        val runnable = Runnable {
            pending.scheduled = null
            runPendingLoad(pending)
        }
        pending.scheduled = runnable
        post(runnable)
    }

    private fun runPendingLoad(pending: PendingLoad) {
        if (pending.generation != generation || disposed || pendingLoad !== pending ||
            pending.adapter !== adapter
        ) {
            return
        }
        // Detached: kept pending, scheduled again on reattach.
        if (!isAttachedToWindow) return

        // The Activity may have gone away since scheduling: the SDK fails silently then.
        val owner = pending.activity.get()
        if (owner == null || owner.isFinishing || owner.isDestroyed ||
            activityProvider() !== owner
        ) {
            // Discard the prepared banner, leave the config unattempted and look for the
            // current Activity.
            Logger.d("[StroeerBannerContainer] Activity changed before the load, discarding prepared banner")
            invalidateCurrentBanner()
            reconcile()
            return
        }

        // Not laid out yet: kept pending, onLayout() wakes it. Only the container is checked: React
        // Native never lays out natively added children (facebook/react-native#17968).
        if (!isLaidOut) return

        val config = pending.config
        attemptedConfig = config
        pendingLoad = null
        try {
            Logger.d("[StroeerBannerContainer] Container laid out, now loading ad for slot: ${config.slotName}")
            pending.adapter.load(config.slotName, pending.callbacks)
        } catch (e: Exception) {
            fail(config, BannerErrorCodes.SETUP_FAILED, e.message ?: "Failed to load banner")
        }
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        (context as? ReactContext)?.removeLifecycleEventListener(lifecycleListener)
        generation++
        cancelScheduledLoad()
        pendingLoad = null
        destroyCurrentAdapter()
        removeAllViews()
        callbacks = null
    }

    private fun reconcile() {
        if (disposed) return
        val config = committedConfig ?: return
        if (!isAttachedToWindow) return
        if (config == attemptedConfig) return
        // A prepared banner is waiting for its posted load: reuse it.
        if (pendingLoad != null) {
            schedulePendingLoad()
            return
        }

        if (!config.valid) {
            attemptedConfig = config
            fail(config, BannerErrorCodes.INVALID_ARGUMENT, "Invalid banner configuration: publisherSlotName must be non-empty and customTargeting must be a map of strings")
            return
        }

        val activity = activityProvider()
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            // Recoverable: retried on attach, commit or host resume.
            Logger.d("[StroeerBannerContainer] No running Activity yet, waiting to load slot: ${config.slotName}")
            return
        }

        val gen = generation
        try {
            val newAdapter = adapterFactory.create(activity)
            // Own the adapter right away so a failure in any later setup step destroys it.
            adapter = newAdapter
            val adapterActivity = WeakReference(activity)
            newAdapter.configure(config.contentUrl.ifEmpty { null }, config.customTargeting)

            val layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            layoutParams.gravity = Gravity.CENTER
            addView(newAdapter.view, layoutParams)

            val newCallbacks = createCallbacks(gen, newAdapter, config)
            callbacks = newCallbacks
            pendingLoad = PendingLoad(config, gen, newAdapter, newCallbacks, adapterActivity)
            schedulePendingLoad()
        } catch (e: Exception) {
            Logger.e("[StroeerBannerContainer] Error setting up banner: ${e.message}")
            attemptedConfig = config
            // Destroy the partially set up banner (if any) exactly once, then report once.
            invalidateCurrentBanner()
            fail(config, BannerErrorCodes.SETUP_FAILED, e.message ?: "Failed to set up banner")
        }
    }

    private fun destroyCurrentAdapter() {
        val old = adapter ?: return
        adapter = null
        try {
            old.destroy()
        } catch (e: Exception) {
            Logger.e("[StroeerBannerContainer] Error destroying banner: ${e.message}")
        }
    }

    private fun fail(config: Config, code: String, message: String) {
        emit(
            BannerEventPayload(
                BannerEventType.FAILED_TO_LOAD,
                config.slotName,
                errorCode = code,
                errorMessage = message
            )
        )
    }

    private fun emit(payload: BannerEventPayload) {
        if (disposed || id == View.NO_ID) return
        logEvent(payload)
        eventSink(id, payload)
    }

    private fun logEvent(payload: BannerEventPayload) {
        val event = payload.type.registrationName
        val slot = payload.publisherSlotName
        when (payload.type) {
            BannerEventType.LOADED, BannerEventType.IMPRESSION -> Logger.i(
                "[StroeerBannerContainer] $event - slot: $slot, size: ${payload.width}x${payload.height}, source: ${payload.source}"
            )
            BannerEventType.FAILED_TO_LOAD -> Logger.e(
                "[StroeerBannerContainer] $event - slot: $slot, code: ${payload.errorCode}, message: ${payload.errorMessage}"
            )
            else -> Logger.i("[StroeerBannerContainer] $event - slot: $slot")
        }
    }

    private fun createCallbacks(gen: Int, owner: BannerSdkAdapter, config: Config): BannerSdkCallbacks {
        // A callback is only valid while its generation is current and its adapter is the one
        // owned by this container.
        fun isCurrent(caller: String): Boolean {
            val current = !disposed && gen == generation && owner === adapter
            if (!current) {
                Logger.d("[StroeerBannerContainer] Ignoring $caller from a stale banner")
            }
            return current
        }

        fun sized(type: BannerEventType): BannerEventPayload {
            val size = updateBannerSizeAndLayout(owner, gen)
            return BannerEventPayload(
                type,
                config.slotName,
                width = size.width,
                height = size.height,
                source = owner.source
            )
        }

        return object : BannerSdkCallbacks {
            override fun onAdLoaded() {
                if (!isCurrent("onAdLoaded")) return
                emit(sized(BannerEventType.LOADED))
            }

            override fun onAdFailedToLoad(message: String?) {
                if (!isCurrent("onAdFailedToLoad")) return
                // After a successful load this is a refresh failure: the creative and the SDK
                // instance are kept.
                fail(config, BannerErrorCodes.LOAD_FAILED, message ?: "")
            }

            override fun onAdOpened() {
                if (!isCurrent("onAdOpened")) return
                emit(BannerEventPayload(BannerEventType.OPENED, config.slotName))
            }

            override fun onAdClosed() {
                if (!isCurrent("onAdClosed")) return
                emit(BannerEventPayload(BannerEventType.CLOSED, config.slotName))
            }

            override fun onAdClicked() {
                if (!isCurrent("onAdClicked")) return
                emit(BannerEventPayload(BannerEventType.CLICKED, config.slotName))
            }

            override fun onAdImpression() {
                if (!isCurrent("onAdImpression")) return
                // Re-report the size: an auto-reloaded creative can render at a different
                // size than the one reported by onAdLoaded, leaving the RN view stale.
                emit(sized(BannerEventType.IMPRESSION))
            }
        }
    }

    /**
     * Re-applies the manual measure/layout pass that works around React Native's layout bug
     * (facebook/react-native#17968) and returns the ad size to report to JS.
     *
     * Called both when the ad loads and when the impression fires: an auto-reloaded creative
     * can differ in size from the one reported at load time, so the size must be refreshed
     * on every impression too.
     */
    private fun updateBannerSizeAndLayout(owner: BannerSdkAdapter, gen: Int): BannerAdSizeDp {
        relayoutBanner(owner, gen)

        // Read after the relayout so the size handed to JS is the one the SDK currently holds.
        return owner.adSize
    }

    /**
     * React Native owns layout and ignores requestLayout() from views added natively, so a
     * creative attached by the SDK (StroeerBannerView.addBannerAdView -> removeAllViews +
     * addView) never gets measured and stays 0x0.
     *
     * That silently breaks impressions: PrebidHtmlBannerView gates its impression on
     * isInViewport() -> getGlobalVisibleRect().width/height > 0. On the very first load it
     * happened to work only because JS resizes the container (null -> WxH), which triggers a
     * real RN layout pass; a refresh reports the same size, so no RN layout happens and the
     * impression is lost.
     *
     * Measuring/laying out the banner makes FrameLayout.onLayout position its children,
     * honouring the WRAP_CONTENT + TOP|CENTER_HORIZONTAL params the SDK sets on the creative.
     */
    private fun relayoutBanner(owner: BannerSdkAdapter, gen: Int) {
        val banner = owner.view
        val layoutAction = Runnable {
            // The banner may have been dropped between scheduling and running this.
            if (disposed || gen != generation || owner !== adapter) return@Runnable
            // While detached there is nothing to lay out; onAttachedToWindow reruns this.
            if (!isAttachedToWindow) return@Runnable

            try {
                // Size from the SDK's adSize, read live: the SDK updates it internally while
                // rendering (e.g. BannerPrebidSdkAdapter sets it to bannerConfig.prebidAdSize),
                // so a snapshot can describe the previous creative. The view's own width/height
                // are only a fallback -- on a format-changing refresh they still hold the old
                // dimensions, and the prebid viewport check can run before JS resizes anything.
                val liveSize = owner.adSize
                val density = banner.resources.displayMetrics.density
                val adWidthPx = (liveSize.width * density).roundToInt()
                val adHeightPx = (liveSize.height * density).roundToInt()
                val widthPx = if (adWidthPx > 0) adWidthPx else banner.width
                val heightPx = if (adHeightPx > 0) adHeightPx else banner.height
                if (widthPx <= 0 || heightPx <= 0) return@Runnable

                // Force complete layout pass on root view
                banner.rootView.requestLayout()

                // Only the banner is measured/laid out explicitly. Its children (the
                // AdManagerAdView or the PrebidHtmlBannerView) are WRAP_CONTENT, so
                // FrameLayout.onMeasure measures them with an AT_MOST spec -- they keep their
                // own natural size -- and FrameLayout.onLayout positions them by gravity.
                // Measuring/laying out the child here as well would be immediately overwritten
                // by that onLayout pass.
                banner.measure(
                    View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(heightPx, View.MeasureSpec.EXACTLY)
                )
                banner.layout(
                    banner.left,
                    banner.top,
                    banner.left + widthPx,
                    banner.top + heightPx
                )
            } catch (e: Exception) {
                Logger.e("[StroeerBannerContainer] Error during banner layout: ${e.message}")
            }
        }

        // Lay out synchronously when already on the main thread: PrebidHtmlBannerView runs its
        // viewport check from a WebView JS-bridge callback, and posting would let that callback
        // win the race and see a 0x0 view (after which it only listens for scroll events).
        if (Looper.myLooper() == Looper.getMainLooper()) {
            layoutAction.run()
        } else {
            banner.post(layoutAction)
        }
    }
}
