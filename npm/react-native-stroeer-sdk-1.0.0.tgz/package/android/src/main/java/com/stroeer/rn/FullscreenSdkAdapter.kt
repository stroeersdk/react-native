package com.stroeer.rn

import android.app.Activity
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.interstitial.StroeerInterstitialFullListener
import com.stroeer.ads.formats.interstitial.StroeerInterstitialView

/**
 * SDK callbacks of a full screen ad, normalised so [FullscreenAdController] does not depend on the
 * SDK listener types of the individual formats. The reward callback only fires for rewarded ads.
 */
internal interface FullscreenSdkCallbacks {
    fun onAdLoaded()
    fun onAdFailedToLoad(message: String?)
    fun onAdShowed()
    fun onAdDismissed()
    fun onAdFailedToShow(message: String?)
    fun onAdClicked()
    fun onAdImpression()

    /** type / amount are null when the SDK delivered no reward item. */
    fun onUserEarnedReward(type: String?, amount: Int?) {}
}

/**
 * Thin seam over one SDK full screen ad instance. An adapter wraps exactly ONE SDK instance, which
 * is dead after [destroy] (and, for rewarded ads, unusable after a failed load), so every load
 * uses a new adapter. All members must be called on the main thread.
 *
 * Implementations must create the SDK instance with auto-show after load disabled.
 */
internal interface FullscreenSdkAdapter {
    fun load(adSlotId: String, callbacks: FullscreenSdkCallbacks)

    /** The SDK silently ignores this when the ad is not ready. */
    fun show()

    /** Idempotent. */
    fun destroy()
}

internal fun interface FullscreenSdkAdapterFactory {
    /** Throws if the SDK instance cannot be created. */
    fun create(activity: Activity): FullscreenSdkAdapter
}

internal class InterstitialSdkAdapter(activity: Activity) : FullscreenSdkAdapter {

    // The SDK holds the Activity weakly and loadAfterReady defaults to true (auto-show after load),
    // which would bypass show().
    private val view = StroeerInterstitialView(activity).also { it.loadAfterReady = false }

    // The SDK's callback path is weak: keep the listener strongly referenced as long as the view.
    private var listener: StroeerInterstitialFullListener? = null

    override fun load(adSlotId: String, callbacks: FullscreenSdkCallbacks) {
        val sdkListener = object : StroeerInterstitialFullListener() {
            override fun onAdLoaded() = callbacks.onAdLoaded()

            override fun onAdFailedToLoad(exception: StroeerException?) =
                callbacks.onAdFailedToLoad(exception?.message)

            override fun onAdShowedFullScreenContent() = callbacks.onAdShowed()

            override fun onAdDismissedFullScreenContent() = callbacks.onAdDismissed()

            override fun onAdFailedToShowFullScreenContent(e: StroeerException?) =
                callbacks.onAdFailedToShow(e?.message)

            override fun onAdClicked() = callbacks.onAdClicked()

            override fun onAdImpression() = callbacks.onAdImpression()
        }
        listener = sdkListener
        view.load(adSlotId, sdkListener)
    }

    override fun show() {
        view.show()
    }

    override fun destroy() {
        view.destroy()
    }
}
