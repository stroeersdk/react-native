package com.stroeer.rn

import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.stroeer.ads.plugins.identity.IdentityManager
import com.stroeer.ads.plugins.identity.objects.IdentityCustomInfo

/**
 * Identity TurboModule. Every call builds a fresh [IdentityCustomInfo] and assigns it in one
 * step, so no mutable state is shared between calls or with the SDK. Values (email, phone, puid)
 * are personal data and are never logged. The SDK's ID5 provider only ever sets fields, never
 * clears them, so omitted fields keep previously applied values and applied data cannot be removed.
 */
class StroeerIdentityModule internal constructor(
    reactContext: ReactApplicationContext,
    private val identityManager: IdentityManager
) : NativeStroeerIdentityModuleSpec(reactContext) {

    constructor(reactContext: ReactApplicationContext) : this(reactContext, IdentityManager.instance)

    companion object {
        const val NAME = NativeStroeerIdentityModuleSpec.NAME
    }

    override fun setCustomInfo(info: ReadableMap) {
        identityManager.customInfo = IdentityCustomInfo().apply {
            email = info.optString("email")
            phone = info.optString("phone")
            puid = info.optString("puid")
            regionCode = info.optString("regionCode")
            cityCode = info.optString("cityCode")
        }
    }

    private fun ReadableMap.optString(key: String): String? =
        if (hasKey(key) && !isNull(key)) getString(key) else null
}
