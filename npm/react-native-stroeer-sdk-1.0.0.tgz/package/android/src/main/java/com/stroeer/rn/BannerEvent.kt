package com.stroeer.rn

import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.events.Event

internal enum class BannerEventType(val eventName: String, val registrationName: String) {
    LOADED("topAdLoaded", "onAdLoaded"),
    IMPRESSION("topAdImpression", "onAdImpression"),
    FAILED_TO_LOAD("topAdFailedToLoad", "onAdFailedToLoad"),
    OPENED("topAdOpened", "onAdOpened"),
    CLOSED("topAdClosed", "onAdClosed"),
    CLICKED("topAdClicked", "onAdClicked")
}

/** Plain-Kotlin event data (sizes in dp), converted to a WritableMap only at dispatch time. */
internal data class BannerEventPayload(
    val type: BannerEventType,
    val publisherSlotName: String,
    val width: Int = 0,
    val height: Int = 0,
    val source: String = "",
    val errorCode: String? = null,
    val errorMessage: String? = null
)

/**
 * Fabric direct event. Never coalesced: the Fabric EventQueue otherwise replaces a queued event of
 * the same type for the same target, which would drop e.g. a loaded event queued right before an
 * impression, or two consecutive refresh impressions.
 */
internal class BannerEvent(
    surfaceId: Int,
    viewId: Int,
    private val payload: BannerEventPayload
) : Event<BannerEvent>(surfaceId, viewId) {

    override fun getEventName(): String = payload.type.eventName

    override fun canCoalesce(): Boolean = false

    override fun getEventData(): WritableMap {
        val map = Arguments.createMap()
        map.putString("publisherSlotName", payload.publisherSlotName)
        when (payload.type) {
            BannerEventType.LOADED, BannerEventType.IMPRESSION -> {
                map.putDouble("width", payload.width.toDouble())
                map.putDouble("height", payload.height.toDouble())
                map.putString("source", payload.source)
            }
            BannerEventType.FAILED_TO_LOAD -> {
                val error = Arguments.createMap()
                error.putString("code", payload.errorCode ?: BannerErrorCodes.LOAD_FAILED)
                error.putString("message", payload.errorMessage ?: "")
                map.putMap("error", error)
            }
            else -> Unit
        }
        return map
    }
}

internal object BannerErrorCodes {
    const val INVALID_ARGUMENT = "INVALID_ARGUMENT"
    const val SETUP_FAILED = "SETUP_FAILED"
    const val LOAD_FAILED = "LOAD_FAILED"
}
