# Consent Module (CMP)

The `StroeerConsentModule` is **currently disabled** by default because the CMP (Consent Management Platform) plugin is optional.

## Current Status

- ❌ **Module File**: `StroeerConsentModule.kt.disabled` (renamed, not compiled)
- ❌ **Package Registration**: Commented out in `StroeerPackage.kt`
- ✅ **TypeScript Interface**: Available with graceful fallback in `src/Consent.tsx`

## Why Disabled?

The CMP plugin (`com.yieldlove.adIntegration:cmp`) adds additional dependencies that may not be needed by all apps. By disabling it by default, the SDK remains lighter and apps can opt-in to consent features only when needed.

## How to Enable

### 1. Add CMP Dependencies

Add these to `android/build.gradle`:

```gradle
dependencies {
    // ... existing dependencies
    implementation 'com.yieldlove.adIntegration:cmp:8.0.0'
    implementation 'com.sourcepoint.cmplibrary:cmplibrary:7.15.9'
}
```

### 2. Enable the Module File

Rename the disabled file:

```bash
mv android/src/main/java/com/stroeer/rn/StroeerConsentModule.kt.disabled \
   android/src/main/java/com/stroeer/rn/StroeerConsentModule.kt
```

### 3. Register the Module

In `android/src/main/java/com/stroeer/rn/StroeerPackage.kt`, uncomment:

```kotlin
override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> {
    return listOf(
        StroeerModule(reactContext),
        StroeerConsentModule(reactContext),  // <-- Uncomment this line
        StroeerConfiantModule(reactContext),
        // ... other modules
    )
}
```

### 4. Rebuild

```bash
yarn build:android
```

## Usage

The TypeScript interface is always available and will gracefully handle whether CMP is enabled or not:

```typescript
import { StroeerConsentModule } from 'react-native-stroeer-sdk';

// Check if CMP is available
const cmpAvailable = await StroeerConsentModule.isAvailable();

if (cmpAvailable) {
  // CMP is enabled - use consent features
  await StroeerConsentModule.initialize();
  await StroeerConsentModule.showConsent();
} else {
  // CMP is disabled - handle gracefully
  console.log('CMP not available');
}
```

## Implementation Details

The module uses **reflection** to access CMP classes at runtime. This means:
- ✅ Compiles without CMP dependencies
- ✅ Works with or without CMP at runtime
- ✅ No compile-time dependency on CMP classes
- ✅ Graceful fallback when CMP is not available

The module checks for these classes at runtime:
- `com.stroeer.cmp.StroeerConsent`
- `com.stroeer.cmp.StroeerConsentListener`
- `com.stroeer.consent.ConsentManager`

If any are missing, methods will reject with a clear error message.
