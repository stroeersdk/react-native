package com.stroeer.rn

import android.app.Activity
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.LifecycleEventListener
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.UiThreadUtil
import com.facebook.react.bridge.WritableMap
import com.facebook.react.common.LifecycleState
import com.stroeer.ads.utilities.logging.Logger

/**
 * Rewarded TurboModule: a thin adapter between the generated spec and [FullscreenAdController]
 * (shared with interstitial ads). Every spec method hops to the main thread first; the controller owns
 * all state.
 */
class StroeerRewardedModule internal constructor(
    reactContext: ReactApplicationContext,
    activityProvider: () -> Activity?,
    adapterFactory: FullscreenSdkAdapterFactory,
    scheduler: FullscreenScheduler,
    private val mapFactory: () -> WritableMap,
    loadTimeoutMs: Long,
    initialHostResumed: Boolean = true
) : NativeStroeerRewardedModuleSpec(reactContext), LifecycleEventListener {

    constructor(reactContext: ReactApplicationContext) : this(
        reactContext,
        activityProvider = { reactContext.currentActivity },
        adapterFactory = FullscreenSdkAdapterFactory { activity -> RewardedSdkAdapter(activity) },
        scheduler = MainLooperScheduler(),
        mapFactory = { Arguments.createMap() },
        loadTimeoutMs = FullscreenAdController.DEFAULT_LOAD_TIMEOUT_MS,
        initialHostResumed = reactContext.lifecycleState == LifecycleState.RESUMED
    )

    private val currentActivityProvider = activityProvider
    private var invalidated = false

    private val controller = FullscreenAdController(
        activityProvider = activityProvider,
        adapterFactory = adapterFactory,
        events = ModuleEvents(),
        scheduler = scheduler,
        loadTimeoutMs = loadTimeoutMs,
        initialHostResumed = initialHostResumed,
        logTag = "[StroeerRewarded]"
    )

    init {
        reactContext.addLifecycleEventListener(this)
    }

    override fun createAd(publisherSlotName: String, promise: Promise) {
        onMain(promise) { controller.create(publisherSlotName, promise.asSettlement { it }) }
    }

    override fun load(adId: String, promise: Promise) {
        onMain(promise) { controller.load(adId, promise.asSettlement { null }) }
    }

    override fun show(adId: String, promise: Promise) {
        onMain(promise) { controller.show(adId, promise.asSettlement { null }) }
    }

    override fun isReady(adId: String, promise: Promise) {
        onMain(promise) { promise.resolve(controller.isReady(adId)) }
    }

    override fun destroy(adId: String, promise: Promise) {
        onMain(promise) { controller.destroy(adId, promise.asSettlement { null }) }
    }

    override fun onHostResume() {
        runOnMain { controller.onHostResume() }
    }

    override fun onHostPause() {
        runOnMain { controller.onHostPause() }
    }

    override fun onHostDestroy() {
        // ReactContext still reports the destroyed Activity while listeners run.
        controller.onHostDestroy(currentActivityProvider())
    }

    override fun invalidate() {
        runOnMain {
            if (invalidated) return@runOnMain
            invalidated = true
            Logger.d("[StroeerRewarded] invalidate - cleaning up")
            reactApplicationContext.removeLifecycleEventListener(this)
            controller.invalidate()
        }
        super.invalidate()
    }

    /** Runs on the main thread; an exception inside the task rejects the promise. */
    private fun onMain(promise: Promise, task: () -> Unit) {
        runOnMain {
            try {
                task()
            } catch (e: Exception) {
                Logger.e("[StroeerRewarded] Unexpected error: ${e.message}")
                promise.reject(FullscreenErrorCodes.INVALID_STATE, e.message ?: "Unexpected error")
            }
        }
    }

    // UiThreadUtil.runOnUiThread always posts; run right away when already on the main thread.
    private fun runOnMain(task: () -> Unit) {
        if (UiThreadUtil.isOnUiThread()) task() else UiThreadUtil.runOnUiThread(task)
    }

    private fun <T> Promise.asSettlement(value: (T) -> Any?): Settlement<T> =
        Settlement(
            resolve = { resolve(value(it)) },
            reject = { code, message -> reject(code, message) }
        )

    private fun idMap(adId: String): WritableMap = mapFactory().also { it.putString("adId", adId) }

    private fun errorMap(adId: String, code: String, message: String): WritableMap =
        idMap(adId).also {
            it.putMap("error", mapFactory().also { error ->
                error.putString("code", code)
                error.putString("message", message)
            })
        }

    private fun rewardMap(adId: String, type: String, amount: Int): WritableMap =
        idMap(adId).also {
            it.putMap("reward", mapFactory().also { reward ->
                reward.putString("type", type)
                reward.putDouble("amount", amount.toDouble())
            })
        }

    // Events are emitted on the main thread. The generated emit helpers dereference the emitter
    // callback, which is only set once the TurboModule host installed it: a failing emit must
    // never break the controller's state handling or the SDK callback that triggered it.
    private fun emitSafely(name: String, emit: () -> Unit) {
        try {
            emit()
        } catch (e: Exception) {
            Logger.e("[StroeerRewarded] Failed to emit $name: ${e.message}")
        }
    }

    private inner class ModuleEvents : FullscreenAdEvents {
        override fun onAdLoaded(adId: String) = emitSafely("onAdLoaded") { emitOnAdLoaded(idMap(adId)) }
        override fun onAdShowed(adId: String) = emitSafely("onAdShowed") { emitOnAdShowed(idMap(adId)) }
        override fun onAdDismissed(adId: String) = emitSafely("onAdDismissed") { emitOnAdDismissed(idMap(adId)) }
        override fun onAdClicked(adId: String) = emitSafely("onAdClicked") { emitOnAdClicked(idMap(adId)) }
        override fun onAdImpression(adId: String) = emitSafely("onAdImpression") { emitOnAdImpression(idMap(adId)) }
        override fun onUserEarnedReward(adId: String, type: String, amount: Int) =
            emitSafely("onUserEarnedReward") { emitOnUserEarnedReward(rewardMap(adId, type, amount)) }
        override fun onAdFailedToLoad(adId: String, code: String, message: String) =
            emitSafely("onAdFailedToLoad") { emitOnAdFailedToLoad(errorMap(adId, code, message)) }
        override fun onAdFailedToShow(adId: String, code: String, message: String) =
            emitSafely("onAdFailedToShow") { emitOnAdFailedToShow(errorMap(adId, code, message)) }
    }
}
