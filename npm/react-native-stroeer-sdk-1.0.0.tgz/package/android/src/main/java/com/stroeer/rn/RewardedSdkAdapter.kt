package com.stroeer.rn

import android.app.Activity
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.rewarded.StroeerRewardedFullListener
import com.stroeer.ads.formats.rewarded.StroeerRewardedView

/**
 * [FullscreenSdkAdapter] of one [StroeerRewardedView]. After a failed load the SDK view stays in
 * its LOADING status forever, so it is never reused: every handle gets a new adapter.
 */
internal class RewardedSdkAdapter(
    activity: Activity,
    viewFactory: (Activity) -> StroeerRewardedView = { StroeerRewardedView(it) }
) : FullscreenSdkAdapter {

    // The SDK holds the Activity weakly and loadAfterReady defaults to true (auto-show after load),
    // which would bypass show().
    private val view = viewFactory(activity).also { it.loadAfterReady = false }

    // The SDK's callback path is weak: keep the listener strongly referenced as long as the view.
    private var listener: StroeerRewardedFullListener? = null

    override fun load(adSlotId: String, callbacks: FullscreenSdkCallbacks) {
        val sdkListener = object : StroeerRewardedFullListener() {
            override fun onAdLoaded(rewardedAd: RewardedAd?) = callbacks.onAdLoaded()

            override fun onAdFailedToLoad(exception: StroeerException) =
                callbacks.onAdFailedToLoad(exception.message)

            override fun onUserEarnedReward(item: RewardItem?) =
                callbacks.onUserEarnedReward(item?.type, item?.amount)

            override fun onAdShowedFullScreenContent() = callbacks.onAdShowed()

            override fun onAdDismissedFullScreenContent() = callbacks.onAdDismissed()

            override fun onAdFailedToShowFullScreenContent(e: StroeerException?) =
                callbacks.onAdFailedToShow(e?.message)

            override fun onAdClicked() = callbacks.onAdClicked()

            override fun onAdImpression() = callbacks.onAdImpression()
        }
        listener = sdkListener
        view.load(adSlotId, sdkListener)
    }

    override fun show() {
        view.show()
    }

    override fun destroy() {
        view.destroy()
    }
}
