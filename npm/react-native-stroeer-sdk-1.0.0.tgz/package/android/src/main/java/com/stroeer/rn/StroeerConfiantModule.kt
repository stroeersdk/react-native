package com.stroeer.rn

import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.stroeer.ads.plugins.monitoring.IAdMonitorCallback
import com.stroeer.ads.plugins.monitoring.confiant.ConfiantLoader
import com.stroeer.ads.utilities.logging.Logger
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Confiant TurboModule.
 *
 * [ConfiantLoader] gives weak guarantees this module compensates for:
 * - the callback may run on the caller's thread (invalid config) or on an SDK worker thread;
 * - it is NOT invoked at all when the loader is already initializing, already initialized or in
 *   a terminal failure state (no Confiant SDK / not activated / invalid config from an earlier
 *   attempt), and a second call replaces the first call's callback;
 * - it may be invoked more than once.
 * Hence the SDK attempt is tracked separately from the JS promise: [loader] is called at most once
 * per attempt and never again until that attempt's callback arrives (even if its promise timed
 * out, since a second call would overwrite the running attempt's inputs). The first observed SDK
 * result is cached and answers later calls without touching the loader (a late callback after a
 * timeout updates it). A timeout bounds each promise's wait; each promise settles exactly once.
 */
class StroeerConfiantModule internal constructor(
    reactContext: ReactApplicationContext,
    private val loader: ConfiantLoader,
    private val scheduler: FullscreenScheduler,
    private val initTimeoutMs: Long
) : NativeStroeerConfiantModuleSpec(reactContext) {

    constructor(reactContext: ReactApplicationContext) : this(
        reactContext,
        loader = ConfiantLoader.getInstance(),
        scheduler = MainLooperScheduler(),
        initTimeoutMs = DEFAULT_INIT_TIMEOUT_MS
    )

    companion object {
        const val NAME = NativeStroeerConfiantModuleSpec.NAME
        const val INVALID_ARGUMENT = "INVALID_ARGUMENT"
        const val ALREADY_INITIALIZING = "ALREADY_INITIALIZING"
        const val INIT_TIMEOUT = "INIT_TIMEOUT"
        const val INIT_FAILED = "INIT_FAILED"

        // Remote configuration wait (3 x 1s) plus the Confiant SDK's own initialization.
        internal const val DEFAULT_INIT_TIMEOUT_MS = 60_000L
    }

    /** One in-flight initialize call; [settle] runs at most one of the supplied actions. */
    private inner class Pending(private val promise: Promise) {
        private val settled = AtomicBoolean(false)
        @Volatile var timer: FullscreenCancellable? = null

        fun settle(action: (Promise) -> Unit) {
            if (!settled.compareAndSet(false, true)) return
            timer?.cancel()
            synchronized(lock) { if (pending === this) pending = null }
            action(promise)
        }
    }

    private val lock = Any()
    private var pending: Pending? = null
    private var attemptRunning = false
    private var cachedResult: Boolean? = null
    private var initializeRequested = false

    override fun enableTestMode() {
        synchronized(lock) {
            if (initializeRequested) {
                // The loader reads the flag once its asynchronous initialization runs, and never
                // again after a terminal result: a late call is unreliable, so it is refused.
                Logger.e("[StroeerConfiant] enableTestMode ignored: initialize was already requested")
                return
            }
        }
        loader.enableTestMode()
        Logger.i("[StroeerConfiant] Test mode enabled")
    }

    override fun initialize(confiantPropertyId: String, enableReload: Boolean, promise: Promise) {
        if (confiantPropertyId.isBlank()) {
            promise.reject(INVALID_ARGUMENT, "confiantPropertyId is blank")
            return
        }

        val call: Pending
        synchronized(lock) {
            if (attemptRunning) {
                promise.reject(ALREADY_INITIALIZING, "Confiant initialization is already in progress")
                return
            }
            cachedResult?.let {
                promise.resolve(it)
                return
            }
            if (loader.isRunnable()) {
                promise.resolve(true)
                return
            }
            initializeRequested = true
            attemptRunning = true
            call = Pending(promise)
            pending = call
        }

        call.timer = scheduler.postDelayed(initTimeoutMs) {
            Logger.e("[StroeerConfiant] initialize timed out after ${initTimeoutMs}ms")
            call.settle { it.reject(INIT_TIMEOUT, "Confiant did not report an initialization result") }
        }

        try {
            loader.initialize(confiantPropertyId, enableReload, IAdMonitorCallback { success ->
                Logger.i("[StroeerConfiant] Initialized: $success")
                synchronized(lock) {
                    // A duplicate callback of an attempt that already reported is ignored.
                    if (attemptRunning) {
                        attemptRunning = false
                        cachedResult = success
                    }
                }
                call.settle { it.resolve(success) }
            })
        } catch (e: Exception) {
            Logger.e("[StroeerConfiant] Error initializing: ${e.message}")
            synchronized(lock) { attemptRunning = false }
            call.settle { it.reject(INIT_FAILED, e.message ?: "Failed to initialize Confiant", e) }
        }
    }
}
