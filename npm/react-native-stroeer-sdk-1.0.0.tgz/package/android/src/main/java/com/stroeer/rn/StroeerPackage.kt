package com.stroeer.rn

import com.facebook.react.BaseReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfo
import com.facebook.react.module.model.ReactModuleInfoProvider
import com.facebook.react.uimanager.ViewManager

class StroeerPackage : BaseReactPackage() {
    override fun getModule(name: String, reactContext: ReactApplicationContext): NativeModule? =
        when (name) {
            StroeerModule.NAME -> StroeerModule(reactContext)
            StroeerConfiantModule.NAME -> StroeerConfiantModule(reactContext)
            StroeerIdentityModule.NAME -> StroeerIdentityModule(reactContext)
            NativeStroeerInterstitialModuleSpec.NAME -> StroeerInterstitialModule(reactContext)
            NativeStroeerRewardedModuleSpec.NAME -> StroeerRewardedModule(reactContext)
            else -> null
        }

    override fun getReactModuleInfoProvider(): ReactModuleInfoProvider = ReactModuleInfoProvider {
        // Every module extends a codegen spec, so all of them are TurboModules.
        listOf(
            StroeerModule.NAME to StroeerModule::class.java,
            StroeerConfiantModule.NAME to StroeerConfiantModule::class.java,
            StroeerIdentityModule.NAME to StroeerIdentityModule::class.java,
            NativeStroeerInterstitialModuleSpec.NAME to StroeerInterstitialModule::class.java,
            NativeStroeerRewardedModuleSpec.NAME to StroeerRewardedModule::class.java
        ).associate { (name, cls) ->
            name to ReactModuleInfo(
                name = name,
                className = cls.name,
                canOverrideExistingModule = false,
                needsEagerInit = false,
                isCxxModule = false,
                isTurboModule = true
            )
        }
    }

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> {
        return listOf(StroeerBannerViewManager(reactContext))
    }
}
