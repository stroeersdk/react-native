package com.stroeer.rn

import android.app.Activity
import android.view.View
import com.stroeer.ads.exceptions.StroeerException
import com.stroeer.ads.formats.banner.StroeerBannerListener
import com.stroeer.ads.formats.banner.StroeerBannerView

/** Ad size in dp, as currently held by the SDK. */
internal data class BannerAdSizeDp(val width: Int, val height: Int)

/** SDK callbacks, normalised so the container does not depend on the SDK listener type. */
internal interface BannerSdkCallbacks {
    fun onAdLoaded()
    fun onAdFailedToLoad(message: String?)
    fun onAdOpened()
    fun onAdClosed()
    fun onAdClicked()
    fun onAdImpression()
}

/**
 * Thin seam over the SDK's [StroeerBannerView]. One adapter wraps exactly one SDK banner instance:
 * the SDK view is dead after [destroy], so a new load always uses a new adapter. All members must
 * be called on the main thread.
 */
internal interface BannerSdkAdapter {
    /** The view to add to the container. */
    val view: View

    /** Slot id as currently held by the SDK. */
    val adSlotId: String

    /** Ad size in dp, read live from the SDK (it changes while a creative renders). */
    val adSize: BannerAdSizeDp

    /** Ad sub source of the current creative, or "" when unknown. */
    val source: String

    /** contentUrl / customTargeting must be applied before [load]. */
    fun configure(contentUrl: String?, customTargeting: Map<String, String>)

    fun load(adSlotId: String, callbacks: BannerSdkCallbacks)

    /** Idempotent. */
    fun destroy()
}

internal fun interface BannerSdkAdapterFactory {
    /** Throws if the SDK view cannot be created. */
    fun create(activity: Activity): BannerSdkAdapter
}

internal class StroeerBannerSdkAdapter(activity: Activity) : BannerSdkAdapter {

    // The SDK needs an Activity context, otherwise load fails silently (ContextException without
    // a callback).
    private val banner = StroeerBannerView(activity).also {
        // destroyWhenDetached would destroy the SDK view in onDetachedFromWindow without any
        // handling for reattachment. The container owns the lifecycle instead.
        it.destroyWhenDetached = false
    }

    // The SDK only holds its listener weakly, so keep a strong reference for the lifetime of the
    // banner.
    private var listener: StroeerBannerListener? = null

    override val view: View get() = banner

    override val adSlotId: String get() = banner.adSlotId

    override val adSize: BannerAdSizeDp
        get() {
            val size = banner.adSize
            return BannerAdSizeDp(size.width, size.height)
        }

    override val source: String
        get() = try {
            banner.bannerConfig.source.adSubSource ?: ""
        } catch (e: Exception) {
            ""
        }

    override fun configure(contentUrl: String?, customTargeting: Map<String, String>) {
        banner.contentUrl = contentUrl
        if (customTargeting.isNotEmpty()) {
            // Hand over a copy: the container's map must stay untouched.
            banner.bannerConfig.customTargeting = customTargeting.toMutableMap()
        }
    }

    override fun load(adSlotId: String, callbacks: BannerSdkCallbacks) {
        val sdkListener = object : StroeerBannerListener() {
            override fun onAdLoaded(banner: StroeerBannerView?) = callbacks.onAdLoaded()

            override fun onAdFailedToLoad(banner: StroeerBannerView?, error: StroeerException) =
                callbacks.onAdFailedToLoad(error.message)

            override fun onAdOpened(banner: StroeerBannerView?) = callbacks.onAdOpened()

            override fun onAdClosed(banner: StroeerBannerView?) = callbacks.onAdClosed()

            override fun onAdClicked(banner: StroeerBannerView?) = callbacks.onAdClicked()

            override fun onAdImpression(banner: StroeerBannerView?) = callbacks.onAdImpression()
        }
        listener = sdkListener
        banner.load(adSlotId, sdkListener)
    }

    override fun destroy() {
        banner.destroy()
    }
}
