package com.stroeer.rn

import android.app.Activity
import android.os.Handler
import android.os.Looper
import com.stroeer.ads.utilities.logging.Logger
import java.lang.ref.WeakReference
import java.util.UUID

internal object FullscreenErrorCodes {
    const val INVALID_ARGUMENT = "INVALID_ARGUMENT"
    const val UNKNOWN_AD = "UNKNOWN_AD"
    const val INVALID_STATE = "INVALID_STATE"
    const val NOT_READY = "NOT_READY"
    const val NO_ACTIVITY = "NO_ACTIVITY"
    const val ACTIVITY_LOST = "ACTIVITY_LOST"
    const val LOAD_FAILED = "LOAD_FAILED"
    const val LOAD_TIMEOUT = "LOAD_TIMEOUT"
    const val SHOW_FAILED = "SHOW_FAILED"
    const val DESTROYED = "DESTROYED"
    const val APP_IN_BACKGROUND = "APP_IN_BACKGROUND"
}

/** Settles one JS promise. The controller guarantees it is invoked exactly once. */
internal class Settlement<T>(
    val resolve: (T) -> Unit,
    val reject: (code: String, message: String) -> Unit
)

/** Public events of an ad handle. Called on the main thread, after the state transition. */
internal interface FullscreenAdEvents {
    fun onAdLoaded(adId: String)
    fun onAdShowed(adId: String)
    fun onAdDismissed(adId: String)
    fun onAdClicked(adId: String)
    fun onAdImpression(adId: String)
    fun onAdFailedToLoad(adId: String, code: String, message: String)
    fun onAdFailedToShow(adId: String, code: String, message: String)

    /** Only rewarded ads. */
    fun onUserEarnedReward(adId: String, type: String, amount: Int) {}
}

internal fun interface FullscreenCancellable {
    fun cancel()
}

internal interface FullscreenScheduler {
    fun postDelayed(delayMs: Long, task: Runnable): FullscreenCancellable
}

internal class MainLooperScheduler : FullscreenScheduler {
    private val handler = Handler(Looper.getMainLooper())

    override fun postDelayed(delayMs: Long, task: Runnable): FullscreenCancellable {
        handler.postDelayed(task, delayMs)
        return FullscreenCancellable { handler.removeCallbacks(task) }
    }
}

internal enum class FullscreenAdState { IDLE, LOADING, READY, SHOWING, DISMISSED, FAILED }

/**
 * Shared controller of one-shot full screen ad handles (interstitial, rewarded).
 *
 * Every handle (adId) owns at most one SDK instance, created on [load] and never reused. State
 * machine: IDLE -> LOADING -> READY -> SHOWING -> DISMISSED, LOADING -> FAILED, READY / SHOWING ->
 * FAILED; destroy removes the record from any state.
 *
 * The SDK instance is released on a failed load (error / timeout / activity loss), a failed
 * show (including a dismissal that was never preceded by a showed callback), destroy and
 * invalidate, but NOT on a dismissal of a presented ad: a reward may still arrive after it.
 *
 * Rules:
 *  - All members run on the main thread (callers post there first).
 *  - Every promise settles exactly once; its slot is cleared before it is settled, and the state
 *    transition happens before the event is emitted and the promise settled.
 *  - A failed accepted operation emits the matching failure event AND rejects with the same
 *    {code, message}. Precondition rejections (unknown id, wrong state, no Activity) do not emit.
 *  - SDK callbacks are validated against the record and its session, so late callbacks of a
 *    destroyed / replaced SDK instance are ignored.
 *  - The Activity is only referenced weakly, for identity.
 */
internal class FullscreenAdController(
    private val activityProvider: () -> Activity?,
    private val adapterFactory: FullscreenSdkAdapterFactory,
    events: FullscreenAdEvents,
    private val scheduler: FullscreenScheduler,
    private val loadTimeoutMs: Long = DEFAULT_LOAD_TIMEOUT_MS,
    private val idFactory: () -> String = { UUID.randomUUID().toString() },
    initialHostResumed: Boolean = true,
    private val logTag: String = "[FullscreenAdController]"
) {

    // Every public event is logged once, at the single point where it is handed to JS.
    private val events: FullscreenAdEvents = LoggingEvents(events)

    private class Record(val adId: String, val slotName: String) {
        var state = FullscreenAdState.IDLE
        var adapter: FullscreenSdkAdapter? = null

        // Identifies the SDK instance whose callbacks are valid; kept after the SDK instance has
        // been released so callbacks queued around dismissal (e.g. a reward) still route.
        var session: Any? = null

        // Strong reference: the SDK only holds its listener weakly.
        var callbacks: FullscreenSdkCallbacks? = null
        var activity: WeakReference<Activity>? = null
        var loadSettlement: Settlement<Unit>? = null
        var showSettlement: Settlement<Unit>? = null
        var timeout: FullscreenCancellable? = null

        // destroy() was requested while SHOWING: no more public events.
        var disposed = false
        var rewardDelivered = false

        // SHOWING starts when show() is requested; this is set once the SDK confirmed the
        // presentation (onAdShowed).
        var showConfirmed = false
    }

    private val records = HashMap<String, Record>()
    private var invalidated = false

    // Whether the host Activity is resumed. show() is refused while it is not; load() is not gated.
    // Our own presented ad pauses the host only after show() moved the record to SHOWING.
    private var hostResumed = initialHostResumed

    fun onHostResume() {
        hostResumed = true
    }

    fun onHostPause() {
        hostResumed = false
    }

    fun create(slotName: String, settlement: Settlement<String>) {
        if (invalidated) {
            settlement.reject(FullscreenErrorCodes.DESTROYED, "The React instance was destroyed")
            return
        }
        if (slotName.isEmpty()) {
            settlement.reject(FullscreenErrorCodes.INVALID_ARGUMENT, "publisherSlotName must not be empty")
            return
        }
        var adId = idFactory()
        while (records.containsKey(adId)) adId = idFactory()
        records[adId] = Record(adId, slotName)
        settlement.resolve(adId)
    }

    fun load(adId: String, settlement: Settlement<Unit>) {
        val record = records[adId]
        if (record == null) {
            settlement.reject(FullscreenErrorCodes.UNKNOWN_AD, "Unknown ad: $adId")
            return
        }
        if (record.state != FullscreenAdState.IDLE) {
            settlement.reject(FullscreenErrorCodes.INVALID_STATE, "Cannot load an ad in state ${record.state}; an ad can only be loaded once")
            return
        }
        val activity = activityProvider()
        if (!isAlive(activity)) {
            settlement.reject(FullscreenErrorCodes.NO_ACTIVITY, "No running Activity available to load the ad")
            return
        }
        activity!!

        record.state = FullscreenAdState.LOADING
        record.loadSettlement = settlement
        record.activity = WeakReference(activity)
        val session = Any()
        record.session = session

        try {
            val adapter = adapterFactory.create(activity)
            record.adapter = adapter
            val callbacks = createCallbacks(record, session)
            record.callbacks = callbacks
            record.timeout = scheduler.postDelayed(loadTimeoutMs) { onLoadTimeout(record, session) }
            adapter.load(record.slotName, callbacks)
        } catch (e: Exception) {
            Logger.e("[FullscreenAdController] Error loading ad: ${e.message}")
            failLoad(record, FullscreenErrorCodes.LOAD_FAILED, e.message ?: "Failed to load ad")
        }
    }

    fun show(adId: String, settlement: Settlement<Unit>) {
        val record = records[adId]
        if (record == null) {
            settlement.reject(FullscreenErrorCodes.UNKNOWN_AD, "Unknown ad: $adId")
            return
        }
        when (record.state) {
            FullscreenAdState.READY -> Unit
            FullscreenAdState.IDLE, FullscreenAdState.LOADING -> {
                settlement.reject(FullscreenErrorCodes.NOT_READY, "The ad is not loaded yet")
                return
            }
            else -> {
                settlement.reject(FullscreenErrorCodes.INVALID_STATE, "Cannot show an ad in state ${record.state}; an ad can only be shown once")
                return
            }
        }

        // A paused host (app in background) must not present an ad. A precondition rejection: no
        // event, the ad stays READY (and isReady() stays true: it is loaded) and can be shown once
        // the app is resumed.
        if (!hostResumed) {
            settlement.reject(
                FullscreenErrorCodes.APP_IN_BACKGROUND,
                "The app is in the background; show the ad once it is in the foreground"
            )
            return
        }

        // The SDK validates the Activity itself but fails silently, so check it here: it must be
        // the one the SDK instance was created with.
        val current = activityProvider()
        val owner = record.activity?.get()
        if (!isAlive(current) || owner == null || current !== owner) {
            val message = "The Activity the ad was loaded with is no longer available"
            record.state = FullscreenAdState.FAILED
            releaseAdapter(record)
            events.onAdFailedToShow(adId, FullscreenErrorCodes.ACTIVITY_LOST, message)
            settlement.reject(FullscreenErrorCodes.ACTIVITY_LOST, message)
            return
        }

        record.state = FullscreenAdState.SHOWING
        record.showSettlement = settlement
        try {
            record.adapter?.show()
        } catch (e: Exception) {
            Logger.e("[FullscreenAdController] Error showing ad: ${e.message}")
            failShow(record, FullscreenErrorCodes.SHOW_FAILED, e.message ?: "Failed to show ad")
        }
    }

    fun isReady(adId: String): Boolean {
        val record = records[adId] ?: return false
        if (record.state != FullscreenAdState.READY) return false
        val owner = record.activity?.get()
        return owner != null && isAlive(owner) && activityProvider() === owner
    }

    /** Idempotent: an unknown id resolves. */
    fun destroy(adId: String, settlement: Settlement<Unit>) {
        val record = records[adId]
        if (record != null) destroyRecord(record)
        settlement.resolve(Unit)
    }

    /**
     * The host Activity is going away: ads still being loaded fail, loaded-but-not-shown ads can no
     * longer be shown. A showing ad is left to the SDK once the SDK confirmed the presentation;
 * before that its pending show fails with ACTIVITY_LOST.
     */
    fun onHostDestroy(destroyed: Activity?) {
        if (destroyed == null) return
        for (record in records.values.toList()) {
            if (record.activity?.get() !== destroyed) continue
            when (record.state) {
                FullscreenAdState.LOADING ->
                    failLoad(record, FullscreenErrorCodes.ACTIVITY_LOST, "The Activity was destroyed while the ad was loading")
                FullscreenAdState.READY -> {
                    record.state = FullscreenAdState.FAILED
                    releaseAdapter(record)
                }
                FullscreenAdState.SHOWING -> {
                    // A confirmed presentation is left to the SDK. An unconfirmed one will never
                    // be confirmed: settle the pending show promise.
                    if (!record.showConfirmed) {
                        failShow(record, FullscreenErrorCodes.ACTIVITY_LOST, "The Activity was destroyed while the ad was being shown")
                    }
                }
                else -> Unit
            }
        }
    }

    /** The React instance goes away: reject everything pending and destroy every SDK instance. */
    fun invalidate() {
        if (invalidated) return
        invalidated = true
        for (record in records.values.toList()) {
            destroyRecord(record)
            // A showing ad keeps its SDK instance after destroyRecord(); nothing will route its
            // dismissal any more.
            releaseAdapter(record)
        }
        records.clear()
    }

    private fun destroyRecord(record: Record) {
        record.timeout?.cancel()
        record.timeout = null

        if (record.state == FullscreenAdState.SHOWING) {
            // The SDK instance is still on screen: suppress public events and let the dismissal /
            // show failure callback destroy it and remove the record.
            record.disposed = true
            settleShow(record, FullscreenErrorCodes.DESTROYED, "The ad was destroyed")
            return
        }
        records.remove(record.adId)
        record.disposed = true
        settleLoad(record, FullscreenErrorCodes.DESTROYED, "The ad was destroyed")
        settleShow(record, FullscreenErrorCodes.DESTROYED, "The ad was destroyed")
        releaseAdapter(record)
    }

    private fun createCallbacks(record: Record, session: Any): FullscreenSdkCallbacks {
        // Callbacks are valid while the record is registered and belongs to this SDK instance.
        fun isCurrent(caller: String): Boolean {
            val current = records[record.adId] === record && record.session === session
            if (!current) {
                Logger.d("[FullscreenAdController] Ignoring $caller from a stale ad instance")
            }
            return current
        }

        return object : FullscreenSdkCallbacks {
            override fun onAdLoaded() {
                if (!isCurrent("onAdLoaded")) return
                if (record.state != FullscreenAdState.LOADING) return
                record.timeout?.cancel()
                record.timeout = null
                record.state = FullscreenAdState.READY
                events.onAdLoaded(record.adId)
                settleLoadSuccess(record)
            }

            override fun onAdFailedToLoad(message: String?) {
                if (!isCurrent("onAdFailedToLoad")) return
                if (record.state != FullscreenAdState.LOADING) return
                failLoad(record, FullscreenErrorCodes.LOAD_FAILED, message ?: "Failed to load ad")
            }

            override fun onAdShowed() {
                if (!isCurrent("onAdShowed")) return
                if (record.state != FullscreenAdState.SHOWING) return
                record.showConfirmed = true
                if (!record.disposed) events.onAdShowed(record.adId)
                settleShowSuccess(record)
            }

            override fun onAdDismissed() {
                if (!isCurrent("onAdDismissed")) return
                if (record.state != FullscreenAdState.SHOWING) return
                if (record.disposed) {
                    // destroy() was requested while showing: release now.
                    record.state = FullscreenAdState.DISMISSED
                    releaseAdapter(record)
                    records.remove(record.adId)
                    return
                }
                if (!record.showConfirmed) {
                    // Dismissed without a showed callback: the presentation never happened, so
                    // this is a failed show (the SDK reports showed before dismissed for any ad
                    // that was presented, hence no reward can be lost here).
                    failShow(record, FullscreenErrorCodes.SHOW_FAILED, "The ad was dismissed before it was shown")
                    return
                }
                record.state = FullscreenAdState.DISMISSED
                // The SDK instance (and its listener) stays alive until destroy() / invalidate():
                // the SDK's callback path is weak and a reward may arrive after the dismissal.
                events.onAdDismissed(record.adId)
            }

            override fun onAdFailedToShow(message: String?) {
                if (!isCurrent("onAdFailedToShow")) return
                if (record.state != FullscreenAdState.SHOWING) return
                failShow(record, FullscreenErrorCodes.SHOW_FAILED, message ?: "Failed to show ad")
            }

            override fun onAdClicked() {
                if (!isCurrent("onAdClicked")) return
                if (record.disposed || !isPresented(record)) return
                events.onAdClicked(record.adId)
            }

            override fun onAdImpression() {
                if (!isCurrent("onAdImpression")) return
                if (record.disposed || !isPresented(record)) return
                events.onAdImpression(record.adId)
            }

            override fun onUserEarnedReward(type: String?, amount: Int?) {
                if (!isCurrent("onUserEarnedReward")) return
                if (record.disposed || !isPresented(record)) return
                if (type == null || amount == null) {
                    Logger.e("[FullscreenAdController] The SDK delivered no reward item; no reward event emitted")
                    return
                }
                if (record.rewardDelivered) {
                    Logger.e("[FullscreenAdController] Ignoring a second reward for the same ad")
                    return
                }
                record.rewardDelivered = true
                events.onUserEarnedReward(record.adId, type, amount)
            }
        }
    }

    // Callbacks queued around dismissal still route, hence DISMISSED counts as well.
    private fun isPresented(record: Record) =
        record.state == FullscreenAdState.SHOWING || record.state == FullscreenAdState.DISMISSED

    private fun onLoadTimeout(record: Record, session: Any) {
        if (records[record.adId] !== record || record.session !== session) return
        if (record.state != FullscreenAdState.LOADING) return
        failLoad(
            record,
            FullscreenErrorCodes.LOAD_TIMEOUT,
            "The ad did not finish loading within ${loadTimeoutMs / 1000} seconds"
        )
    }

    private fun failLoad(record: Record, code: String, message: String) {
        record.timeout?.cancel()
        record.timeout = null
        record.state = FullscreenAdState.FAILED
        releaseAdapter(record)
        if (!record.disposed) events.onAdFailedToLoad(record.adId, code, message)
        settleLoad(record, code, message)
    }

    private fun failShow(record: Record, code: String, message: String) {
        record.state = FullscreenAdState.FAILED
        releaseAdapter(record)
        if (record.disposed) {
            records.remove(record.adId)
            return
        }
        events.onAdFailedToShow(record.adId, code, message)
        settleShow(record, code, message)
    }

    private fun settleLoadSuccess(record: Record) {
        val settlement = record.loadSettlement ?: return
        record.loadSettlement = null
        settlement.resolve(Unit)
    }

    private fun settleLoad(record: Record, code: String, message: String) {
        val settlement = record.loadSettlement ?: return
        record.loadSettlement = null
        settlement.reject(code, message)
    }

    private fun settleShowSuccess(record: Record) {
        val settlement = record.showSettlement ?: return
        record.showSettlement = null
        settlement.resolve(Unit)
    }

    private fun settleShow(record: Record, code: String, message: String) {
        val settlement = record.showSettlement ?: return
        record.showSettlement = null
        settlement.reject(code, message)
    }

    /** Destroys the SDK instance exactly once. */
    private fun releaseAdapter(record: Record) {
        val adapter = record.adapter ?: return
        record.adapter = null
        try {
            adapter.destroy()
        } catch (e: Exception) {
            Logger.e("[FullscreenAdController] Error destroying ad: ${e.message}")
        }
    }

    private fun isAlive(activity: Activity?) =
        activity != null && !activity.isFinishing && !activity.isDestroyed

    /** Logs each event with its slot before forwarding it. Records are still registered here. */
    private inner class LoggingEvents(private val delegate: FullscreenAdEvents) : FullscreenAdEvents {
        private fun describe(adId: String) = "slot: ${records[adId]?.slotName ?: "?"}, adId: $adId"

        private fun info(event: String, adId: String) = Logger.i("$logTag $event - ${describe(adId)}")

        override fun onAdLoaded(adId: String) {
            info("onAdLoaded", adId)
            delegate.onAdLoaded(adId)
        }

        override fun onAdShowed(adId: String) {
            info("onAdShowed", adId)
            delegate.onAdShowed(adId)
        }

        override fun onAdDismissed(adId: String) {
            info("onAdDismissed", adId)
            delegate.onAdDismissed(adId)
        }

        override fun onAdClicked(adId: String) {
            info("onAdClicked", adId)
            delegate.onAdClicked(adId)
        }

        override fun onAdImpression(adId: String) {
            info("onAdImpression", adId)
            delegate.onAdImpression(adId)
        }

        override fun onAdFailedToLoad(adId: String, code: String, message: String) {
            Logger.e("$logTag onAdFailedToLoad - ${describe(adId)}, code: $code, message: $message")
            delegate.onAdFailedToLoad(adId, code, message)
        }

        override fun onAdFailedToShow(adId: String, code: String, message: String) {
            Logger.e("$logTag onAdFailedToShow - ${describe(adId)}, code: $code, message: $message")
            delegate.onAdFailedToShow(adId, code, message)
        }

        override fun onUserEarnedReward(adId: String, type: String, amount: Int) {
            Logger.i("$logTag onUserEarnedReward - ${describe(adId)}, reward: $amount $type")
            delegate.onUserEarnedReward(adId, type, amount)
        }
    }

    companion object {
        // The SDK fails silently (no callback) in some cases, e.g. a dead Activity.
        const val DEFAULT_LOAD_TIMEOUT_MS = 60_000L
    }
}
