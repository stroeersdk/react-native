package com.stroeer.rn

import android.app.Activity
import com.facebook.react.bridge.Dynamic
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.UIManagerHelper
import com.facebook.react.uimanager.ViewManagerDelegate
import com.facebook.react.viewmanagers.StroeerBannerViewManagerDelegate
import com.facebook.react.viewmanagers.StroeerBannerViewManagerInterface

/**
 * Fabric view manager of the banner. Fully prop driven: props only update the container's pending
 * config, which is committed once per transaction in [onAfterUpdateTransaction]; the container
 * decides when to load. See [StroeerBannerContainer].
 */
class StroeerBannerViewManager internal constructor(
    private val reactContext: ReactApplicationContext,
    private val adapterFactory: BannerSdkAdapterFactory
) : SimpleViewManager<StroeerBannerContainer>(),
    StroeerBannerViewManagerInterface<StroeerBannerContainer> {

    constructor(reactContext: ReactApplicationContext) : this(
        reactContext,
        BannerSdkAdapterFactory { activity: Activity -> StroeerBannerSdkAdapter(activity) }
    )

    private val bannerDelegate = StroeerBannerViewManagerDelegate<StroeerBannerContainer, StroeerBannerViewManager>(this)

    override fun getDelegate(): ViewManagerDelegate<StroeerBannerContainer> = bannerDelegate

    override fun getName(): String = NAME

    override fun createViewInstance(context: ThemedReactContext): StroeerBannerContainer {
        return StroeerBannerContainer(
            context,
            activityProvider = { reactContext.currentActivity },
            eventSink = { viewId, payload ->
                val dispatcher = UIManagerHelper.getEventDispatcherForReactTag(context, viewId)
                dispatcher?.dispatchEvent(
                    BannerEvent(UIManagerHelper.getSurfaceId(context), viewId, payload)
                )
            },
            adapterFactory = adapterFactory
        )
    }

    override fun setPublisherSlotName(view: StroeerBannerContainer, value: String?) {
        view.setSlotName(value)
    }

    override fun setContentUrl(view: StroeerBannerContainer, value: String?) {
        view.setContentUrl(value)
    }

    override fun setCustomTargeting(view: StroeerBannerContainer, value: Dynamic) {
        view.setCustomTargeting(parseCustomTargeting(value))
    }

    override fun onAfterUpdateTransaction(view: StroeerBannerContainer) {
        super.onAfterUpdateTransaction(view)
        view.commitConfig()
    }

    override fun getExportedCustomDirectEventTypeConstants(): MutableMap<String, Any> {
        val export = super.getExportedCustomDirectEventTypeConstants() ?: mutableMapOf()
        for (type in BannerEventType.values()) {
            export[type.eventName] = mapOf("registrationName" to type.registrationName)
        }
        return export
    }

    override fun onDropViewInstance(view: StroeerBannerContainer) {
        view.dispose()
        super.onDropViewInstance(view)
    }

    companion object {
        const val NAME = "StroeerBannerView"
    }
}
