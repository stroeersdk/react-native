import { forwardRef, useCallback, useMemo, useRef, useState } from 'react';
import { StroeerRewarded } from './StroeerRewarded';
import type { RewardItem, StroeerRewardedListeners } from './StroeerRewarded';
import { useFullscreenAd } from './fullscreen/useFullscreenAd';
import type { UseFullscreenAdResult } from './fullscreen/useFullscreenAd';
import { useFullscreenAdComponent } from './fullscreen/useFullscreenAdComponent';
import type { FullscreenAdRef } from './fullscreen/useFullscreenAdComponent';
import type { FullscreenAdHandle } from './fullscreen/types';

export type StroeerRewardedAdRef = FullscreenAdRef;

export interface UseStroeerRewardedResult extends UseFullscreenAdResult {
  /** The reward of the current ad; reset to null when a new ad is loaded or discarded. */
  reward: RewardItem | null;
}

export interface StroeerRewardedAdProps extends StroeerRewardedListeners {
  publisherSlotName: string;
  /** Load when mounted. Default false. */
  autoLoad?: boolean;
  /** Show as soon as the ad is loaded (once per slot / mount). Default false. */
  autoShow?: boolean;
}

/**
 * Subscribes the reward of every handle the shared hook creates. `reward` is reset whenever the
 * hook discards its ad (new load, destroy, slot change, unmount).
 */
function useRewardOptions(
  listeners: StroeerRewardedListeners | undefined,
  onRewardState?: (reward: RewardItem | null) => void
) {
  const listenersRef = useRef(listeners);
  listenersRef.current = listeners;
  const stateRef = useRef(onRewardState);
  stateRef.current = onRewardState;

  const subscribeExtra = useCallback(
    (handle: FullscreenAdHandle<StroeerRewardedListeners>) =>
      handle.subscribe({
        onUserEarnedReward: (reward) => {
          stateRef.current?.(reward);
          listenersRef.current?.onUserEarnedReward?.(reward);
        },
      }),
    []
  );
  const onReset = useCallback(() => stateRef.current?.(null), []);
  return { subscribeExtra, onReset };
}

/**
 * Rewarded state and controls for a slot. The hook owns its ad: `load()` always creates a fresh
 * one (a failed load is retried with a new ad), and the ad is destroyed on `destroy()`, slot
 * change and unmount. `load`, `show`, `isReady` and `destroy` keep their identity across renders.
 */
export function useStroeerRewarded(
  publisherSlotName: string,
  listeners?: StroeerRewardedListeners
): UseStroeerRewardedResult {
  const [reward, setReward] = useState<RewardItem | null>(null);
  const { subscribeExtra, onReset } = useRewardOptions(listeners, setReward);
  const ad = useFullscreenAd(StroeerRewarded, publisherSlotName, {
    listeners,
    subscribeExtra,
    onReset,
  });
  return { ...ad, reward };
}

/**
 * Headless rewarded component. Control it with a ref (`load`, `show`, `isReady`) and/or
 * `autoLoad` / `autoShow`. Renders nothing; unmounting destroys the ad.
 */
export const StroeerRewardedAd = forwardRef<
  StroeerRewardedAdRef,
  StroeerRewardedAdProps
>(function RewardedAdComponent(
  {
    publisherSlotName,
    autoLoad,
    autoShow,
    onAdLoaded,
    onAdFailedToLoad,
    onAdShowed,
    onAdDismissed,
    onAdFailedToShow,
    onAdClicked,
    onAdImpression,
    onUserEarnedReward,
  },
  ref
) {
  const listeners = useMemo<StroeerRewardedListeners>(
    () => ({
      onAdLoaded,
      onAdFailedToLoad,
      onAdShowed,
      onAdDismissed,
      onAdFailedToShow,
      onAdClicked,
      onAdImpression,
      onUserEarnedReward,
    }),
    [
      onAdLoaded,
      onAdFailedToLoad,
      onAdShowed,
      onAdDismissed,
      onAdFailedToShow,
      onAdClicked,
      onAdImpression,
      onUserEarnedReward,
    ]
  );
  const { subscribeExtra } = useRewardOptions(listeners);

  useFullscreenAdComponent(
    StroeerRewarded,
    publisherSlotName,
    ref,
    { autoLoad, autoShow },
    { listeners, subscribeExtra }
  );
  return null;
});
