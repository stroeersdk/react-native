import { getNativeStroeerConfiant } from './specs/NativeStroeerConfiantModule';
import type { Spec } from './specs/NativeStroeerConfiantModule';

function resolveModule(): Spec {
  try {
    return getNativeStroeerConfiant();
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw Object.assign(
      new Error(`The StroeerSDK Confiant module is not available: ${reason}`),
      { code: 'MODULE_UNAVAILABLE' }
    );
  }
}

export interface StroeerConfiantType {
  /**
   * Activates Confiant regardless of the remote configuration. Call it before `initialize`; a
   * later call is ignored. Throws an error with code `MODULE_UNAVAILABLE` when the native module
   * is missing.
   */
  enableTestMode(): void;
  /**
   * Resolves `true` when Confiant is running and `false` when it is not available or not
   * activated. Rejects with an error carrying `code`: `MODULE_UNAVAILABLE`, `INVALID_ARGUMENT`,
   * `ALREADY_INITIALIZING`, `INIT_TIMEOUT` or `INIT_FAILED`.
   */
  initialize(confiantPropertyId: string, enableReload: boolean): Promise<boolean>;
}

export const StroeerConfiant: StroeerConfiantType = {
  enableTestMode: () => {
    resolveModule().enableTestMode();
  },

  initialize: async (confiantPropertyId, enableReload) =>
    resolveModule().initialize(confiantPropertyId, enableReload),
};
