import { TurboModuleRegistry, NativeModules } from 'react-native';

interface NativeStroeerConsentModule {
  isAvailable(): Promise<boolean>;
  initialize(): Promise<boolean>;
  showConsent(): Promise<boolean>;
  showConsentWithLayout(layoutName: string): Promise<boolean>;
  clearConsent(): Promise<boolean>;
  showPrivacyManager(): Promise<boolean>;
  showPrivacyManagerWithLayout(layoutName: string): Promise<boolean>;
  getConsent(): Promise<string | null>;
  hasVendorConsent(vendorId: number): Promise<boolean>;
}

const NativeModule =
  (TurboModuleRegistry.get<any>('StroeerConsentModule') ?? NativeModules.StroeerConsentModule) as NativeStroeerConsentModule | undefined;

export interface StroeerConsentType {
  isAvailable(): Promise<boolean>;
  initialize(): Promise<boolean>;
  showConsent(layoutName?: string): Promise<boolean>;
  clearConsent(): Promise<boolean>;
  showPrivacyManager(layoutName?: string): Promise<boolean>;
  getConsent(): Promise<string | null>;
  hasVendorConsent(vendorId: number): Promise<boolean>;
}

export const StroeerConsentModule: StroeerConsentType = {
  isAvailable: async () => {
    if (!NativeModule) {
      return false;
    }
    try {
      return await NativeModule.isAvailable();
    } catch {
      return false;
    }
  },

  initialize: () => {
    if (!NativeModule) {
      return Promise.reject(new Error('StroeerConsentModule native module not found'));
    }
    return NativeModule.initialize();
  },

  showConsent: (layoutName?: string) => {
    if (!NativeModule) {
      return Promise.reject(new Error('StroeerConsentModule native module not found'));
    }
    if (layoutName) {
      return NativeModule.showConsentWithLayout(layoutName);
    }
    return NativeModule.showConsent();
  },

  clearConsent: () => {
    if (!NativeModule) {
      return Promise.reject(new Error('StroeerConsentModule native module not found'));
    }
    return NativeModule.clearConsent();
  },

  showPrivacyManager: (layoutName?: string) => {
    if (!NativeModule) {
      return Promise.reject(new Error('StroeerConsentModule native module not found'));
    }
    if (layoutName) {
      return NativeModule.showPrivacyManagerWithLayout(layoutName);
    }
    return NativeModule.showPrivacyManager();
  },

  getConsent: () => {
    if (!NativeModule) {
      return Promise.reject(new Error('StroeerConsentModule native module not found'));
    }
    return NativeModule.getConsent();
  },

  hasVendorConsent: (vendorId: number) => {
    if (!NativeModule) {
      return Promise.reject(new Error('StroeerConsentModule native module not found'));
    }
    return NativeModule.hasVendorConsent(vendorId);
  },
};
