import { getNativeStroeerSDK } from './specs/NativeStroeerSDKModule';
import type { Spec } from './specs/NativeStroeerSDKModule';

export interface SlotNames {
  bannerSlots: string[];
  interstitialSlots: string[];
}

/**
 * Global custom targeting: key to list of values.
 *
 * The key `user` carries user interests (GAM `user_keyword`, Prebid `user.data` "interests"); the
 * key `context` carries page context (GAM `context_keyword`, Prebid `app.content.data`). Any other
 * key is sent as-is to GAM and as Prebid `ext.data.<key>`. Keys are merged per key: setting one
 * key does not remove others. Values are trimmed and de-duplicated natively; keys whose values end
 * up empty are skipped.
 */
export type StroeerTargeting = Readonly<Record<string, ReadonlyArray<string>>>;

function unavailable(reason: string): Error {
  return Object.assign(
    new Error(`The StroeerSDK module is not available: ${reason}`),
    { code: 'MODULE_UNAVAILABLE' }
  );
}

function invalidArgument(message: string): Error {
  return Object.assign(new Error(message), { code: 'INVALID_ARGUMENT' });
}

function resolveModule(): Spec {
  try {
    return getNativeStroeerSDK();
  } catch (error) {
    throw unavailable(error instanceof Error ? error.message : String(error));
  }
}

// Promise methods must reject, not throw synchronously.
function callAsync<T>(call: (module: Spec) => Promise<T>): Promise<T> {
  try {
    return call(resolveModule());
  } catch (error) {
    return Promise.reject(error);
  }
}

function validateTargeting(targeting: unknown): void {
  if (
    typeof targeting !== 'object' ||
    targeting === null ||
    Array.isArray(targeting)
  ) {
    throw invalidArgument('targeting must be a plain object');
  }
  for (const [key, values] of Object.entries(targeting)) {
    if (key.length === 0) {
      throw invalidArgument('targeting keys must be non-empty');
    }
    if (
      !Array.isArray(values) ||
      !values.every((value) => typeof value === 'string')
    ) {
      throw invalidArgument(
        `targeting values for key "${key}" must be an array of strings`
      );
    }
  }
}

export interface StroeerSDKType {
  /**
   * Starts the SDK setup. Rejects with INVALID_ARGUMENT for a blank name and SDK_ERROR when the
   * SDK throws. Resolves once setup has started, not once the configuration is loaded.
   */
  setApplicationName(applicationName: string): Promise<void>;
  /**
   * Resets the SDK configuration, applies the application name and waits for the configuration.
   * Disruptive: do not run while ads are loading or showing. Calls are serialized. Rejects with
   * CONFIG_NOT_LOADED when the configuration could not be loaded.
   */
  resetAndLoadConfiguration(applicationName: string): Promise<SlotNames>;
  /**
   * Discards the cached configuration and requests a refresh. Resolves when the refresh has been
   * requested, not when it finished. Does not touch consent data.
   */
  clearConfigurationCache(): Promise<void>;
  /** Rejects with CONFIG_NOT_LOADED when the configuration is not loaded. */
  getSlotNames(): Promise<SlotNames>;
  /** Resolves null when the configuration is not loaded. */
  getConfiguration(): Promise<string | null>;
  /**
   * Sets the URL of the content the ad is displayed alongside, used for contextual targeting and
   * brand safety.
   *
   * On iOS this requires `setApplicationName` to have been called first — the URL is written to
   * the Yieldlove instance's ad request, and is dropped with a warning if that instance does not
   * exist yet.
   */
  setContentUrl(url: string): void;
  /** Throws INVALID_ARGUMENT for malformed input. See {@link StroeerTargeting}. */
  setGlobalCustomTargeting(targeting: StroeerTargeting): void;
  disableErrorLog(disable: boolean): void;
  enableTestForIOCampaigns(enable: boolean): void;
  forcePrebidRendering(enable: boolean): void;
  enableDebugMode(): void;
  enableInspectionMode(): void;
}

/**
 * Every method throws (void methods) or rejects (Promise methods) with code `MODULE_UNAVAILABLE`
 * when the native module is missing.
 */
export const StroeerSDK: StroeerSDKType = {
  setApplicationName: (applicationName) =>
    callAsync((m) => m.setApplicationName(applicationName)),
  resetAndLoadConfiguration: (applicationName) =>
    callAsync((m) => m.resetAndLoadConfiguration(applicationName)),
  clearConfigurationCache: () => callAsync((m) => m.clearConfigurationCache()),
  getSlotNames: () => callAsync((m) => m.getSlotNames()),
  getConfiguration: () => callAsync((m) => m.getConfiguration()),
  setContentUrl: (url) => resolveModule().setContentUrl(url),
  setGlobalCustomTargeting: (targeting) => {
    const module = resolveModule();
    validateTargeting(targeting);
    module.setGlobalCustomTargeting(targeting);
  },
  disableErrorLog: (disable) => resolveModule().disableErrorLog(disable),
  enableTestForIOCampaigns: (enable) =>
    resolveModule().enableTestForIOCampaigns(enable),
  forcePrebidRendering: (enable) =>
    resolveModule().forcePrebidRendering(enable),
  enableDebugMode: () => resolveModule().enableDebugMode(),
  enableInspectionMode: () => resolveModule().enableInspectionMode(),
};
