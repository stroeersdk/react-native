import { useCallback, useEffect, useRef, useState } from 'react';
import type {
  AdError,
  AdStatus,
  FullscreenAdFactory,
  FullscreenAdHandle,
  FullscreenAdListeners,
  Subscription,
} from './types';

export interface UseFullscreenAdOptions<L extends FullscreenAdListeners> {
  /** Called for the events of the current ad. The latest object is always used. */
  listeners?: L;
  /**
   * Called for every handle the hook creates, to add format specific subscriptions (e.g. the
   * reward of rewarded ads). The returned subscription is removed together with the handle.
   */
  subscribeExtra?: (handle: FullscreenAdHandle<L>) => Subscription;
  /** Called when the hook discards its ad (new load, destroy, slot change, unmount). */
  onReset?: () => void;
}

export interface UseFullscreenAdResult {
  status: AdStatus;
  isLoading: boolean;
  isLoaded: boolean;
  /** Id and slot of the current ad (set once its handle exists), null otherwise. */
  adId: string | null;
  adSlot: string | null;
  /** The error of the last failed operation; cleared when a new load starts. */
  error: AdError | null;
  /** Creates a fresh ad and loads it. Rejects while loading or showing. */
  load(): Promise<void>;
  /**
   * Shows the loaded ad. Rejects unless `status` is `loaded`. Rejects with `APP_IN_BACKGROUND`
   * while the app is in the background: `onAdFailedToShow` is called and `error` set, but
   * `status` returns to `loaded` so the ad can be shown once the app is resumed.
   */
  show(): Promise<void>;
  isReady(): Promise<boolean>;
  /** Discards the current ad and resets to `idle`. */
  destroy(): Promise<void>;
}

function errorOf(code: string, message: string): AdError & Error {
  return Object.assign(new Error(message), { code });
}

function toAdError(error: unknown): AdError {
  const { code, message } = (error ?? {}) as Partial<AdError>;
  return {
    code: typeof code === 'string' ? code : 'UNKNOWN',
    message: typeof message === 'string' ? message : String(error),
  };
}

/**
 * Shared hook of the full screen formats. It owns one ad handle at a time: `load()` creates a
 * fresh handle (destroying the previous one), `destroy()`, a slot change and unmount destroy it.
 * All native work happens in callbacks and effects, never during render.
 */
export function useFullscreenAd<L extends FullscreenAdListeners>(
  factory: FullscreenAdFactory<L>,
  publisherSlotName: string,
  options: UseFullscreenAdOptions<L> = {}
): UseFullscreenAdResult {
  const [status, setStatusState] = useState<AdStatus>('idle');
  const [error, setError] = useState<AdError | null>(null);
  const [ad, setAd] = useState<{ adId: string; slot: string } | null>(null);

  const statusRef = useRef<AdStatus>('idle');
  const slotRef = useRef(publisherSlotName);
  const optionsRef = useRef(options);
  const currentRef = useRef<{
    handle: FullscreenAdHandle<L>;
    subscription: Subscription;
  } | null>(null);
  // Bumped whenever the current ad is discarded: results of older operations are ignored.
  const generationRef = useRef(0);
  // Whether the failure of the running show() was already delivered by a native event.
  const showReportedRef = useRef(false);

  useEffect(() => {
    optionsRef.current = options;
  });

  const setStatus = useCallback((next: AdStatus) => {
    statusRef.current = next;
    setStatusState(next);
  }, []);
  // Reads through a function so TypeScript does not narrow the ref across awaits.
  const currentStatus = useCallback((): AdStatus => statusRef.current, []);

  const discard = useCallback(() => {
    generationRef.current += 1;
    setAd(null);
    const current = currentRef.current;
    currentRef.current = null;
    optionsRef.current.onReset?.();
    if (!current) return Promise.resolve();
    current.subscription.remove();
    return current.handle.destroy().catch(() => {});
  }, []);

  // A different slot is a different ad; unmount discards the ad. Also keeps StrictMode's
  // mount / unmount / mount cycle harmless: nothing native exists before load().
  useEffect(() => {
    slotRef.current = publisherSlotName;
    return () => {
      setStatus('idle');
      setError(null);
      discard();
    };
  }, [publisherSlotName, discard, setStatus]);

  const load = useCallback(async () => {
    if (currentStatus() === 'loading' || currentStatus() === 'showing') {
      throw errorOf('INVALID_STATE', `Cannot load while the ad is ${currentStatus()}`);
    }
    discard();
    const generation = generationRef.current;
    setError(null);
    setStatus('loading');

    const isStale = () => generation !== generationRef.current;
    // Failures of operations that never reached the native module, or that it rejected without
    // an event (create, preconditions), are delivered through onAdFailedToLoad as well; a
    // failure already delivered by a native event is not repeated.
    let loadReported = false;
    try {
      const handle = await factory.create(slotRef.current);
      if (isStale()) {
        // Unmounted, destroyed or reloaded while the handle was being created.
        handle.destroy().catch(() => {});
        throw errorOf('DESTROYED', 'The ad was discarded before it finished loading');
      }

      const forward = (
        key: keyof FullscreenAdListeners,
        ...args: unknown[]
      ) => {
        const listener = optionsRef.current.listeners?.[key] as
          | ((...a: unknown[]) => void)
          | undefined;
        listener?.(...args);
      };
      const internal = handle.subscribe({
        onAdLoaded: () => {
          if (isStale()) return;
          setStatus('loaded');
          forward('onAdLoaded');
        },
        onAdFailedToLoad: (e: AdError) => {
          if (isStale()) return;
          loadReported = true;
          setError(e);
          setStatus('failed');
          forward('onAdFailedToLoad', e);
        },
        onAdShowed: () => {
          if (isStale()) return;
          setStatus('showing');
          forward('onAdShowed');
        },
        onAdDismissed: () => {
          if (isStale()) return;
          setStatus('dismissed');
          forward('onAdDismissed');
        },
        onAdFailedToShow: (e: AdError) => {
          if (isStale()) return;
          setError(e);
          setStatus('failed');
          // The rejected show() may have reported the same failure first.
          if (showReportedRef.current) return;
          showReportedRef.current = true;
          forward('onAdFailedToShow', e);
        },
        onAdClicked: () => {
          if (!isStale()) forward('onAdClicked');
        },
        onAdImpression: () => {
          if (!isStale()) forward('onAdImpression');
        },
      } as L);
      setAd({ adId: handle.adId, slot: handle.publisherSlotName });
      const extra = optionsRef.current.subscribeExtra?.(handle);
      currentRef.current = {
        handle,
        subscription: {
          remove() {
            internal.remove();
            extra?.remove();
          },
        },
      };

      await handle.load();
    } catch (e) {
      // A superseded operation (slot change, unmount, destroy, reload) is a cancellation, not a
      // failure.
      if (!isStale() && currentStatus() === 'loading') {
        const adError = toAdError(e);
        setError(adError);
        setStatus('failed');
        if (!loadReported) {
          optionsRef.current.listeners?.onAdFailedToLoad?.(adError);
        }
      }
      throw e;
    }
  }, [factory, discard, setStatus, currentStatus]);

  const show = useCallback(async () => {
    const current = currentRef.current;
    if (!current || currentStatus() !== 'loaded') {
      throw errorOf('NOT_READY', 'The ad is not loaded');
    }
    const generation = generationRef.current;
    showReportedRef.current = false;
    // Moves to `showing` right away so a second show() or a load() is rejected.
    setStatus('showing');
    try {
      await current.handle.show();
    } catch (e) {
      // Reported once, whether the native event or this rejection arrives first (and even if a
      // dismissal event already moved the status on); a discarded ad is not a failure.
      if (generation === generationRef.current && !showReportedRef.current) {
        showReportedRef.current = true;
        const adError = toAdError(e);
        setError(adError);
        // The app being in the background does not consume the ad: it can still be shown later.
        setStatus(adError.code === 'APP_IN_BACKGROUND' ? 'loaded' : 'failed');
        optionsRef.current.listeners?.onAdFailedToShow?.(adError);
      }
      throw e;
    }
  }, [setStatus, currentStatus]);

  const isReady = useCallback(async () => {
    const current = currentRef.current;
    return current ? current.handle.isReady() : false;
  }, []);

  const destroy = useCallback(async () => {
    setStatus('idle');
    setError(null);
    await discard();
  }, [discard, setStatus]);

  return {
    status,
    adId: ad?.adId ?? null,
    adSlot: ad?.slot ?? null,
    isLoading: status === 'loading',
    isLoaded: status === 'loaded',
    error,
    load,
    show,
    isReady,
    destroy,
  };
}
