import { useEffect, useImperativeHandle, useRef } from 'react';
import type { Ref } from 'react';
import { useFullscreenAd } from './useFullscreenAd';
import type { UseFullscreenAdOptions } from './useFullscreenAd';
import type {
  AdStatus,
  FullscreenAdFactory,
  FullscreenAdListeners,
} from './types';

/** Imperative API of the headless ad components. */
export interface FullscreenAdRef {
  load(): Promise<void>;
  show(): Promise<void>;
  isReady(): Promise<boolean>;
}

export interface FullscreenAdComponentOptions {
  /** Load when mounted (and when `publisherSlotName` changes). Default false. */
  autoLoad?: boolean;
  /**
   * Show as soon as the ad is loaded; once per slot / mount. Default false. If the app is in the
   * background at that moment the attempt fails with `APP_IN_BACKGROUND` and is not retried on
   * resume (no surprise ad); call `show()` yourself.
   */
  autoShow?: boolean;
}

/**
 * Shared implementation of the headless ad components (a component only calls this and renders
 * `null`). Built on {@link useFullscreenAd}; callback identity changes never reload.
 */
export function useFullscreenAdComponent<L extends FullscreenAdListeners>(
  factory: FullscreenAdFactory<L>,
  publisherSlotName: string,
  ref: Ref<FullscreenAdRef> | undefined,
  { autoLoad = false, autoShow = false }: FullscreenAdComponentOptions,
  hookOptions: UseFullscreenAdOptions<L>
) {
  const ad = useFullscreenAd(factory, publisherSlotName, hookOptions);
  const { load, show, isReady, status } = ad;

  useImperativeHandle(ref, () => ({ load, show, isReady }), [
    load,
    show,
    isReady,
  ]);

  // Auto operations consume their rejections: the hook already delivers every failure through
  // `onAdFailedToLoad` / `onAdFailedToShow` (deduplicated against native events) and `error`, and
  // does not report superseded operations.
  useEffect(() => {
    if (autoLoad) load().catch(() => {});
  }, [autoLoad, load, publisherSlotName]);

  // The ad id an auto show was attempted for: at most one attempt per ad.
  const autoShownAdIdRef = useRef<string | null>(null);
  const { adId, adSlot } = ad;
  useEffect(() => {
    if (
      shouldAutoShow({
        autoShow,
        status,
        adId,
        adSlot,
        publisherSlotName,
        lastAutoShownAdId: autoShownAdIdRef.current,
      })
    ) {
      autoShownAdIdRef.current = adId;
      show().catch(() => {});
    }
  }, [autoShow, status, adId, adSlot, publisherSlotName, show]);

  return ad;
}

export interface AutoShowInput {
  autoShow: boolean;
  status: AdStatus;
  adId: string | null;
  adSlot: string | null;
  publisherSlotName: string;
  lastAutoShownAdId: string | null;
}

/**
 * Whether an auto show should start now: only for a loaded ad that belongs to the CURRENT slot
 * (a render right after a slot change still carries the previous ad's status), and once per ad.
 */
export function shouldAutoShow(input: AutoShowInput): boolean {
  return (
    input.autoShow &&
    input.status === 'loaded' &&
    input.adId !== null &&
    input.adSlot === input.publisherSlotName &&
    input.adId !== input.lastAutoShownAdId
  );
}
