import type {
  FullscreenAdFactory,
  FullscreenAdHandle,
  FullscreenAdListeners,
  FullscreenNativeSpec,
  NativeAdErrorEvent,
  NativeAdEvent,
  NativeEmitter,
  Subscription,
} from './types';

/**
 * An additional native event of a format (e.g. the rewarded `onUserEarnedReward`): which
 * emitter to listen to and how to hand its payload to one set of listeners.
 */
export interface ExtraRoute<
  L extends FullscreenAdListeners,
  S extends FullscreenNativeSpec,
  E extends { adId: string },
> {
  /** Picks the emitter from the (lazily resolved) native module. */
  emitter(spec: S): NativeEmitter<E>;
  dispatch(listeners: L, event: E): void;
}

/** Type-erased route as stored by the factory. */
type AnyRoute<L extends FullscreenAdListeners, S extends FullscreenNativeSpec> = ExtraRoute<L, S, any>;

/**
 * Builds the `create()` factory of a full screen format on top of its TurboModule spec.
 *
 * The native module is resolved and its emitters are subscribed once, lazily on the first
 * `create()` (a missing module rejects that promise; importing never throws), and route every
 * event to the listeners registered for its `adId`. A throwing listener never breaks routing.
 */
export function createFullscreenAdFactory<
  L extends FullscreenAdListeners,
  S extends FullscreenNativeSpec = FullscreenNativeSpec,
>(
  getSpec: () => S,
  extraRoutes: ReadonlyArray<AnyRoute<L, S>> = []
): FullscreenAdFactory<L> {
  const listenersByAd = new Map<string, Set<L>>();
  let installed = false;

  function dispatchTo(adId: string, call: (listeners: L) => void) {
    const set = listenersByAd.get(adId);
    if (!set) return;
    // Copy: a listener may remove itself or others while being called.
    for (const listeners of Array.from(set)) {
      if (!set.has(listeners)) continue;
      try {
        call(listeners);
      } catch (error) {
        console.error('[StroeerSDK] An ad listener threw an error', error);
      }
    }
  }

  function install(spec: S) {
    if (installed) return;
    installed = true;

    const simple = (
      emitter: NativeEmitter<NativeAdEvent>,
      call: (listeners: L) => void
    ) => emitter((event) => dispatchTo(event.adId, call));
    const failure = (
      emitter: NativeEmitter<NativeAdErrorEvent>,
      pick: (listeners: L) => ((error: NativeAdErrorEvent['error']) => void) | undefined
    ) =>
      emitter((event) =>
        dispatchTo(event.adId, (listeners) => pick(listeners)?.(event.error))
      );

    simple(spec.onAdLoaded, (l) => l.onAdLoaded?.());
    simple(spec.onAdShowed, (l) => l.onAdShowed?.());
    simple(spec.onAdDismissed, (l) => l.onAdDismissed?.());
    simple(spec.onAdClicked, (l) => l.onAdClicked?.());
    simple(spec.onAdImpression, (l) => l.onAdImpression?.());
    failure(spec.onAdFailedToLoad, (l) => l.onAdFailedToLoad);
    failure(spec.onAdFailedToShow, (l) => l.onAdFailedToShow);
    for (const route of extraRoutes) {
      route.emitter(spec)((event) =>
        dispatchTo(event.adId, (listeners) => route.dispatch(listeners, event))
      );
    }
  }

  return {
    async create(publisherSlotName: string): Promise<FullscreenAdHandle<L>> {
      let spec: S;
      try {
        spec = getSpec();
        install(spec);
      } catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        throw Object.assign(
          new Error(`The StroeerSDK native ad module is not available: ${reason}`),
          { code: 'MODULE_UNAVAILABLE' }
        );
      }
      const adId = await spec.createAd(publisherSlotName);
      let destroyed = false;

      const handle: FullscreenAdHandle<L> = {
        adId,
        publisherSlotName,
        load: () => spec.load(adId),
        show: () => spec.show(adId),
        isReady: () => spec.isReady(adId),
        async destroy() {
          if (!destroyed) {
            destroyed = true;
            // Clear, not just unmap: a dispatch in progress iterates over a copy and checks
            // membership in this set, so the remaining listeners must not be called.
            listenersByAd.get(adId)?.clear();
            listenersByAd.delete(adId);
          }
          await spec.destroy(adId);
        },
        subscribe(listeners: L): Subscription {
          if (destroyed) return { remove() {} };
          let set = listenersByAd.get(adId);
          if (!set) {
            set = new Set();
            listenersByAd.set(adId, set);
          }
          // Wrap, so subscribing the same object twice stays two independent subscriptions.
          const entry = { ...listeners } as L;
          set.add(entry);
          return {
            remove() {
              set.delete(entry);
              if (set.size === 0 && listenersByAd.get(adId) === set) {
                listenersByAd.delete(adId);
              }
            },
          };
        },
      };
      return handle;
    },
  };
}
