import { getNativeStroeerIdentity } from './specs/NativeStroeerIdentityModule';
import type {
  NativeIdentityCustomInfo,
  Spec,
} from './specs/NativeStroeerIdentityModule';

/** Custom identity information handed to the identity provider. Every field is optional. */
export type StroeerIdentityCustomInfo = NativeIdentityCustomInfo;

function resolveModule(): Spec {
  try {
    return getNativeStroeerIdentity();
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw Object.assign(
      new Error(`The StroeerSDK identity module is not available: ${reason}`),
      { code: 'MODULE_UNAVAILABLE' }
    );
  }
}

export interface StroeerIdentityType {
  /**
   * Each call hands a fresh, complete info object to the SDK atomically. At the ID5 provider
   * level fields are only ever set, never cleared: omitted fields keep previously applied values
   * and there is currently no way to remove applied identity data (that needs an SDK reset API).
   * Throws an error with code `MODULE_UNAVAILABLE` when the native module is missing.
   */
  setCustomInfo(info: StroeerIdentityCustomInfo): void;
}

export const StroeerIdentity: StroeerIdentityType = {
  setCustomInfo: (info) => {
    resolveModule().setCustomInfo(info);
  },
};
