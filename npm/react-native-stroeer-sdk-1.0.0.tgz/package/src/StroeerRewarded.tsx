import {
  getNativeStroeerRewarded,
  type Spec as NativeRewardedSpec,
  type NativeRewardedRewardEvent,
} from './specs/NativeStroeerRewardedModule';
import { createFullscreenAdFactory } from './fullscreen/createAdHandle';
import type {
  FullscreenAdFactory,
  FullscreenAdHandle,
  FullscreenAdListeners,
} from './fullscreen/types';

/** Reward granted by the ad network once the user earned it. */
export interface RewardItem {
  type: string;
  amount: number;
}

export interface StroeerRewardedListeners extends FullscreenAdListeners {
  /**
   * The user earned the reward. Delivered at most once per ad, independent of the `show()`
   * promise, and possibly after `onAdDismissed` while the handle is not destroyed. An ad that
   * reports no reward item delivers no event.
   */
  onUserEarnedReward?: (reward: RewardItem) => void;
}

/** One-shot rewarded ad: load once, show once, then `destroy()`. */
export type StroeerRewardedHandle = FullscreenAdHandle<StroeerRewardedListeners>;

/**
 * Low-level rewarded API. Every ad is a handle:
 *
 * ```ts
 * const ad = await StroeerRewarded.create('slot');
 * const sub = ad.subscribe({ onUserEarnedReward: (reward) => {} });
 * await ad.load();
 * await ad.show(); // resolves when the ad is presented, before any reward
 * // Later, when the owner (e.g. the screen) goes away:
 * sub.remove();
 * await ad.destroy();
 * ```
 *
 * Handles are not garbage collected natively: always call `destroy()` when done (the hook and
 * component do this for you). Keep the handle and its subscription alive until the owner goes
 * away, not just until `show()` resolves or the ad is dismissed: the reward can be delivered
 * after either, and nothing is delivered after `destroy()`. A failed load needs a NEW handle to
 * retry.
 *
 * Failed operations reject with an error carrying `code` and `message` (see `AdError`).
 */
export const StroeerRewarded: FullscreenAdFactory<StroeerRewardedListeners> =
  createFullscreenAdFactory<StroeerRewardedListeners, NativeRewardedSpec>(
    getNativeStroeerRewarded,
    [
      {
        emitter: (spec) => spec.onUserEarnedReward,
        dispatch: (listeners, event: NativeRewardedRewardEvent) =>
          listeners.onUserEarnedReward?.({
            type: event.reward.type,
            amount: event.reward.amount,
          }),
      },
    ]
  );
