import { getNativeStroeerInterstitial } from './specs/NativeStroeerInterstitialModule';
import { createFullscreenAdFactory } from './fullscreen/createAdHandle';
import type {
  FullscreenAdFactory,
  FullscreenAdHandle,
  FullscreenAdListeners,
} from './fullscreen/types';

export type StroeerInterstitialListeners = FullscreenAdListeners;

/** One-shot interstitial: load once, show once, then `destroy()`. */
export type StroeerInterstitialHandle =
  FullscreenAdHandle<StroeerInterstitialListeners>;

/**
 * Low-level interstitial API. Every ad is a handle:
 *
 * ```ts
 * const ad = await StroeerInterstitial.create('slot');
 * const sub = ad.subscribe({ onAdDismissed: () => {} });
 * await ad.load();
 * await ad.show();
 * sub.remove();
 * await ad.destroy();
 * ```
 *
 * Handles are not garbage collected natively: always call `destroy()` when done (the hook and
 * component do this for you). A dismissed ad keeps its native instance until then.
 *
 * Failed operations reject with an error carrying `code` and `message` (see `AdError`).
 */
export const StroeerInterstitial: FullscreenAdFactory<StroeerInterstitialListeners> =
  createFullscreenAdFactory<StroeerInterstitialListeners>(
    getNativeStroeerInterstitial
  );
