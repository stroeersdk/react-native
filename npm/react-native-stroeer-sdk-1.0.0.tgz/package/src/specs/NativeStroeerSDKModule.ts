import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

// Defined here: codegen resolves the type from this file.
export type NativeSlotNames = Readonly<{
  bannerSlots: string[];
  interstitialSlots: string[];
}>;

/**
 * Promise methods reject with {code, message}: INVALID_ARGUMENT, SDK_ERROR, CONFIG_NOT_LOADED,
 * MODULE_INVALIDATED. Void methods never throw natively; failures are logged.
 */
export interface Spec extends TurboModule {
  /** Resolves once the SDK setup has started (not once the configuration is loaded). */
  setApplicationName(applicationName: string): Promise<void>;
  /**
   * Disruptive: resets the SDK configuration, applies the application name and waits for the
   * configuration. Do not run while ads are loading or showing. Calls are serialized.
   */
  resetAndLoadConfiguration(applicationName: string): Promise<NativeSlotNames>;
  /** Resolves when the refresh has been REQUESTED, not when it completed. Never touches consent. */
  clearConfigurationCache(): Promise<void>;
  getSlotNames(): Promise<NativeSlotNames>;
  /** Resolves null when the configuration is not loaded. */
  getConfiguration(): Promise<string | null>;
  setContentUrl(url: string): void;
  /** Keys map to string arrays; the keys "user" and "context" have special meaning. */
  setGlobalCustomTargeting(targeting: Object): void;
  disableErrorLog(disable: boolean): void;
  enableTestForIOCampaigns(enable: boolean): void;
  forcePrebidRendering(enable: boolean): void;
  enableDebugMode(): void;
  enableInspectionMode(): void;
}

// Lazy on purpose: importing the package must never throw when the module is missing.
// The failure surfaces on first use.
export function getNativeStroeerSDK(): Spec {
  return TurboModuleRegistry.getEnforcing<Spec>('StroeerSDK');
}
