import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

// Defined here: codegen resolves the type from this file.
export type NativeIdentityCustomInfo = Readonly<{
  email?: string;
  phone?: string;
  puid?: string;
  regionCode?: string;
  cityCode?: string;
}>;

export interface Spec extends TurboModule {
  /**
   * Hands a fresh custom info object to the SDK atomically. Omitted fields are null in that
   * object, but the SDK's ID5 provider only sets fields and never clears them.
   */
  setCustomInfo(info: NativeIdentityCustomInfo): void;
}

// Lazy on purpose: importing the package must never throw when the module is missing (e.g. a
// platform where it is not implemented yet). The failure surfaces on first use.
export function getNativeStroeerIdentity(): Spec {
  return TurboModuleRegistry.getEnforcing<Spec>('StroeerIdentityModule');
}
