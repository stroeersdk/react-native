import type { ViewProps, HostComponent } from 'react-native';
import { codegenNativeComponent } from 'react-native';
import type {
  DirectEventHandler,
  Double,
  UnsafeMixed,
} from 'react-native/Libraries/Types/CodegenTypes';

// Codegen requires explicit numeric types in event payloads; bare `number`
// fails schema generation.
export type NativeBannerLoadedEvent = Readonly<{
  publisherSlotName: string;
  width: Double;
  height: Double;
  source: string;
}>;

export type NativeBannerFailedToLoadEvent = Readonly<{
  publisherSlotName: string;
  error: Readonly<{
    code: string;
    message: string;
  }>;
}>;

export type NativeBannerSlotEvent = Readonly<{
  publisherSlotName: string;
}>;

export interface NativeProps extends ViewProps {
  publisherSlotName: string;
  contentUrl?: string;
  // Codegen has no prop type for an open-ended string map, so this is declared
  // as UnsafeMixed (folly::dynamic in C++, Dynamic in Java, id in ObjC). It must
  // be declared here regardless: props missing from the spec are stripped by the
  // generated ComponentDescriptor and never reach the native view manager.
  customTargeting?: UnsafeMixed;
  onAdLoaded?: DirectEventHandler<NativeBannerLoadedEvent>;
  onAdImpression?: DirectEventHandler<NativeBannerLoadedEvent>;
  onAdFailedToLoad?: DirectEventHandler<NativeBannerFailedToLoadEvent>;
  onAdOpened?: DirectEventHandler<NativeBannerSlotEvent>;
  onAdClosed?: DirectEventHandler<NativeBannerSlotEvent>;
  onAdClicked?: DirectEventHandler<NativeBannerSlotEvent>;
}

export default codegenNativeComponent<NativeProps>(
  'StroeerBannerView'
) as HostComponent<NativeProps>;
