import type { TurboModule } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

export interface Spec extends TurboModule {
  /**
   * Activates the Confiant module regardless of the remote configuration. Must be called before
   * `initialize`: once initialization was requested the SDK has already captured its mode, so a
   * later call is ignored (and logged natively).
   */
  enableTestMode(): void;
  /**
   * Initializes Confiant monitoring. Resolves with the SDK's own result: `true` when Confiant is
   * running, `false` when it is not (module not activated remotely, Confiant SDK/plugin not on
   * the classpath, invalid configuration, ...). Absence is a normal state, not an error.
   *
   * The first SDK result is cached: later calls resolve it immediately (a failed result is not
   * retried for the life of the process). The SDK only reports a boolean and gives no callback
   * when asked again after a permanent failure, so a retryable failure (e.g. remote
   * configuration not loaded yet) cannot be told apart and is not retried either: call this
   * after the SDK has loaded its configuration. Rejects with {code, message}: INVALID_ARGUMENT (blank property id),
   * ALREADY_INITIALIZING (the SDK attempt has not reported yet, even if an earlier call timed
   * out), INIT_TIMEOUT (the SDK never reported back) or INIT_FAILED
   * (the SDK threw). The promise settles exactly once.
   */
  initialize(
    confiantPropertyId: string,
    enableReload: boolean
  ): Promise<boolean>;
}

// Lazy on purpose: importing the package must never throw when the module is missing (e.g. a
// platform where it is not implemented yet). The failure surfaces on first use.
export function getNativeStroeerConfiant(): Spec {
  return TurboModuleRegistry.getEnforcing<Spec>('StroeerConfiantModule');
}
