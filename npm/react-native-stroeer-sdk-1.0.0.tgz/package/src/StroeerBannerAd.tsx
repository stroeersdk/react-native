import React, { useMemo, useState } from 'react';
import type { ViewProps } from 'react-native';
import NativeStroeerBannerView from './specs/StroeerBannerViewNativeComponent';
import type {
  NativeBannerFailedToLoadEvent,
  NativeBannerLoadedEvent,
} from './specs/StroeerBannerViewNativeComponent';

/** Payload of `onAdLoaded` and `onAdImpression`. Sizes are in dp. */
export interface StroeerBannerLoadedEvent {
  width: number;
  height: number;
  publisherSlotName: string;
  source: string;
}

/** Error reported by `onAdFailedToLoad`. */
export interface StroeerBannerError {
  /**
   * `INVALID_ARGUMENT`, `SETUP_FAILED` or `LOAD_FAILED`. A missing Activity is not an error: the
   * banner waits and loads once one is available.
   */
  code: string;
  message: string;
}

export interface StroeerBannerAdListeners {
  onAdLoaded?: (event: StroeerBannerLoadedEvent) => void;
  /**
   * Also called when an automatic refresh fails; the previous creative stays visible then.
   */
  onAdFailedToLoad?: (error: StroeerBannerError) => void;
  onAdOpened?: () => void;
  onAdClosed?: () => void;
  onAdClicked?: () => void;
  /** Called for every impression, including those of automatic refreshes. */
  onAdImpression?: (event: StroeerBannerLoadedEvent) => void;
}

export interface StroeerBannerAdProps
  extends ViewProps,
    StroeerBannerAdListeners {
  publisherSlotName: string;
  contentUrl?: string;
  customTargeting?: Readonly<Record<string, string>>;
}

type BannerSize = { width: number; height: number };

function isUsableSize(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0;
}

/**
 * Banner ad view. It is purely prop driven: a banner loads when the component is mounted and
 * again whenever `publisherSlotName`, `contentUrl` or `customTargeting` change in value
 * (targeting is compared by content, so passing a new but equal object does not reload).
 *
 * A config change remounts the native view: the old native banner is destroyed, a new one loads,
 * and the auto-size state starts fresh, so events of the previous config can never apply to the
 * new one. There is no imperative reload; to force a fresh load for an unchanged config, change
 * the React `key` of this component. Unmounting destroys the banner.
 *
 * The view resizes itself to the size of the loaded creative.
 */
export function StroeerBannerAd(props: StroeerBannerAdProps) {
  const { publisherSlotName, contentUrl, customTargeting } = props;

  // Semantic identity of the native config (targeting by sorted entries).
  const configKey = useMemo(() => {
    const entries = Object.entries(customTargeting ?? {}).sort(([a], [b]) =>
      a < b ? -1 : a > b ? 1 : 0
    );
    return JSON.stringify([publisherSlotName, contentUrl ?? '', entries]);
  }, [publisherSlotName, contentUrl, customTargeting]);

  return <StroeerBannerAdInner key={configKey} {...props} />;
}

function StroeerBannerAdInner(props: StroeerBannerAdProps) {
  const {
    publisherSlotName,
    contentUrl,
    customTargeting,
    onAdLoaded,
    onAdFailedToLoad,
    onAdOpened,
    onAdClosed,
    onAdClicked,
    onAdImpression,
    style,
    ...viewProps
  } = props;

  const [bannerSize, setBannerSize] = useState<BannerSize | null>(null);

  // Applies a size reported by the native side. Bails out when the size is unchanged so that
  // repeated impression events don't trigger redundant re-renders, and ignores non-finite or
  // non-positive sizes (they must not collapse the view).
  const updateBannerSize = (width: unknown, height: unknown) => {
    if (!isUsableSize(width) || !isUsableSize(height)) {
      return;
    }
    setBannerSize((current) =>
      current?.width === width && current.height === height
        ? current
        : { width, height }
    );
  };

  const handleLoaded = (event: { nativeEvent: NativeBannerLoadedEvent }) => {
    const { width, height, publisherSlotName: slot, source } = event.nativeEvent;
    updateBannerSize(width, height);
    onAdLoaded?.({ width, height, publisherSlotName: slot, source });
  };

  const handleImpression = (event: { nativeEvent: NativeBannerLoadedEvent }) => {
    // Native re-reports the size here: an auto-reloaded creative can render at a different size
    // than the one reported by onAdLoaded.
    const { width, height, publisherSlotName: slot, source } = event.nativeEvent;
    updateBannerSize(width, height);
    onAdImpression?.({ width, height, publisherSlotName: slot, source });
  };

  // A refresh failure keeps the creative (and its size) that is still displayed; a failure before
  // any load has no size to reset.
  const handleFailedToLoad = (event: {
    nativeEvent: NativeBannerFailedToLoadEvent;
  }) => {
    const { code, message } = event.nativeEvent.error;
    onAdFailedToLoad?.({ code, message });
  };

  const finalStyle = [
    style,
    bannerSize ? { width: bannerSize.width, height: bannerSize.height } : null,
  ];

  return (
    <NativeStroeerBannerView
      {...viewProps}
      publisherSlotName={publisherSlotName}
      contentUrl={contentUrl}
      customTargeting={customTargeting}
      style={finalStyle}
      onAdLoaded={handleLoaded}
      onAdImpression={handleImpression}
      onAdFailedToLoad={handleFailedToLoad}
      onAdOpened={onAdOpened ? () => onAdOpened() : undefined}
      onAdClosed={onAdClosed ? () => onAdClosed() : undefined}
      onAdClicked={onAdClicked ? () => onAdClicked() : undefined}
    />
  );
}
