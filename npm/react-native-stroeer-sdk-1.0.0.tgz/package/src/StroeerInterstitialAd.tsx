import { forwardRef, useMemo } from 'react';
import { StroeerInterstitial } from './StroeerInterstitial';
import type { StroeerInterstitialListeners } from './StroeerInterstitial';
import { useFullscreenAd } from './fullscreen/useFullscreenAd';
import type { UseFullscreenAdResult } from './fullscreen/useFullscreenAd';
import { useFullscreenAdComponent } from './fullscreen/useFullscreenAdComponent';
import type { FullscreenAdRef } from './fullscreen/useFullscreenAdComponent';

export type StroeerInterstitialAdRef = FullscreenAdRef;

export type UseStroeerInterstitialResult = UseFullscreenAdResult;

export interface StroeerInterstitialAdProps
  extends StroeerInterstitialListeners {
  publisherSlotName: string;
  /** Load when mounted. Default false. */
  autoLoad?: boolean;
  /** Show as soon as the ad is loaded (once per slot / mount). Default false. */
  autoShow?: boolean;
}

/**
 * Interstitial state and controls for a slot. The hook owns its ad: `load()` always creates a
 * fresh one, and the ad is destroyed on `destroy()`, slot change and unmount. `load`, `show`,
 * `isReady` and `destroy` keep their identity across renders.
 */
export function useStroeerInterstitial(
  publisherSlotName: string,
  listeners?: StroeerInterstitialListeners
): UseStroeerInterstitialResult {
  return useFullscreenAd(StroeerInterstitial, publisherSlotName, {
    listeners,
  });
}

/**
 * Headless interstitial component. Control it with a ref (`load`, `show`, `isReady`) and/or
 * `autoLoad` / `autoShow`. Renders nothing; unmounting destroys the ad.
 */
export const StroeerInterstitialAd = forwardRef<
  StroeerInterstitialAdRef,
  StroeerInterstitialAdProps
>(function InterstitialAdComponent(
  {
    publisherSlotName,
    autoLoad,
    autoShow,
    onAdLoaded,
    onAdFailedToLoad,
    onAdShowed,
    onAdDismissed,
    onAdFailedToShow,
    onAdClicked,
    onAdImpression,
  },
  ref
) {
  const listeners = useMemo<StroeerInterstitialListeners>(
    () => ({
      onAdLoaded,
      onAdFailedToLoad,
      onAdShowed,
      onAdDismissed,
      onAdFailedToShow,
      onAdClicked,
      onAdImpression,
    }),
    [
      onAdLoaded,
      onAdFailedToLoad,
      onAdShowed,
      onAdDismissed,
      onAdFailedToShow,
      onAdClicked,
      onAdImpression,
    ]
  );

  useFullscreenAdComponent(
    StroeerInterstitial,
    publisherSlotName,
    ref,
    { autoLoad, autoShow },
    { listeners }
  );
  return null;
});
