export interface SlotNames {
    bannerSlots: string[];
    interstitialSlots: string[];
}
/**
 * Global custom targeting: key to list of values.
 *
 * The key `user` carries user interests (GAM `user_keyword`, Prebid `user.data` "interests"); the
 * key `context` carries page context (GAM `context_keyword`, Prebid `app.content.data`). Any other
 * key is sent as-is to GAM and as Prebid `ext.data.<key>`. Keys are merged per key: setting one
 * key does not remove others. Values are trimmed and de-duplicated natively; keys whose values end
 * up empty are skipped.
 */
export type StroeerTargeting = Readonly<Record<string, ReadonlyArray<string>>>;
export interface StroeerSDKType {
    /**
     * Starts the SDK setup. Rejects with INVALID_ARGUMENT for a blank name and SDK_ERROR when the
     * SDK throws. Resolves once setup has started, not once the configuration is loaded.
     */
    setApplicationName(applicationName: string): Promise<void>;
    /**
     * Resets the SDK configuration, applies the application name and waits for the configuration.
     * Disruptive: do not run while ads are loading or showing. Calls are serialized. Rejects with
     * CONFIG_NOT_LOADED when the configuration could not be loaded.
     */
    resetAndLoadConfiguration(applicationName: string): Promise<SlotNames>;
    /**
     * Discards the cached configuration and requests a refresh. Resolves when the refresh has been
     * requested, not when it finished. Does not touch consent data.
     */
    clearConfigurationCache(): Promise<void>;
    /** Rejects with CONFIG_NOT_LOADED when the configuration is not loaded. */
    getSlotNames(): Promise<SlotNames>;
    /** Resolves null when the configuration is not loaded. */
    getConfiguration(): Promise<string | null>;
    /**
     * Sets the URL of the content the ad is displayed alongside, used for contextual targeting and
     * brand safety.
     *
     * On iOS this requires `setApplicationName` to have been called first — the URL is written to
     * the Yieldlove instance's ad request, and is dropped with a warning if that instance does not
     * exist yet.
     */
    setContentUrl(url: string): void;
    /** Throws INVALID_ARGUMENT for malformed input. See {@link StroeerTargeting}. */
    setGlobalCustomTargeting(targeting: StroeerTargeting): void;
    disableErrorLog(disable: boolean): void;
    enableTestForIOCampaigns(enable: boolean): void;
    forcePrebidRendering(enable: boolean): void;
    enableDebugMode(): void;
    enableInspectionMode(): void;
}
/**
 * Every method throws (void methods) or rejects (Promise methods) with code `MODULE_UNAVAILABLE`
 * when the native module is missing.
 */
export declare const StroeerSDK: StroeerSDKType;
//# sourceMappingURL=StroeerSDK.d.ts.map