import type { TurboModule } from 'react-native';
import type { Double, EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
export type NativeRewardedEvent = Readonly<{
    adId: string;
}>;
export type NativeRewardedErrorEvent = Readonly<{
    adId: string;
    error: Readonly<{
        code: string;
        message: string;
    }>;
}>;
export type NativeRewardedRewardEvent = Readonly<{
    adId: string;
    reward: Readonly<{
        type: string;
        amount: Double;
    }>;
}>;
export interface Spec extends TurboModule {
    /** Registers a one-shot ad handle and returns its id. Creates no SDK object. */
    createAd(publisherSlotName: string): Promise<string>;
    /** Resolves on the SDK's onAdLoaded; rejects with {code, message}. */
    load(adId: string): Promise<void>;
    /** Resolves when the ad is on screen; rejects with {code, message}. */
    show(adId: string): Promise<void>;
    isReady(adId: string): Promise<boolean>;
    /** Idempotent: an unknown id resolves. */
    destroy(adId: string): Promise<void>;
    readonly onAdLoaded: EventEmitter<NativeRewardedEvent>;
    readonly onAdShowed: EventEmitter<NativeRewardedEvent>;
    readonly onAdDismissed: EventEmitter<NativeRewardedEvent>;
    readonly onAdClicked: EventEmitter<NativeRewardedEvent>;
    readonly onAdImpression: EventEmitter<NativeRewardedEvent>;
    readonly onAdFailedToLoad: EventEmitter<NativeRewardedErrorEvent>;
    readonly onAdFailedToShow: EventEmitter<NativeRewardedErrorEvent>;
    /** At most once per ad; may also arrive after `onAdDismissed`. */
    readonly onUserEarnedReward: EventEmitter<NativeRewardedRewardEvent>;
}
export declare function getNativeStroeerRewarded(): Spec;
//# sourceMappingURL=NativeStroeerRewardedModule.d.ts.map