import type { TurboModule } from 'react-native';
export type NativeIdentityCustomInfo = Readonly<{
    email?: string;
    phone?: string;
    puid?: string;
    regionCode?: string;
    cityCode?: string;
}>;
export interface Spec extends TurboModule {
    /**
     * Hands a fresh custom info object to the SDK atomically. Omitted fields are null in that
     * object, but the SDK's ID5 provider only sets fields and never clears them.
     */
    setCustomInfo(info: NativeIdentityCustomInfo): void;
}
export declare function getNativeStroeerIdentity(): Spec;
//# sourceMappingURL=NativeStroeerIdentityModule.d.ts.map