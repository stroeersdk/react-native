import type { ViewProps, HostComponent } from 'react-native';
import type { DirectEventHandler, Double, UnsafeMixed } from 'react-native/Libraries/Types/CodegenTypes';
export type NativeBannerLoadedEvent = Readonly<{
    publisherSlotName: string;
    width: Double;
    height: Double;
    source: string;
}>;
export type NativeBannerFailedToLoadEvent = Readonly<{
    publisherSlotName: string;
    error: Readonly<{
        code: string;
        message: string;
    }>;
}>;
export type NativeBannerSlotEvent = Readonly<{
    publisherSlotName: string;
}>;
export interface NativeProps extends ViewProps {
    publisherSlotName: string;
    contentUrl?: string;
    customTargeting?: UnsafeMixed;
    onAdLoaded?: DirectEventHandler<NativeBannerLoadedEvent>;
    onAdImpression?: DirectEventHandler<NativeBannerLoadedEvent>;
    onAdFailedToLoad?: DirectEventHandler<NativeBannerFailedToLoadEvent>;
    onAdOpened?: DirectEventHandler<NativeBannerSlotEvent>;
    onAdClosed?: DirectEventHandler<NativeBannerSlotEvent>;
    onAdClicked?: DirectEventHandler<NativeBannerSlotEvent>;
}
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=StroeerBannerViewNativeComponent.d.ts.map