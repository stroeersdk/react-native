import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
export type NativeInterstitialEvent = Readonly<{
    adId: string;
}>;
export type NativeInterstitialErrorEvent = Readonly<{
    adId: string;
    error: Readonly<{
        code: string;
        message: string;
    }>;
}>;
export interface Spec extends TurboModule {
    /** Registers a one-shot ad handle and returns its id. Creates no SDK object. */
    createAd(publisherSlotName: string): Promise<string>;
    /** Resolves on the SDK's onAdLoaded; rejects with {code, message}. */
    load(adId: string): Promise<void>;
    /** Resolves when the ad is on screen; rejects with {code, message}. */
    show(adId: string): Promise<void>;
    isReady(adId: string): Promise<boolean>;
    /** Idempotent: an unknown id resolves. */
    destroy(adId: string): Promise<void>;
    readonly onAdLoaded: EventEmitter<NativeInterstitialEvent>;
    readonly onAdShowed: EventEmitter<NativeInterstitialEvent>;
    readonly onAdDismissed: EventEmitter<NativeInterstitialEvent>;
    readonly onAdClicked: EventEmitter<NativeInterstitialEvent>;
    readonly onAdImpression: EventEmitter<NativeInterstitialEvent>;
    readonly onAdFailedToLoad: EventEmitter<NativeInterstitialErrorEvent>;
    readonly onAdFailedToShow: EventEmitter<NativeInterstitialErrorEvent>;
}
export declare function getNativeStroeerInterstitial(): Spec;
//# sourceMappingURL=NativeStroeerInterstitialModule.d.ts.map