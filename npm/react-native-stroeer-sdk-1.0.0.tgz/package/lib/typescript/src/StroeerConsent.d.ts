export interface StroeerConsentType {
    isAvailable(): Promise<boolean>;
    initialize(): Promise<boolean>;
    showConsent(layoutName?: string): Promise<boolean>;
    clearConsent(): Promise<boolean>;
    showPrivacyManager(layoutName?: string): Promise<boolean>;
    getConsent(): Promise<string | null>;
    hasVendorConsent(vendorId: number): Promise<boolean>;
}
export declare const StroeerConsentModule: StroeerConsentType;
//# sourceMappingURL=StroeerConsent.d.ts.map