/**
 * Details extracted from an error rejected by a native module.
 *
 * React Native rejects promises with an `Error` whose `code`, `domain` and
 * `userInfo` are own *enumerable* properties, while `message` — the only field
 * carrying the SDK's actual failure text — is own but *non-enumerable*. That
 * makes `{ ...error }` silently drop the message, which is why native failures
 * used to log as `{ code: '1', domain: 'RCTErrorDomain', userInfo: null }`.
 */
export interface NativeErrorDetails {
    code?: string;
    message: string;
    domain?: string;
    userInfo?: unknown;
}
/**
 * Normalises an error thrown by a native module into a plain, log-friendly
 * object. Reads `message` explicitly so it survives, and omits
 * `nativeStackIOS` to keep logs readable.
 */
export declare function describeNativeError(error: unknown): NativeErrorDetails;
/**
 * Short single-line rendering of a native error, suitable for on-screen status
 * text. Falls back to the message alone when no code is present.
 */
export declare function formatNativeError(error: unknown): string;
//# sourceMappingURL=nativeError.d.ts.map