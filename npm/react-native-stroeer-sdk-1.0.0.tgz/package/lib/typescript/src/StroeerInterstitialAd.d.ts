import type { StroeerInterstitialListeners } from './StroeerInterstitial';
import type { UseFullscreenAdResult } from './fullscreen/useFullscreenAd';
import type { FullscreenAdRef } from './fullscreen/useFullscreenAdComponent';
export type StroeerInterstitialAdRef = FullscreenAdRef;
export type UseStroeerInterstitialResult = UseFullscreenAdResult;
export interface StroeerInterstitialAdProps extends StroeerInterstitialListeners {
    publisherSlotName: string;
    /** Load when mounted. Default false. */
    autoLoad?: boolean;
    /** Show as soon as the ad is loaded (once per slot / mount). Default false. */
    autoShow?: boolean;
}
/**
 * Interstitial state and controls for a slot. The hook owns its ad: `load()` always creates a
 * fresh one, and the ad is destroyed on `destroy()`, slot change and unmount. `load`, `show`,
 * `isReady` and `destroy` keep their identity across renders.
 */
export declare function useStroeerInterstitial(publisherSlotName: string, listeners?: StroeerInterstitialListeners): UseStroeerInterstitialResult;
/**
 * Headless interstitial component. Control it with a ref (`load`, `show`, `isReady`) and/or
 * `autoLoad` / `autoShow`. Renders nothing; unmounting destroys the ad.
 */
export declare const StroeerInterstitialAd: import("react").ForwardRefExoticComponent<StroeerInterstitialAdProps & import("react").RefAttributes<FullscreenAdRef>>;
//# sourceMappingURL=StroeerInterstitialAd.d.ts.map