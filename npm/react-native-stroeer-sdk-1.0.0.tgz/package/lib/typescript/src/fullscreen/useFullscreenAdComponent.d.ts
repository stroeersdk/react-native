import type { Ref } from 'react';
import type { UseFullscreenAdOptions } from './useFullscreenAd';
import type { AdStatus, FullscreenAdFactory, FullscreenAdListeners } from './types';
/** Imperative API of the headless ad components. */
export interface FullscreenAdRef {
    load(): Promise<void>;
    show(): Promise<void>;
    isReady(): Promise<boolean>;
}
export interface FullscreenAdComponentOptions {
    /** Load when mounted (and when `publisherSlotName` changes). Default false. */
    autoLoad?: boolean;
    /**
     * Show as soon as the ad is loaded; once per slot / mount. Default false. If the app is in the
     * background at that moment the attempt fails with `APP_IN_BACKGROUND` and is not retried on
     * resume (no surprise ad); call `show()` yourself.
     */
    autoShow?: boolean;
}
/**
 * Shared implementation of the headless ad components (a component only calls this and renders
 * `null`). Built on {@link useFullscreenAd}; callback identity changes never reload.
 */
export declare function useFullscreenAdComponent<L extends FullscreenAdListeners>(factory: FullscreenAdFactory<L>, publisherSlotName: string, ref: Ref<FullscreenAdRef> | undefined, { autoLoad, autoShow }: FullscreenAdComponentOptions, hookOptions: UseFullscreenAdOptions<L>): import("./useFullscreenAd").UseFullscreenAdResult;
export interface AutoShowInput {
    autoShow: boolean;
    status: AdStatus;
    adId: string | null;
    adSlot: string | null;
    publisherSlotName: string;
    lastAutoShownAdId: string | null;
}
/**
 * Whether an auto show should start now: only for a loaded ad that belongs to the CURRENT slot
 * (a render right after a slot change still carries the previous ad's status), and once per ad.
 */
export declare function shouldAutoShow(input: AutoShowInput): boolean;
//# sourceMappingURL=useFullscreenAdComponent.d.ts.map