import type { AdError, AdStatus, FullscreenAdFactory, FullscreenAdHandle, FullscreenAdListeners, Subscription } from './types';
export interface UseFullscreenAdOptions<L extends FullscreenAdListeners> {
    /** Called for the events of the current ad. The latest object is always used. */
    listeners?: L;
    /**
     * Called for every handle the hook creates, to add format specific subscriptions (e.g. the
     * reward of rewarded ads). The returned subscription is removed together with the handle.
     */
    subscribeExtra?: (handle: FullscreenAdHandle<L>) => Subscription;
    /** Called when the hook discards its ad (new load, destroy, slot change, unmount). */
    onReset?: () => void;
}
export interface UseFullscreenAdResult {
    status: AdStatus;
    isLoading: boolean;
    isLoaded: boolean;
    /** Id and slot of the current ad (set once its handle exists), null otherwise. */
    adId: string | null;
    adSlot: string | null;
    /** The error of the last failed operation; cleared when a new load starts. */
    error: AdError | null;
    /** Creates a fresh ad and loads it. Rejects while loading or showing. */
    load(): Promise<void>;
    /**
     * Shows the loaded ad. Rejects unless `status` is `loaded`. Rejects with `APP_IN_BACKGROUND`
     * while the app is in the background: `onAdFailedToShow` is called and `error` set, but
     * `status` returns to `loaded` so the ad can be shown once the app is resumed.
     */
    show(): Promise<void>;
    isReady(): Promise<boolean>;
    /** Discards the current ad and resets to `idle`. */
    destroy(): Promise<void>;
}
/**
 * Shared hook of the full screen formats. It owns one ad handle at a time: `load()` creates a
 * fresh handle (destroying the previous one), `destroy()`, a slot change and unmount destroy it.
 * All native work happens in callbacks and effects, never during render.
 */
export declare function useFullscreenAd<L extends FullscreenAdListeners>(factory: FullscreenAdFactory<L>, publisherSlotName: string, options?: UseFullscreenAdOptions<L>): UseFullscreenAdResult;
//# sourceMappingURL=useFullscreenAd.d.ts.map