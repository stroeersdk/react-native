/** Error of a failed ad operation, delivered by rejected promises and failure events. */
export interface AdError {
    /**
     * `INVALID_ARGUMENT`, `UNKNOWN_AD`, `INVALID_STATE`, `NOT_READY`, `NO_ACTIVITY`,
     * `ACTIVITY_LOST`, `LOAD_FAILED`, `LOAD_TIMEOUT`, `SHOW_FAILED`, `APP_IN_BACKGROUND` or `DESTROYED`.
     * `APP_IN_BACKGROUND`: show() was refused because the app is not in the foreground; the ad
     * stays loaded and can be shown once the app is resumed.
     */
    code: string;
    message: string;
}
/** Lifecycle status of an ad managed by a hook / component. */
export type AdStatus = 'idle' | 'loading' | 'loaded' | 'showing' | 'dismissed' | 'failed';
export interface Subscription {
    remove(): void;
}
/** Events shared by all full screen formats. */
export interface FullscreenAdListeners {
    onAdLoaded?: () => void;
    onAdFailedToLoad?: (error: AdError) => void;
    onAdShowed?: () => void;
    onAdDismissed?: () => void;
    onAdFailedToShow?: (error: AdError) => void;
    onAdClicked?: () => void;
    onAdImpression?: () => void;
}
/**
 * One-shot ad. A handle loads once and shows once; to show another ad, create a new handle.
 * `destroy()` MUST be called when the handle is no longer needed: the native ad instance (also
 * after it was dismissed, so late callbacks still arrive) is only released by `destroy()`.
 */
export interface FullscreenAdHandle<L extends FullscreenAdListeners> {
    readonly adId: string;
    readonly publisherSlotName: string;
    /** Resolves when the ad is loaded. Rejects with {@link AdError}-shaped errors. */
    load(): Promise<void>;
    /**
     * Resolves when the ad is on screen. Dismissal is reported by `onAdDismissed`. Ads expire
     * (GMA: about one hour after loading): load a new ad when an old one is stale.
     */
    show(): Promise<void>;
    isReady(): Promise<boolean>;
    /** Idempotent. Drops all subscriptions of this handle. */
    destroy(): Promise<void>;
    /** Additive: every call registers another set of listeners. */
    subscribe(listeners: L): Subscription;
}
export interface FullscreenAdFactory<L extends FullscreenAdListeners> {
    create(publisherSlotName: string): Promise<FullscreenAdHandle<L>>;
}
/** Native event emitters keyed by the ad id of their payload (codegen `EventEmitter`). */
export type NativeEmitter<T> = (handler: (event: T) => void) => Subscription;
export interface NativeAdEvent {
    adId: string;
}
export interface NativeAdErrorEvent {
    adId: string;
    error: {
        code: string;
        message: string;
    };
}
/** The part of a codegen TurboModule spec every full screen format has. */
export interface FullscreenNativeSpec {
    createAd(publisherSlotName: string): Promise<string>;
    load(adId: string): Promise<void>;
    show(adId: string): Promise<void>;
    isReady(adId: string): Promise<boolean>;
    destroy(adId: string): Promise<void>;
    readonly onAdLoaded: NativeEmitter<NativeAdEvent>;
    readonly onAdShowed: NativeEmitter<NativeAdEvent>;
    readonly onAdDismissed: NativeEmitter<NativeAdEvent>;
    readonly onAdClicked: NativeEmitter<NativeAdEvent>;
    readonly onAdImpression: NativeEmitter<NativeAdEvent>;
    readonly onAdFailedToLoad: NativeEmitter<NativeAdErrorEvent>;
    readonly onAdFailedToShow: NativeEmitter<NativeAdErrorEvent>;
}
//# sourceMappingURL=types.d.ts.map