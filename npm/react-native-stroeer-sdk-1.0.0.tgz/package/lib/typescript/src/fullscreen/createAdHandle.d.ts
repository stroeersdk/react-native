import type { FullscreenAdFactory, FullscreenAdListeners, FullscreenNativeSpec, NativeEmitter } from './types';
/**
 * An additional native event of a format (e.g. the rewarded `onUserEarnedReward`): which
 * emitter to listen to and how to hand its payload to one set of listeners.
 */
export interface ExtraRoute<L extends FullscreenAdListeners, S extends FullscreenNativeSpec, E extends {
    adId: string;
}> {
    /** Picks the emitter from the (lazily resolved) native module. */
    emitter(spec: S): NativeEmitter<E>;
    dispatch(listeners: L, event: E): void;
}
/** Type-erased route as stored by the factory. */
type AnyRoute<L extends FullscreenAdListeners, S extends FullscreenNativeSpec> = ExtraRoute<L, S, any>;
/**
 * Builds the `create()` factory of a full screen format on top of its TurboModule spec.
 *
 * The native module is resolved and its emitters are subscribed once, lazily on the first
 * `create()` (a missing module rejects that promise; importing never throws), and route every
 * event to the listeners registered for its `adId`. A throwing listener never breaks routing.
 */
export declare function createFullscreenAdFactory<L extends FullscreenAdListeners, S extends FullscreenNativeSpec = FullscreenNativeSpec>(getSpec: () => S, extraRoutes?: ReadonlyArray<AnyRoute<L, S>>): FullscreenAdFactory<L>;
export {};
//# sourceMappingURL=createAdHandle.d.ts.map