import React from 'react';
import type { ViewProps } from 'react-native';
/** Payload of `onAdLoaded` and `onAdImpression`. Sizes are in dp. */
export interface StroeerBannerLoadedEvent {
    width: number;
    height: number;
    publisherSlotName: string;
    source: string;
}
/** Error reported by `onAdFailedToLoad`. */
export interface StroeerBannerError {
    /**
     * `INVALID_ARGUMENT`, `SETUP_FAILED` or `LOAD_FAILED`. A missing Activity is not an error: the
     * banner waits and loads once one is available.
     */
    code: string;
    message: string;
}
export interface StroeerBannerAdListeners {
    onAdLoaded?: (event: StroeerBannerLoadedEvent) => void;
    /**
     * Also called when an automatic refresh fails; the previous creative stays visible then.
     */
    onAdFailedToLoad?: (error: StroeerBannerError) => void;
    onAdOpened?: () => void;
    onAdClosed?: () => void;
    onAdClicked?: () => void;
    /** Called for every impression, including those of automatic refreshes. */
    onAdImpression?: (event: StroeerBannerLoadedEvent) => void;
}
export interface StroeerBannerAdProps extends ViewProps, StroeerBannerAdListeners {
    publisherSlotName: string;
    contentUrl?: string;
    customTargeting?: Readonly<Record<string, string>>;
}
/**
 * Banner ad view. It is purely prop driven: a banner loads when the component is mounted and
 * again whenever `publisherSlotName`, `contentUrl` or `customTargeting` change in value
 * (targeting is compared by content, so passing a new but equal object does not reload).
 *
 * A config change remounts the native view: the old native banner is destroyed, a new one loads,
 * and the auto-size state starts fresh, so events of the previous config can never apply to the
 * new one. There is no imperative reload; to force a fresh load for an unchanged config, change
 * the React `key` of this component. Unmounting destroys the banner.
 *
 * The view resizes itself to the size of the loaded creative.
 */
export declare function StroeerBannerAd(props: StroeerBannerAdProps): React.JSX.Element;
//# sourceMappingURL=StroeerBannerAd.d.ts.map