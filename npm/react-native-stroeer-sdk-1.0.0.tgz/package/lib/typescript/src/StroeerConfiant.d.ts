export interface StroeerConfiantType {
    /**
     * Activates Confiant regardless of the remote configuration. Call it before `initialize`; a
     * later call is ignored. Throws an error with code `MODULE_UNAVAILABLE` when the native module
     * is missing.
     */
    enableTestMode(): void;
    /**
     * Resolves `true` when Confiant is running and `false` when it is not available or not
     * activated. Rejects with an error carrying `code`: `MODULE_UNAVAILABLE`, `INVALID_ARGUMENT`,
     * `ALREADY_INITIALIZING`, `INIT_TIMEOUT` or `INIT_FAILED`.
     */
    initialize(confiantPropertyId: string, enableReload: boolean): Promise<boolean>;
}
export declare const StroeerConfiant: StroeerConfiantType;
//# sourceMappingURL=StroeerConfiant.d.ts.map