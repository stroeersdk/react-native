import type { RewardItem, StroeerRewardedListeners } from './StroeerRewarded';
import type { UseFullscreenAdResult } from './fullscreen/useFullscreenAd';
import type { FullscreenAdRef } from './fullscreen/useFullscreenAdComponent';
export type StroeerRewardedAdRef = FullscreenAdRef;
export interface UseStroeerRewardedResult extends UseFullscreenAdResult {
    /** The reward of the current ad; reset to null when a new ad is loaded or discarded. */
    reward: RewardItem | null;
}
export interface StroeerRewardedAdProps extends StroeerRewardedListeners {
    publisherSlotName: string;
    /** Load when mounted. Default false. */
    autoLoad?: boolean;
    /** Show as soon as the ad is loaded (once per slot / mount). Default false. */
    autoShow?: boolean;
}
/**
 * Rewarded state and controls for a slot. The hook owns its ad: `load()` always creates a fresh
 * one (a failed load is retried with a new ad), and the ad is destroyed on `destroy()`, slot
 * change and unmount. `load`, `show`, `isReady` and `destroy` keep their identity across renders.
 */
export declare function useStroeerRewarded(publisherSlotName: string, listeners?: StroeerRewardedListeners): UseStroeerRewardedResult;
/**
 * Headless rewarded component. Control it with a ref (`load`, `show`, `isReady`) and/or
 * `autoLoad` / `autoShow`. Renders nothing; unmounting destroys the ad.
 */
export declare const StroeerRewardedAd: import("react").ForwardRefExoticComponent<StroeerRewardedAdProps & import("react").RefAttributes<FullscreenAdRef>>;
//# sourceMappingURL=StroeerRewardedAd.d.ts.map