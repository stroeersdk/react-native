# Ströer SDK for React Native

**Version:** 1.0.1 | **React Native:** 0.82.1+ (New Architecture) | **Android:** min SDK 24, target SDK 36, Java 17 | **iOS:** 15.1+

React Native bridge (npm package `react-native-stroeer-sdk`) for the Ströer advertising SDK. It
supports banner, interstitial and rewarded ads on Android and iOS, plus Confiant ad-quality
monitoring and identity data.

- [Integration Guide](https://stroeersdk.github.io/react-native/blob/main/docs/1.0/Integration.md)
- [Public Repository](https://github.com/stroeersdk/react-native) (published packages, docs, example apps)
- [Migration guide](#migration-guide) (upgrading from `react-native-yieldlove` 4.3.1)

## Requirements

- React Native **0.82.1** or later with the New Architecture (always on since 0.82), React **19.1.1** or later
- Android: min SDK 24, compile/target SDK 36, Java 17
- iOS: 15.1 or later, CocoaPods
- A Ströer application name and publisher slot names (provided by Ströer)

## Installation

```bash
npm install react-native-stroeer-sdk
# or
yarn add react-native-stroeer-sdk
```

The package is autolinked. The Android SDK is not on Maven Central, so your app has to declare the
Ströer Maven repository. The iOS SDK is on CocoaPods trunk.

### Android

Add the Ströer Maven repository to the repositories of your project (`android/build.gradle`, or
`dependencyResolutionManagement` in `android/settings.gradle`):

```groovy
allprojects {
  repositories {
    google()
    mavenCentral()
    maven {
      url "https://stroeersdk.github.io/android/maven"
      content { includeGroup("com.stroeer.ads") }
    }
  }
}
```

The bridge depends on `com.stroeer.ads:core`. Add your Google Mobile Ads application ID to
`android/app/src/main/AndroidManifest.xml`:

```xml
<application>
  <meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy" />
</application>
```

### iOS

Declare the `StroeerSDK` pod (from CocoaPods trunk) in `ios/Podfile`, then run `pod install`:

```ruby
target 'YourApp' do
  # ...
  pod 'StroeerSDK', :subspecs => ['Core']   # add 'Consent' for CMP
end
```

Add `GADApplicationIdentifier` (your Google Mobile Ads application ID) and the `SKAdNetworkItems`
from the Integration Guide to `Info.plist`. The app crashes on start without the application ID.

### Optional: Confiant

Confiant needs its native SDK in addition to the bridge.

- Android: add the Confiant repository and the Ströer Confiant plugin:

  ```groovy
  maven {
    url 'https://cdn.confiant-integrations.net/backend-integrations/in-app/releases/android/maven'
    content { includeGroup("com.confiant.android") }
  }
  ```
  ```groovy
  // android/app/build.gradle
  implementation 'com.stroeer.ads:confiant:<sdk version>'
  ```

- iOS: add the Confiant podspec source to the Podfile and follow the Integration Guide:

  ```ruby
  source 'https://cdn.cocoapods.org/'
  source 'https://cdn.confiant-integrations.net/backend-integrations/in-app/releases/ios/podspecs.git'
  ```

  Then install `StroeerSDK` from the Confiant podspec, which adds the `Confiant` subspec. It
  replaces the `pod 'StroeerSDK'` line from [iOS](#ios); declare the pod only once:

  ```ruby
  pod 'StroeerSDK', :podspec => 'https://stroeersdk.github.io/iOS/cocoapods/1.0.0/StroeerSDK-Confiant.podspec',
                    :subspecs => ['Core', 'Confiant']   # add 'Consent' for CMP
  ```

Without the Confiant SDK, `StroeerConfiant.initialize` resolves `false`.

## Quick start

Initialize the SDK once, before any ad loads:

```tsx
import { StroeerSDK } from 'react-native-stroeer-sdk';

await StroeerSDK.setApplicationName('your-app-name');
```

`setApplicationName` resolves once the setup has started, not once the configuration is loaded.
It rejects with `INVALID_ARGUMENT` for a blank name.

## Banner

```tsx
import { StroeerBannerAd } from 'react-native-stroeer-sdk';

<StroeerBannerAd
  publisherSlotName="banner_slot"
  contentUrl="https://example.com/article"
  customTargeting={{ section: 'sport' }}
  onAdLoaded={({ width, height }) => console.log('loaded', width, height)}
  onAdFailedToLoad={({ code, message }) => console.warn(code, message)}
/>
```

- The banner loads when mounted and resizes itself to the creative (sizes in dp).
- It reloads when `publisherSlotName`, `contentUrl` or `customTargeting` change in value. Passing a
  new but equal targeting object does not reload. To force a reload, change the React `key`.
- Unmounting destroys the banner.
- Events: `onAdLoaded`, `onAdImpression` (both `{ width, height, publisherSlotName, source }`),
  `onAdFailedToLoad` (`{ code, message }`, also for failed automatic refreshes), `onAdOpened`,
  `onAdClosed`, `onAdClicked`.

## Interstitial

The hook is the simplest option. It owns one ad at a time: `load()` always creates a fresh ad, and
the ad is destroyed on `destroy()`, slot change and unmount.

```tsx
import { useStroeerInterstitial } from 'react-native-stroeer-sdk';

function ArticleScreen() {
  const ad = useStroeerInterstitial('interstitial_slot', {
    onAdDismissed: () => console.log('dismissed'),
  });

  // ad.status: 'idle' | 'loading' | 'loaded' | 'showing' | 'dismissed' | 'failed'
  // ad.error:  { code, message } of the last failed operation, or null
  return (
    <>
      <Button title="Load" onPress={() => ad.load().catch(() => {})} />
      <Button title="Show" disabled={!ad.isLoaded} onPress={() => ad.show().catch(() => {})} />
    </>
  );
}
```

The headless component is controlled with a ref and/or `autoLoad` / `autoShow` (both default
`false`):

```tsx
import { StroeerInterstitialAd, type StroeerInterstitialAdRef } from 'react-native-stroeer-sdk';

const ref = useRef<StroeerInterstitialAdRef>(null);

<StroeerInterstitialAd ref={ref} publisherSlotName="interstitial_slot" autoLoad />
// later: await ref.current?.show();
```

For full control, use ad handles. A handle loads once and shows once; create a new handle for the
next ad, and **always call `destroy()`** when you are done (the hook and component do this for you):

```ts
import { StroeerInterstitial } from 'react-native-stroeer-sdk';

const ad = await StroeerInterstitial.create('interstitial_slot');
const sub = ad.subscribe({ onAdDismissed: () => {} });
await ad.load();
await ad.show(); // resolves when the ad is on screen
// ...
sub.remove();
await ad.destroy();
```

Events: `onAdLoaded`, `onAdFailedToLoad`, `onAdShowed`, `onAdDismissed`, `onAdFailedToShow`,
`onAdClicked`, `onAdImpression`. `subscribe()` is additive: every call adds another set of listeners.

Ads expire about one hour after loading; load a new ad when an old one is stale.

## Rewarded

Rewarded ads have the same API as interstitials (`StroeerRewarded`, `useStroeerRewarded`,
`StroeerRewardedAd`) plus the reward:

```tsx
import { useStroeerRewarded } from 'react-native-stroeer-sdk';

const ad = useStroeerRewarded('rewarded_slot', {
  onUserEarnedReward: ({ type, amount }) => grant(type, amount),
});
// ad.reward: { type, amount } of the current ad, or null (reset on every new load)
```

- The reward is delivered at most once per ad, independently of `show()`, and can arrive after
  `onAdDismissed`. Keep the handle (and its subscription) alive until the screen goes away;
  nothing is delivered after `destroy()`.
- An ad that reports no reward item delivers no reward event.
- A failed load cannot be retried on the same handle: create a new one (the hook does this on
  every `load()`).

## SDK configuration and targeting

```ts
import { StroeerSDK } from 'react-native-stroeer-sdk';

// Content URL for contextual targeting and brand safety (iOS: after setApplicationName)
StroeerSDK.setContentUrl('https://example.com/article');

// Global targeting: key -> list of values, merged per key
StroeerSDK.setGlobalCustomTargeting({
  user: ['sports', 'technology'],   // user interests
  context: ['sport', 'game'],        // page context
  section: ['soccer'],               // any other key: plain custom targeting
});

const { bannerSlots, interstitialSlots } = await StroeerSDK.getSlotNames();
```

| Method | Description |
|---|---|
| `setApplicationName(name): Promise<void>` | Starts the SDK setup. Call once at app start. |
| `getSlotNames(): Promise<SlotNames>` | Rejects with `CONFIG_NOT_LOADED` when no configuration is loaded. |
| `getConfiguration(): Promise<string \| null>` | The raw configuration, or `null` when not loaded. |
| `setContentUrl(url)` | Content URL for contextual targeting. |
| `setGlobalCustomTargeting(targeting)` | Keys `user` and `context` are special; others are sent as-is. Throws `INVALID_ARGUMENT` for malformed input. |
| `enableDebugMode()`, `enableInspectionMode()` | Debugging aids. Do not ship enabled. |
| `enableTestForIOCampaigns(enable)`, `forcePrebidRendering(enable)`, `disableErrorLog(disable)` | Testing options. |

## Identity

Identity data is passed to the SDK's identity provider (ID5) with one call:

```ts
import { StroeerIdentity } from 'react-native-stroeer-sdk';

StroeerIdentity.setCustomInfo({
  email: 'user@example.com',
  puid: 'user-1234',
});
```

| Field | Type | Description |
|---|---|---|
| `email` | `string` | The user's email address |
| `phone` | `string` | The user's phone number |
| `puid` | `string` | Your own (publisher) user ID |
| `regionCode` | `string` | Region code |
| `cityCode` | `string` | City code |

- **Every field is optional.** Pass only the fields you have; leave the others out rather than
  passing empty strings. A missing field and `null` are treated the same.
- **The order of the fields does not matter.** The argument is an object and every field is read by
  its name, so `{ puid, email }` and `{ email, puid }` are identical.
- **Shorthand needs matching variable names.** `setCustomInfo({ email, puid })` only works when you
  have variables named `email` and `puid`. Otherwise write `{ email: userEmail, puid: userId }`.
- **Call it when the data is known**, for example after login. Ad requests made before the call do
  not carry the data. You can call it again at any time.
- **Each call is applied at once.** The SDK receives all fields of the call together, so there is no
  separate `apply()` step.
- **Later calls add to earlier ones.** The SDK only sets fields and never clears them, so a field
  left out of a later call keeps its earlier value:

  ```ts
  StroeerIdentity.setCustomInfo({ email: 'user@example.com' });
  StroeerIdentity.setCustomInfo({ puid: 'user-1234' });
  // The SDK now has both email and puid.
  ```
- **Identity data cannot be removed yet.** Neither leaving a field out nor passing `null` clears a
  value that was already set (for example on logout). This needs a reset API in the native SDK.
- **Values are never logged** by the bridge.
- **Errors:** `setCustomInfo` returns nothing. It throws an error with the code `MODULE_UNAVAILABLE`
  when the native module is missing (rebuild the app after installing the package).

The TypeScript type of the argument is exported as `StroeerIdentityCustomInfo`.

## Confiant

```ts
import { StroeerConfiant } from 'react-native-stroeer-sdk';

// StroeerConfiant.enableTestMode(); // optional, must come before initialize
const running = await StroeerConfiant.initialize('<confiant property id>', true /* enableReload */);
```

`initialize` resolves `true` when Confiant runs and `false` when it is not installed or not
activated. It settles once; a second call while it runs rejects with `ALREADY_INITIALIZING`.

## Errors

Every error is `{ code, message }`. Promises reject and failure events deliver the same shape.
`describeNativeError(error)` and `formatNativeError(error)` turn any rejection into a loggable
object or a one-line string.

| Code | Meaning |
|---|---|
| `MODULE_UNAVAILABLE` | The native module is missing (package not linked or app not rebuilt). |
| `INVALID_ARGUMENT` | Bad input, e.g. an empty slot or application name. |
| `CONFIG_NOT_LOADED`, `SDK_ERROR` | SDK configuration not loaded / SDK failure. |
| `LOAD_FAILED`, `LOAD_TIMEOUT` | The ad did not load (timeout: 60 s). |
| `NOT_READY`, `INVALID_STATE` | `show()` without a loaded ad, or an operation in the wrong state for the handle. |
| `SHOW_FAILED`, `APP_IN_BACKGROUND` | The ad could not be shown. In the background the ad stays loaded and can be shown after resume. |
| `NO_ACTIVITY`, `ACTIVITY_LOST` | Android: no foreground Activity to show the ad. |
| `UNKNOWN_AD`, `DESTROYED` | The handle was destroyed. |
| `SETUP_FAILED` | Banner: SDK setup failed. |
| `ALREADY_INITIALIZING`, `INIT_TIMEOUT`, `INIT_FAILED` | Confiant initialization. |

## Troubleshooting

- **App crashes on start**: the Google Mobile Ads application ID is missing
  (`APPLICATION_ID` in `AndroidManifest.xml`, `GADApplicationIdentifier` in `Info.plist`).
- **`MODULE_UNAVAILABLE`**: rebuild the native app after installing or updating the package
  (`pod install` on iOS).
- **Gradle cannot resolve `com.stroeer.ads:core`** / **CocoaPods cannot find `StroeerSDK`**: the
  Maven repository from [Installation](#installation) is missing, or the CocoaPods specs are outdated
  (`pod install --repo-update`).
- **No ads**: check the application name and slot names, and that consent is given.

# Migration guide

## 4.3.1 to 1.0.1

1.0.1 is the first release of the bridge as `react-native-stroeer-sdk`. It replaces
`react-native-yieldlove` 4.3.1. The version number restarts at 1.0 together with the native
StröerSDK. React Native 0.82.1 and the New Architecture are still required, as in 4.3.x.

### 1. Replace the package

```bash
npm uninstall react-native-yieldlove
npm install react-native-stroeer-sdk@^1.0.1
# or
yarn remove react-native-yieldlove
yarn add react-native-stroeer-sdk@^1.0.1
```

Update your imports:

```diff
- import { StroeerSDK, StroeerBannerAd } from 'react-native-yieldlove';
+ import { StroeerSDK, StroeerBannerAd } from 'react-native-stroeer-sdk';
```

### 2. Update the native setup

- **Android**: replace the old Yieldlove Maven repository
  (`slabs-yieldlove-ad-integration.s3...`, group `com.yieldlove.adIntegration`) with the Ströer
  repository shown in [Android](#android) (group `com.stroeer.ads`). If you declared Yieldlove
  artifacts yourself, replace them: `com.yieldlove.adIntegration:yieldlove` becomes
  `com.stroeer.ads:core`, and `com.yieldlove.adIntegration:confiant` becomes
  `com.stroeer.ads:confiant`. Jetifier is no longer required.
- **iOS**: the `YieldloveAdIntegration` pod is replaced by `StroeerSDK`. Remove any
  `YieldloveAdIntegration` entries from your `Podfile`, add the `StroeerSDK` pod as shown in
  [iOS](#ios), then run `pod install --repo-update`.
- Rebuild the native app. A JS reload is not enough.

### 3. SDK configuration and targeting

```diff
- StroeerSDK.setApplicationName('your-app-name');
+ await StroeerSDK.setApplicationName('your-app-name');

- StroeerSDK.setUserTargeting(['sports', 'technology']);
- StroeerSDK.setContextTargeting(['sport', 'game']);
- StroeerSDK.setCustomTargeting({ section: ['soccer'] });
+ StroeerSDK.setGlobalCustomTargeting({
+   user: ['sports', 'technology'],
+   context: ['sport', 'game'],
+   section: ['soccer'],
+ });

- const slots = await StroeerSDK.reloadConfigurationAndGetSlotNames('your-app-name');
+ const slots = await StroeerSDK.resetAndLoadConfiguration('your-app-name');
```

- `setContextDataTargeting(...)` keys also move into `setGlobalCustomTargeting`.
- `getSlotNames()` now rejects with `CONFIG_NOT_LOADED` instead of resolving `null`. Wrap it in
  `try`/`catch` instead of checking for `null`.
- `clearConfigurationCache()` no longer clears the app's default shared preferences (Android),
  so consent is kept.

### 4. Banner

```diff
  <StroeerBannerAd
    publisherSlotName="banner_slot"
-   destroyWhenDetached={false}
  />
```

- Remove `destroyWhenDetached`. The banner is destroyed when it unmounts.
- `onAdFailedToLoad` still receives `message`, so existing handlers keep working. It now also
  receives an error `code` (see [Errors](#errors)).
- The banner reloads when `publisherSlotName`, `contentUrl` or `customTargeting` change in value.
  To force a reload, change the React `key`.
- `onAdImpression` now receives the same `{ width, height, publisherSlotName, source }` payload as
  `onAdLoaded`.

### 5. Interstitial and rewarded

`StroeerInterstitial` and `StroeerRewarded` used to be single shared objects. Now they create ad
handles. `setLoadAfterReady`, `setListeners` and `removeAllListeners` are removed, and ads never
show automatically after loading.

```diff
- StroeerInterstitial.setListeners({ onAdDismissed: () => {} });
- await StroeerInterstitial.load('interstitial_slot');
- await StroeerInterstitial.show();
- StroeerInterstitial.removeAllListeners();
+ const ad = await StroeerInterstitial.create('interstitial_slot');
+ const sub = ad.subscribe({ onAdDismissed: () => {} });
+ await ad.load();
+ await ad.show();
+ sub.remove();
+ await ad.destroy();
```

- A handle loads once and shows once. Create a new handle for the next ad, and always call
  `destroy()`.
- `onAdFailedToLoad` and `onAdFailedToShow` receive `{ code, message }` instead of a string.
  Update handlers that treat the error as a string:

  ```diff
  - onAdFailedToLoad: (error) => console.warn(error),
  + onAdFailedToLoad: ({ code, message }) => console.warn(code, message),
  ```
- The hooks take listeners as an optional second argument and expose `status`, `error`, `load`,
  `show`, `isReady` and `destroy`. `checkReady()` is replaced by `isReady()` (or `isLoaded`).
  `load()` always creates a fresh ad.

  ```diff
  - const ad = useStroeerInterstitial('interstitial_slot');
  + const ad = useStroeerInterstitial('interstitial_slot', { onAdDismissed: () => {} });
  ```
- `StroeerInterstitialAd` and `StroeerRewardedAd` keep their props (`autoLoad`, `autoShow`,
  listeners) and can also be controlled through a ref (`load`, `show`, `isReady`). Several
  components and hooks can now coexist without replacing each other's listeners.
- Rewarded: deliver rewards from `onUserEarnedReward`, which can fire after `onAdDismissed`. Keep
  the handle alive until then. See [Rewarded](#rewarded).

### 6. Identity

The per-field setters and `apply()` are replaced by one `setCustomInfo` call that takes an object:

```diff
- StroeerIdentity.setEmail('user@example.com');
- StroeerIdentity.setPhone('+49301234567');
- StroeerIdentity.setPuid('user-1234');
- StroeerIdentity.setRegionCode(regionCode);
- StroeerIdentity.setCityCode(cityCode);
- StroeerIdentity.apply();
+ StroeerIdentity.setCustomInfo({
+   email: 'user@example.com',
+   phone: '+49301234567',
+   puid: 'user-1234',
+   regionCode,
+   cityCode,
+ });
```

| 4.3.1 | 1.0.1 |
|---|---|
| `setEmail(value)` | `email` field |
| `setPhone(value)` | `phone` field |
| `setPuid(value)` | `puid` field |
| `setRegionCode(value)` | `regionCode` field |
| `setCityCode(value)` | `cityCode` field |
| `apply()` | not needed: every `setCustomInfo` call is applied at once |

Pass only the fields you have, in any order. Values that were already applied are kept
when a later call leaves them out. See [Identity](#identity) for details.

### 7. Confiant

The `initialize(propertyId, enableReload)` signature is unchanged. It now settles only once:
a second call while the first one runs rejects with `ALREADY_INITIALIZING`.

### 8. Errors and test tooling

- All rejections and failure events are `{ code, message }` (see [Errors](#errors)). A missing
  native module rejects with `MODULE_UNAVAILABLE` instead of a generic error.
- `IabTestConsent` is no longer exported. It was test tooling. Write test consent in your app
  instead (see `example/src/testConsent.ts`).

# Change log
### [1.0.1] (12.Oct.2026)

#### New
- Rebranded the SDK as StröerSDK.
- Changed the package name to `com.stroeer.ads`. (Android)
- Updated the library repository: GitHub – StröerSDK Android. (Android)
- Added a Jetpack Compose wrapper (`com.stroeer.compose`). (Android)
- Configuration is now revalidated using an ETag instead of being re-downloaded on every refresh. (Android)
- The React Native bridge is now built for the New Architecture only (React Native 0.82): every module is a codegen TurboModule and the banner is a Fabric component.
- Interstitial and rewarded ads are now ad handles (`create` → `load` → `show` → `destroy`). Several ads can be loaded at the same time, and hooks and components each own their ad, so they no longer replace each other's listeners.
- Every banner, interstitial and rewarded event is logged by the native SDK. (Android)

#### Fixed
- Corrected the precedence of key-values and `contentUrl` for GAM. Key-values from remote configuration are now also included in Prebid requests. (Android)
- Ad size is now rechecked at impression time, as the size of some banners is determined only when the impression occurs. (Android)
- The SDK no longer adds an app-name label to the merged manifest. (Android)
- Banner: `onAdLoaded` is no longer lost when an impression follows immediately, and every load failure is now reported to `onAdFailedToLoad`.
- Interstitial and rewarded ads no longer show automatically after loading, and `show()` now resolves once the ad is actually presented.
- Rewarded: loading again after a failed load works, and a reward that arrives after the ad is dismissed is still delivered.
- `clearConfigurationCache()` no longer clears the app's default shared preferences (including consent); it now only requests a fresh configuration.
- User and context targeting is now sent to Prebid in the correct place; GAM receives the same key-values as before.
- Release JS bundling of the example app works again in the monorepo.
- Fixed various minor bugs.

#### Changed
- The SDK version reported to GAM and Prebid now follows the new versioning scheme (major + 20). (Android)
- Removed the OkHttp dependency. (Android)
- SDK libraries are now obfuscated. (Android)
- Updated third-party library versions (Android):
  - Prebid Mobile: 3.3.4
  - SourcePoint: 7.15.13
  - Google Mobile Ads SDK: 24.6.0 (publishers can upgrade to a later version)
  - Kotlin: 2.1.0 (publishers can upgrade to a later version)
- The iOS native SDK is now the `StroeerSDK` pod (1.0.0), which replaces `YieldloveAdIntegration`. It is installed from CocoaPods trunk with the subspecs `Core` (default) and `Consent`; the Confiant variant comes from `https://stroeersdk.github.io/iOS/cocoapods/1.0.0/StroeerSDK-Confiant.podspec`. (iOS)
- Updated third-party library versions (iOS):
  - Prebid Mobile: 3.4.1
  - Google Mobile Ads SDK: 13.7.0
  - ConsentViewController (SourcePoint): ~> 7.12
- Errors are now reported as `{ code, message }`. A missing native module is reported with the code `MODULE_UNAVAILABLE`.
- Jetifier is no longer required. (Android)

#### Breaking changes (React Native API)
- **Banner (`StroeerBannerAd`)**: loading is driven by props. It reloads when `publisherSlotName`, `contentUrl` or `customTargeting` change in value; change the React `key` to force a reload. `onAdFailedToLoad` receives `{ code, message }`. The `destroyWhenDetached` prop is removed.
- **Interstitial and rewarded**: use `const ad = await StroeerInterstitial.create(slot)` (or `StroeerRewarded.create(slot)`), then `ad.subscribe(...)`, `ad.load()`, `ad.show()` and `ad.destroy()`. `setLoadAfterReady`, `setListeners` and `removeAllListeners` are removed. `useStroeerInterstitial` / `useStroeerRewarded` and the `StroeerInterstitialAd` / `StroeerRewardedAd` components (controlled through a ref) are kept on the new API.
- **StroeerSDK**:
  - `setUserTargeting`, `setContextTargeting`, `setContextDataTargeting` and `setCustomTargeting` are replaced by `setGlobalCustomTargeting({ user: [...], context: [...], <key>: [...] })`.
  - `setApplicationName` and `clearConfigurationCache` return Promises.
  - `getSlotNames` rejects with `CONFIG_NOT_LOADED` instead of resolving `null`, and `getConfiguration` resolves `null` when no configuration is loaded.
- **StroeerIdentity**: `setEmail`, `setPhone`, `setPuid`, `setRegionCode`, `setCityCode` and `apply` are replaced by `setCustomInfo({ email, phone, puid, regionCode, cityCode })`.
- **StroeerConfiant**: `initialize` resolves only once; a second call while it is running rejects with `ALREADY_INITIALIZING`.
