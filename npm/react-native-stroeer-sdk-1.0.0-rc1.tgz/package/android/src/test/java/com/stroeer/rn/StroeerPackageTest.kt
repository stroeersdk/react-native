package com.stroeer.rn

import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class StroeerPackageTest {

    @Mock
    private lateinit var reactContext: ReactApplicationContext

    private lateinit var stroeerPackage: StroeerPackage

    @Before
    fun setup() {
        org.mockito.MockitoAnnotations.openMocks(this)
        stroeerPackage = StroeerPackage()
    }

    private val expectedNames = setOf(
        "StroeerSDK",
        StroeerConfiantModule.NAME,
        StroeerIdentityModule.NAME,
        NativeStroeerInterstitialModuleSpec.NAME,
        NativeStroeerRewardedModuleSpec.NAME
    )

    @Test
    fun `test module info provider declares every module as a turbo module`() {
        val infos = stroeerPackage.getReactModuleInfoProvider().getReactModuleInfos()

        assertEquals(expectedNames, infos.keys)
        infos.forEach { (name, info) ->
            assertEquals(name, info.name)
            assertTrue("$name must be a TurboModule", info.isTurboModule)
            assertFalse(info.isCxxModule)
        }
    }

    @Test
    fun `test getModule returns the module for each declared name`() {
        expectedNames.forEach { name ->
            val module = stroeerPackage.getModule(name, reactContext)
            assertNotNull("No module for $name", module)
            assertEquals(name, module!!.name)
        }
    }

    @Test
    fun `test getModule returns null for unknown name`() {
        assertNull(stroeerPackage.getModule("DoesNotExist", reactContext))
    }

    @Test
    fun `test createViewManagers returns banner view manager`() {
        // When
        val viewManagers = stroeerPackage.createViewManagers(reactContext)

        // Then
        assert(viewManagers.isNotEmpty())

        // Check for StroeerBannerViewManager
        val viewManagerTypes = viewManagers.map { it::class.java.simpleName }
        assert(viewManagerTypes.contains("StroeerBannerViewManager"))
    }

    @Test
    fun `test view manager names are unique`() {
        // When
        val viewManagers = stroeerPackage.createViewManagers(reactContext)
        val viewManagerNames = viewManagers.map { it.name }

        // Then - all view manager names should be unique
        assert(viewManagerNames.size == viewManagerNames.toSet().size) {
            "View manager names must be unique, found duplicates: ${viewManagerNames.groupingBy { it }.eachCount().filter { it.value > 1 }}"
        }
    }

    @Test
    fun `test all view managers are properly instantiated`() {
        // When
        val viewManagers = stroeerPackage.createViewManagers(reactContext)

        // Then - all view managers should be non-null and have valid names
        viewManagers.forEach { viewManager ->
            assert(viewManager.name.isNotEmpty()) { "ViewManager ${viewManager::class.java.simpleName} has empty name" }
        }
    }
}
