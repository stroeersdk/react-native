package com.stroeer.rn

import com.facebook.react.bridge.JavaOnlyArray
import com.facebook.react.bridge.JavaOnlyMap
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.mockito.Mockito.never
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.kotlin.any
import org.mockito.kotlin.eq
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class StroeerModuleTest {

    private class FakeSdk : SdkFacade {
        val calls = mutableListOf<String>()
        var targeting: Map<String, List<String>>? = null
        var slotNames: SlotNameLists? = SlotNameLists(listOf("b1"), listOf("i1"))
        var configJson: String? = null
        var failWith: RuntimeException? = null
        var awaitGate: CompletableDeferred<Unit>? = null
        var beforeReturn: (() -> Unit)? = null

        private fun record(call: String) {
            calls.add(call)
            failWith?.let { throw it }
        }

        override fun setApplicationName(applicationName: String) = record("setApplicationName:$applicationName")
        override fun resetConfiguration() = record("reset")
        override suspend fun awaitSlotNames(): SlotNameLists? {
            record("await")
            awaitGate?.await()
            beforeReturn?.invoke()
            return slotNames
        }
        override fun configurationJson(): String? = configJson
        override fun clearConfigurationCache() = record("clearConfigurationCache")
        override fun setContentUrl(url: String) = record("setContentUrl:$url")
        override fun setGlobalCustomTargeting(targeting: Map<String, List<String>>) {
            this.targeting = targeting
            record("setGlobalCustomTargeting")
        }
        override fun disableErrorLog(disable: Boolean) = record("disableErrorLog:$disable")
        override fun enableTestForIOCampaigns(enable: Boolean) = record("enableTestForIOCampaigns:$enable")
        override fun forcePrebidRendering(enable: Boolean) = record("forcePrebidRendering:$enable")
        override fun enableDebugMode() = record("enableDebugMode")
        override fun enableInspectionMode() = record("enableInspectionMode")
    }

    private lateinit var sdk: FakeSdk
    private lateinit var scope: CoroutineScope
    private lateinit var module: StroeerModule
    private lateinit var promise: Promise
    private var mainRuns = 0

    @Before
    fun setUp() {
        sdk = FakeSdk()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined)
        promise = mock(Promise::class.java)
        module = newModule()
    }

    private fun newModule() = StroeerModule(
        mock(ReactApplicationContext::class.java),
        sdk,
        scope,
        { task -> mainRuns++; task() },
        { JavaOnlyMap() },
        { JavaOnlyArray() }
    )

    private fun map(vararg pairs: Pair<String, Any?>) = JavaOnlyMap().also { m ->
        pairs.forEach { (k, v) ->
            when (v) {
                is JavaOnlyArray -> m.putArray(k, v)
                null -> m.putNull(k)
                is String -> m.putString(k, v)
            }
        }
    }

    private fun array(vararg items: Any?) = JavaOnlyArray().also { a ->
        items.forEach {
            when (it) {
                null -> a.pushNull()
                is String -> a.pushString(it)
                is Int -> a.pushInt(it)
            }
        }
    }

    @Test
    fun `module name is StroeerSDK`() {
        assertEquals("StroeerSDK", module.name)
    }

    @Test
    fun `setApplicationName delegates on main and resolves`() {
        module.setApplicationName("app", promise)
        assertEquals(listOf("setApplicationName:app"), sdk.calls)
        assertEquals(1, mainRuns)
        verify(promise).resolve(null)
    }

    @Test
    fun `setApplicationName rejects blank names`() {
        module.setApplicationName("  ", promise)
        verify(promise).reject(eq("INVALID_ARGUMENT"), any<String>())
        assertTrue(sdk.calls.isEmpty())
    }

    @Test
    fun `setApplicationName rejects with SDK_ERROR exactly once when the SDK throws`() {
        sdk.failWith = IllegalStateException("boom")
        module.setApplicationName("app", promise)
        verify(promise).reject(eq("SDK_ERROR"), eq("boom"), any<Throwable>())
        verify(promise, never()).resolve(any<Any>())
    }

    @Test
    fun `resetAndLoadConfiguration orders reset, setApplicationName, await without delay`() {
        module.resetAndLoadConfiguration("app", promise)
        assertEquals(listOf("reset", "setApplicationName:app", "await"), sdk.calls)
        val captor = org.mockito.ArgumentCaptor.forClass(Any::class.java)
        verify(promise).resolve(captor.capture())
        val result = captor.value as JavaOnlyMap
        assertEquals(listOf("b1"), result.getArray("bannerSlots")!!.toArrayList())
        assertEquals(listOf("i1"), result.getArray("interstitialSlots")!!.toArrayList())
    }

    @Test
    fun `resetAndLoadConfiguration rejects CONFIG_NOT_LOADED when null`() {
        sdk.slotNames = null
        module.resetAndLoadConfiguration("app", promise)
        verify(promise).reject(eq("CONFIG_NOT_LOADED"), any<String>())
    }

    @Test
    fun `resetAndLoadConfiguration rejects blank names`() {
        module.resetAndLoadConfiguration("", promise)
        verify(promise).reject(eq("INVALID_ARGUMENT"), any<String>())
        assertTrue(sdk.calls.isEmpty())
    }

    @Test
    fun `concurrent resetAndLoadConfiguration calls are serialized`() {
        val gate = CompletableDeferred<Unit>()
        sdk.awaitGate = gate
        val second = mock(Promise::class.java)
        module.resetAndLoadConfiguration("a", promise)
        module.resetAndLoadConfiguration("b", second)
        assertEquals(listOf("reset", "setApplicationName:a", "await"), sdk.calls)

        gate.complete(Unit)
        assertEquals(
            listOf("reset", "setApplicationName:a", "await", "reset", "setApplicationName:b", "await"),
            sdk.calls
        )
        verify(promise).resolve(any<Any>())
        verify(second).resolve(any<Any>())
    }

    @Test
    fun `clearConfigurationCache only asks the SDK for a refresh`() {
        module.clearConfigurationCache(promise)
        assertEquals(listOf("clearConfigurationCache"), sdk.calls)
        verify(promise).resolve(null)
    }

    @Test
    fun `getSlotNames resolves names or CONFIG_NOT_LOADED`() {
        module.getSlotNames(promise)
        verify(promise).resolve(any<Any>())

        sdk.slotNames = null
        val failing = mock(Promise::class.java)
        module.getSlotNames(failing)
        verify(failing).reject(eq("CONFIG_NOT_LOADED"), any<String>())
    }

    @Test
    fun `getConfiguration is null when not loaded and the json otherwise`() {
        module.getConfiguration(promise)
        verify(promise).resolve(null)

        sdk.configJson = "{}"
        val loaded = mock(Promise::class.java)
        module.getConfiguration(loaded)
        verify(loaded).resolve("{}")
    }

    @Test
    fun `void methods map to the facade on the main thread`() {
        module.setContentUrl("https://x")
        module.disableErrorLog(true)
        module.enableTestForIOCampaigns(false)
        module.forcePrebidRendering(true)
        module.enableDebugMode()
        module.enableInspectionMode()
        assertEquals(
            listOf(
                "setContentUrl:https://x", "disableErrorLog:true", "enableTestForIOCampaigns:false",
                "forcePrebidRendering:true", "enableDebugMode", "enableInspectionMode"
            ),
            sdk.calls
        )
        assertEquals(6, mainRuns)
    }

    @Test
    fun `void methods swallow SDK exceptions`() {
        sdk.failWith = RuntimeException("boom")
        module.enableDebugMode()
        module.setContentUrl("u")
        module.setGlobalCustomTargeting(map("user" to array("a")))
    }

    @Test
    fun `targeting keeps user and context keys and skips invalid entries`() {
        module.setGlobalCustomTargeting(
            map(
                "user" to array("a", 1, null, "b"),
                "context" to array("c"),
                "section" to array(),
                "" to array("x"),
                "bad" to "notAnArray",
                "nul" to null
            )
        )
        assertEquals(
            mapOf("user" to listOf("a", "b"), "context" to listOf("c"), "section" to emptyList<String>()),
            sdk.targeting
        )
    }

    @Test
    fun `invalidate rejects in-flight promises once and later calls`() {
        sdk.awaitGate = CompletableDeferred()
        module.resetAndLoadConfiguration("app", promise)
        module.invalidate()
        verify(promise, times(1)).reject(eq("MODULE_INVALIDATED"), any<String>())
        verify(promise, never()).resolve(any<Any>())

        val late = mock(Promise::class.java)
        module.getSlotNames(late)
        verify(late).reject(eq("MODULE_INVALIDATED"), any<String>())

        sdk.calls.clear()
        module.enableDebugMode()
        assertTrue(sdk.calls.isEmpty())
    }

    @Test
    fun `standalone setApplicationName cannot interleave with a reset in flight`() {
        val gate = CompletableDeferred<Unit>()
        sdk.awaitGate = gate
        val other = mock(Promise::class.java)
        module.resetAndLoadConfiguration("a", promise)
        module.setApplicationName("b", other)
        assertEquals(listOf("reset", "setApplicationName:a", "await"), sdk.calls)

        gate.complete(Unit)
        assertEquals(listOf("reset", "setApplicationName:a", "await", "setApplicationName:b"), sdk.calls)
        verify(promise).resolve(any<Any>())
        verify(other).resolve(null)
    }

    @Test
    fun `a result produced after invalidate is rejected not resolved`() {
        // The module is invalidated after the work finished but before the promise is resolved.
        sdk.beforeReturn = { module.invalidate() }
        module.getSlotNames(promise)
        verify(promise, times(1)).reject(eq("MODULE_INVALIDATED"), any<String>())
        verify(promise, never()).resolve(any<Any>())
    }
}
