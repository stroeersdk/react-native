package com.stroeer.rn

import android.app.Activity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class FullscreenAdControllerTest {

    private class FakeAdapter : FullscreenSdkAdapter {
        var loadCount = 0
        var showCount = 0
        var destroyCount = 0
        var loadedSlot: String? = null
        var throwOnLoad: Exception? = null
        var throwOnShow: Exception? = null
        lateinit var callbacks: FullscreenSdkCallbacks

        override fun load(adSlotId: String, callbacks: FullscreenSdkCallbacks) {
            throwOnLoad?.let { throw it }
            loadCount++
            loadedSlot = adSlotId
            this.callbacks = callbacks
        }

        override fun show() {
            throwOnShow?.let { throw it }
            showCount++
        }

        override fun destroy() {
            destroyCount++
        }
    }

    private class FakeScheduler : FullscreenScheduler {
        private class Task(val at: Long, val runnable: Runnable, var cancelled: Boolean = false)

        var now = 0L
        private val tasks = mutableListOf<Task>()

        override fun postDelayed(delayMs: Long, task: Runnable): FullscreenCancellable {
            val t = Task(now + delayMs, task)
            tasks.add(t)
            return FullscreenCancellable { t.cancelled = true }
        }

        fun advance(ms: Long) {
            now += ms
            for (t in tasks.toList()) {
                if (!t.cancelled && t.at <= now) {
                    tasks.remove(t)
                    t.runnable.run()
                }
            }
        }
    }

    private class Result<T> {
        var resolved: T? = null
        var resolveCount = 0
        var rejectCode: String? = null
        var rejectMessage: String? = null
        var rejectCount = 0
        val settleCount get() = resolveCount + rejectCount
        val settlement = Settlement<T>(
            resolve = { resolved = it; resolveCount++ },
            reject = { code, message -> rejectCode = code; rejectMessage = message; rejectCount++ }
        )
    }

    private val log = mutableListOf<String>()
    private val rewards = mutableListOf<Triple<String, String, Int>>()

    private val events = object : FullscreenAdEvents {
        override fun onAdLoaded(adId: String) { log.add("loaded:$adId") }
        override fun onAdShowed(adId: String) { log.add("showed:$adId") }
        override fun onAdDismissed(adId: String) { log.add("dismissed:$adId") }
        override fun onAdClicked(adId: String) { log.add("clicked:$adId") }
        override fun onAdImpression(adId: String) { log.add("impression:$adId") }
        override fun onAdFailedToLoad(adId: String, code: String, message: String) {
            log.add("failedToLoad:$adId:$code:$message")
        }
        override fun onAdFailedToShow(adId: String, code: String, message: String) {
            log.add("failedToShow:$adId:$code:$message")
        }
        override fun onUserEarnedReward(adId: String, type: String, amount: Int) {
            rewards.add(Triple(adId, type, amount))
        }
    }

    private lateinit var activity: Activity
    private var currentActivity: Activity? = null
    private val adapters = mutableListOf<FakeAdapter>()
    private var factoryError: Exception? = null
    private val scheduler = FakeScheduler()
    private var nextId = 0
    private lateinit var controller: FullscreenAdController

    @Before
    fun setUp() {
        activity = Robolectric.buildActivity(Activity::class.java).setup().get()
        currentActivity = activity
        controller = FullscreenAdController(
            activityProvider = { currentActivity },
            adapterFactory = FullscreenSdkAdapterFactory {
                factoryError?.let { e -> throw e }
                FakeAdapter().also { adapters.add(it) }
            },
            events = events,
            scheduler = scheduler,
            loadTimeoutMs = 60_000L,
            idFactory = { "ad${nextId++}" }
        )
    }

    private fun create(slot: String = "slot"): String {
        val r = Result<String>()
        controller.create(slot, r.settlement)
        return r.resolved!!
    }

    private fun load(id: String): Result<Unit> = Result<Unit>().also { controller.load(id, it.settlement) }

    private fun show(id: String): Result<Unit> = Result<Unit>().also { controller.show(id, it.settlement) }

    private fun destroy(id: String): Result<Unit> = Result<Unit>().also { controller.destroy(id, it.settlement) }

    private fun loaded(slot: String = "slot"): Pair<String, FakeAdapter> {
        val id = create(slot)
        load(id)
        adapters.last().callbacks.onAdLoaded()
        log.clear()
        return id to adapters.last()
    }

    @Test
    fun createRejectsEmptySlotAndAfterInvalidate() {
        val r = Result<String>()
        controller.create("", r.settlement)
        assertEquals("INVALID_ARGUMENT", r.rejectCode)
        controller.invalidate()
        val r2 = Result<String>()
        controller.create("slot", r2.settlement)
        assertEquals("DESTROYED", r2.rejectCode)
    }

    @Test
    fun createDoesNotCreateSdkInstance() {
        create()
        assertTrue(adapters.isEmpty())
    }

    @Test
    fun loadCreatesFreshSdkInstancePerHandleAndResolvesOnLoaded() {
        val a = create("a")
        val b = create("b")
        assertNotEquals(a, b)
        val ra = load(a)
        val rb = load(b)
        assertEquals(2, adapters.size)
        assertEquals("a", adapters[0].loadedSlot)
        assertEquals("b", adapters[1].loadedSlot)
        assertEquals(0, ra.settleCount)

        adapters[0].callbacks.onAdLoaded()
        assertEquals(1, ra.resolveCount)
        assertEquals(0, rb.settleCount)
        assertEquals(listOf("loaded:$a"), log)
        assertTrue(controller.isReady(a))
        assertFalse(controller.isReady(b))
    }

    @Test
    fun loadPreconditions() {
        val unknown = load("nope")
        assertEquals("UNKNOWN_AD", unknown.rejectCode)

        val id = create()
        currentActivity = null
        assertEquals("NO_ACTIVITY", load(id).rejectCode)
        assertTrue(adapters.isEmpty())
        assertTrue(log.isEmpty())

        currentActivity = activity
        load(id)
        assertEquals("INVALID_STATE", load(id).rejectCode) // loading
        adapters[0].callbacks.onAdLoaded()
        assertEquals("INVALID_STATE", load(id).rejectCode) // ready
        assertEquals(1, adapters.size)
    }

    @Test
    fun loadFailureEmitsEventRejectsAndDestroysSdkOnce() {
        val id = create()
        val r = load(id)
        adapters[0].callbacks.onAdFailedToLoad("no fill")
        assertEquals("LOAD_FAILED", r.rejectCode)
        assertEquals("no fill", r.rejectMessage)
        assertEquals(listOf("failedToLoad:$id:LOAD_FAILED:no fill"), log)
        assertEquals(1, adapters[0].destroyCount)
        // Retry on the same handle is not allowed; a new handle gets a new SDK instance.
        assertEquals("INVALID_STATE", load(id).rejectCode)
        destroy(id)
        assertEquals(1, adapters[0].destroyCount)
        load(create())
        assertEquals(2, adapters.size)
    }

    @Test
    fun exceptionInSdkLoadOrFactoryFailsTheLoad() {
        val id = create()
        factoryError = IllegalStateException("boom")
        val r = load(id)
        assertEquals("LOAD_FAILED", r.rejectCode)
        assertEquals("boom", r.rejectMessage)
        assertEquals(1, log.size)

        factoryError = null
        val id2 = create()
        // Fail inside adapter.load.
        controller = FullscreenAdController(
            { activity },
            FullscreenSdkAdapterFactory { FakeAdapter().also { it.throwOnLoad = RuntimeException("sdk"); adapters.add(it) } },
            events, scheduler, 60_000L, { "x" }
        )
        val r2 = Result<String>()
        controller.create("s", r2.settlement)
        val r3 = Result<Unit>().also { controller.load("x", it.settlement) }
        assertEquals("sdk", r3.rejectMessage)
        assertEquals(1, adapters.last().destroyCount)
        assertEquals(1, r3.settleCount)
        assertNotEquals(id, id2)
    }

    @Test
    fun silentLoadTimesOutAfter60Seconds() {
        val id = create()
        val r = load(id)
        scheduler.advance(59_999)
        assertEquals(0, r.settleCount)
        scheduler.advance(1)
        assertEquals("LOAD_TIMEOUT", r.rejectCode)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, log.size)
        assertTrue(log[0].startsWith("failedToLoad:$id:LOAD_TIMEOUT"))
        // A late SDK callback is ignored.
        adapters[0].callbacks.onAdLoaded()
        assertEquals(1, r.settleCount)
        assertEquals(1, log.size)
    }

    @Test
    fun timeoutLosesRaceAgainstLoaded() {
        val id = create()
        val r = load(id)
        scheduler.advance(59_000)
        adapters[0].callbacks.onAdLoaded()
        scheduler.advance(5_000)
        assertEquals(1, r.resolveCount)
        assertEquals(0, r.rejectCount)
        assertEquals(0, adapters[0].destroyCount)
        assertTrue(controller.isReady(id))
    }

    @Test
    fun loadedLosesRaceAgainstTimeout() {
        val id = create()
        val r = load(id)
        scheduler.advance(60_000)
        adapters[0].callbacks.onAdLoaded()
        adapters[0].callbacks.onAdFailedToLoad("late")
        assertEquals(1, r.rejectCount)
        assertEquals(0, r.resolveCount)
        assertEquals(1, log.size)
    }

    @Test
    fun showPreconditions() {
        assertEquals("UNKNOWN_AD", show("nope").rejectCode)
        val id = create()
        assertEquals("NOT_READY", show(id).rejectCode)
        load(id)
        assertEquals("NOT_READY", show(id).rejectCode)
        assertEquals(0, adapters[0].showCount)
        assertTrue(log.isEmpty())
    }

    @Test
    fun showResolvesOnlyOnShowedCallback() {
        val (id, adapter) = loaded()
        val r = show(id)
        assertEquals(1, adapter.showCount)
        assertEquals(0, r.settleCount)
        assertFalse(controller.isReady(id))

        // Second show while showing.
        assertEquals("INVALID_STATE", show(id).rejectCode)
        assertEquals(1, adapter.showCount)

        adapter.callbacks.onAdShowed()
        assertEquals(1, r.resolveCount)
        assertEquals(listOf("showed:$id"), log)

        adapter.callbacks.onAdImpression()
        adapter.callbacks.onAdClicked()
        adapter.callbacks.onAdDismissed()
        assertEquals(
            listOf("showed:$id", "impression:$id", "clicked:$id", "dismissed:$id"),
            log
        )
        // Dismissal keeps the SDK instance; only destroy() releases it, exactly once.
        assertEquals(0, adapter.destroyCount)
        assertEquals("INVALID_STATE", show(id).rejectCode)
        destroy(id)
        assertEquals(1, adapter.destroyCount)
        destroy(id)
        assertEquals(1, adapter.destroyCount)
    }

    @Test
    fun pausedHostRefusesShowButKeepsAdReady() {
        val (id, adapter) = loaded()
        controller.onHostPause()
        val r = show(id)
        assertEquals("APP_IN_BACKGROUND", r.rejectCode)
        assertEquals(1, r.rejectCount)
        assertTrue(log.isEmpty())
        assertEquals(0, adapter.showCount)
        assertEquals(0, adapter.destroyCount)
        assertTrue(controller.isReady(id))

        controller.onHostResume()
        val r2 = show(id)
        assertEquals(1, adapter.showCount)
        adapter.callbacks.onAdShowed()
        assertEquals(1, r2.resolveCount)
    }

    @Test
    fun initialPausedStateIsHonouredAndLoadIsNotGated() {
        controller = FullscreenAdController(
            activityProvider = { currentActivity },
            adapterFactory = FullscreenSdkAdapterFactory { FakeAdapter().also { adapters.add(it) } },
            events = events,
            scheduler = scheduler,
            loadTimeoutMs = 60_000L,
            idFactory = { "p${nextId++}" },
            initialHostResumed = false
        )
        val id = create()
        val l = load(id)
        adapters.last().callbacks.onAdLoaded()
        assertEquals(1, l.resolveCount)
        assertEquals("APP_IN_BACKGROUND", show(id).rejectCode)
        controller.onHostResume()
        assertEquals(0, show(id).rejectCount)
        assertEquals(1, adapters.last().showCount)
    }

    @Test
    fun pauseWhileShowingDoesNotAffectTheShow() {
        val (id, adapter) = loaded()
        val r = show(id)
        controller.onHostPause()
        assertEquals(0, r.settleCount)
        assertTrue(log.isEmpty())
        adapter.callbacks.onAdShowed()
        assertEquals(1, r.resolveCount)
        assertEquals(listOf("showed:$id"), log)
        assertEquals(0, adapter.destroyCount)
    }

    @Test
    fun dismissalBeforePresentationFailsTheShow() {
        val (id, adapter) = loaded()
        val r = show(id)
        log.clear()
        adapter.callbacks.onAdDismissed()
        val msg = "The ad was dismissed before it was shown"
        assertEquals(listOf("failedToShow:$id:SHOW_FAILED:$msg"), log)
        assertEquals(1, r.rejectCount)
        assertEquals("SHOW_FAILED", r.rejectCode)
        assertEquals(msg, r.rejectMessage)
        assertEquals(1, adapter.destroyCount)
        assertFalse(controller.isReady(id))
        assertEquals("INVALID_STATE", show(id).rejectCode)

        log.clear()
        adapter.callbacks.onUserEarnedReward("coins", 1)
        adapter.callbacks.onAdClicked()
        adapter.callbacks.onAdImpression()
        adapter.callbacks.onAdDismissed()
        assertTrue(log.isEmpty())
        assertTrue(rewards.isEmpty())
        assertEquals(1, adapter.destroyCount)
    }

    @Test
    fun dismissalBeforePresentationAfterDestroyEmitsNothing() {
        val (id, adapter) = loaded()
        val r = show(id)
        destroy(id)
        log.clear()
        adapter.callbacks.onAdDismissed()
        assertTrue(log.isEmpty())
        assertEquals(1, r.settleCount)
        assertEquals("DESTROYED", r.rejectCode)
        assertEquals(1, adapter.destroyCount)
    }

    @Test
    fun lateCallbacksAfterDismissalStillRouteWhileHandleLives() {
        val (id, adapter) = loaded()
        show(id)
        adapter.callbacks.onAdShowed()
        adapter.callbacks.onAdDismissed()
        log.clear()
        adapter.callbacks.onAdImpression()
        adapter.callbacks.onUserEarnedReward("coins", 3)
        assertEquals(listOf("impression:$id"), log)
        assertEquals(listOf(Triple(id, "coins", 3)), rewards)
        assertEquals(0, adapter.destroyCount)
        destroy(id)
        adapter.callbacks.onUserEarnedReward("coins", 4)
        assertEquals(1, rewards.size)
        assertEquals(1, adapter.destroyCount)
    }

    @Test
    fun invalidateDestroysDismissedAdOnce() {
        val (id, adapter) = loaded()
        show(id)
        adapter.callbacks.onAdShowed()
        adapter.callbacks.onAdDismissed()
        assertEquals(0, adapter.destroyCount)
        controller.invalidate()
        assertEquals(1, adapter.destroyCount)
        assertEquals("UNKNOWN_AD", show(id).rejectCode)
    }

    @Test
    fun failedToShowRejectsAndEmits() {
        val (id, adapter) = loaded()
        val r = show(id)
        adapter.callbacks.onAdFailedToShow("not shown")
        assertEquals("SHOW_FAILED", r.rejectCode)
        assertEquals("not shown", r.rejectMessage)
        assertEquals(listOf("failedToShow:$id:SHOW_FAILED:not shown"), log)
        assertEquals(1, adapter.destroyCount)
        assertEquals(1, r.settleCount)
    }

    @Test
    fun exceptionInSdkShowRejects() {
        val (id, adapter) = loaded()
        adapter.throwOnShow = RuntimeException("show boom")
        val r = show(id)
        assertEquals("SHOW_FAILED", r.rejectCode)
        assertEquals("show boom", r.rejectMessage)
        assertEquals(1, adapter.destroyCount)
    }

    @Test
    fun showWithoutOrWithReplacedActivityFailsWithActivityLost() {
        val (id, adapter) = loaded()
        currentActivity = null
        val r = show(id)
        assertEquals("ACTIVITY_LOST", r.rejectCode)
        assertEquals(0, adapter.showCount)
        assertEquals(1, adapter.destroyCount)
        assertEquals(1, log.size)
        assertTrue(log[0].startsWith("failedToShow:$id:ACTIVITY_LOST"))

        currentActivity = activity
        val (id2, adapter2) = loaded()
        currentActivity = Robolectric.buildActivity(Activity::class.java).setup().get()
        assertFalse(controller.isReady(id2))
        assertEquals("ACTIVITY_LOST", show(id2).rejectCode)
        assertEquals(0, adapter2.showCount)
    }

    @Test
    fun hostDestroyFailsLoadingAndReadyAdsBoundToTheActivity() {
        val loading = create()
        val rl = load(loading)
        val (ready, readyAdapter) = loaded()
        val other = Robolectric.buildActivity(Activity::class.java).setup().get()
        controller.onHostDestroy(other)
        assertEquals(0, rl.settleCount)

        controller.onHostDestroy(activity)
        assertEquals("ACTIVITY_LOST", rl.rejectCode)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, readyAdapter.destroyCount)
        assertFalse(controller.isReady(ready))
        assertEquals("INVALID_STATE", show(ready).rejectCode)
    }

    @Test
    fun hostDestroyLeavesConfirmedPresentationAlone() {
        val (id, adapter) = loaded()
        val r = show(id)
        adapter.callbacks.onAdShowed()
        controller.onHostDestroy(activity)
        assertEquals(0, adapter.destroyCount)
        assertEquals(1, r.resolveCount)
        assertEquals(listOf("showed:$id"), log)
    }

    @Test
    fun hostDestroyBeforeShowConfirmationFailsPendingShow() {
        val (id, adapter) = loaded()
        val r = show(id)
        controller.onHostDestroy(activity)
        assertEquals("ACTIVITY_LOST", r.rejectCode)
        assertEquals(1, r.settleCount)
        assertEquals(1, log.size)
        assertTrue(log[0].startsWith("failedToShow:$id:ACTIVITY_LOST"))
        assertEquals(1, adapter.destroyCount)
        // Late SDK callbacks are ignored and the handle is FAILED.
        adapter.callbacks.onAdShowed()
        assertEquals(1, r.settleCount)
        assertEquals("INVALID_STATE", show(id).rejectCode)
    }

    @Test
    fun hostDestroyOfOtherActivityDoesNotFailPendingShow() {
        val (id, adapter) = loaded()
        val r = show(id)
        controller.onHostDestroy(Robolectric.buildActivity(Activity::class.java).setup().get())
        assertEquals(0, r.settleCount)
        assertEquals(0, adapter.destroyCount)
    }

    @Test
    fun hostDestroyBeforeConfirmationAfterDestroyRequestEmitsNothing() {
        val (id, adapter) = loaded()
        val r = show(id)
        destroy(id)
        controller.onHostDestroy(activity)
        assertEquals("DESTROYED", r.rejectCode)
        assertEquals(1, r.settleCount)
        assertTrue(log.isEmpty())
        assertEquals(1, adapter.destroyCount)
        assertEquals("UNKNOWN_AD", show(id).rejectCode)
    }

    @Test
    fun destroyInEveryState() {
        // IDLE
        val idle = create()
        assertEquals(1, destroy(idle).resolveCount)
        assertEquals("UNKNOWN_AD", load(idle).rejectCode)

        // LOADING: pending load rejected, SDK destroyed, timeout cancelled
        val loading = create()
        val rl = load(loading)
        destroy(loading)
        assertEquals("DESTROYED", rl.rejectCode)
        assertEquals(1, adapters[0].destroyCount)
        scheduler.advance(120_000)
        assertEquals(1, rl.settleCount)
        assertTrue(log.isEmpty())
        adapters[0].callbacks.onAdLoaded()
        assertTrue(log.isEmpty())

        // READY
        val (ready, readyAdapter) = loaded()
        destroy(ready)
        assertEquals(1, readyAdapter.destroyCount)
        assertFalse(controller.isReady(ready))

        // DISMISSED / FAILED already released: destroy does not destroy twice
        val (done, doneAdapter) = loaded()
        show(done)
        doneAdapter.callbacks.onAdShowed()
        doneAdapter.callbacks.onAdDismissed()
        assertEquals(0, doneAdapter.destroyCount)
        destroy(done)
        destroy(done)
        assertEquals(1, doneAdapter.destroyCount)
    }

    @Test
    fun destroyWhileShowingSuppressesEventsAndDestroysAfterDismissal() {
        val (id, adapter) = loaded()
        val r = show(id)
        val d = destroy(id)
        assertEquals(1, d.resolveCount)
        assertEquals("DESTROYED", r.rejectCode)
        assertEquals(0, adapter.destroyCount)

        adapter.callbacks.onAdShowed()
        adapter.callbacks.onAdImpression()
        adapter.callbacks.onAdClicked()
        adapter.callbacks.onAdDismissed()
        assertTrue(log.isEmpty())
        assertEquals(1, adapter.destroyCount)
        assertEquals(1, r.settleCount)
        assertEquals("UNKNOWN_AD", show(id).rejectCode)
    }

    @Test
    fun destroyWhileShowingThenFailedToShowDestroysSdk() {
        val (id, adapter) = loaded()
        show(id)
        destroy(id)
        adapter.callbacks.onAdFailedToShow("x")
        assertTrue(log.isEmpty())
        assertEquals(1, adapter.destroyCount)
    }

    @Test
    fun invalidateRejectsPendingAndDestroysEverySdkInstanceOnce() {
        val loading = create()
        val rl = load(loading)
        val (ready, readyAdapter) = loaded()
        val (showing, showingAdapter) = loaded()
        val rs = show(showing)
        controller.invalidate()
        controller.invalidate()
        assertEquals("DESTROYED", rl.rejectCode)
        assertEquals("DESTROYED", rs.rejectCode)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, readyAdapter.destroyCount)
        assertEquals(1, showingAdapter.destroyCount)
        assertEquals("UNKNOWN_AD", show(ready).rejectCode)
        showingAdapter.callbacks.onAdDismissed()
        assertEquals(1, showingAdapter.destroyCount)
        assertTrue(log.isEmpty())
    }

    @Test
    fun rewardRoutesOnceAndOnlyWhenPresented() {
        val (id, adapter) = loaded()
        adapter.callbacks.onUserEarnedReward("coins", 5) // not shown yet
        assertTrue(rewards.isEmpty())

        show(id)
        adapter.callbacks.onAdShowed()
        adapter.callbacks.onUserEarnedReward(null, null)
        assertTrue(rewards.isEmpty())
        adapter.callbacks.onUserEarnedReward("coins", 5)
        adapter.callbacks.onUserEarnedReward("coins", 6)
        assertEquals(listOf(Triple(id, "coins", 5)), rewards)
    }

    @Test
    fun rewardArrivingAfterDismissalStillRoutes() {
        val (id, adapter) = loaded()
        show(id)
        adapter.callbacks.onAdShowed()
        adapter.callbacks.onAdDismissed()
        adapter.callbacks.onUserEarnedReward("coins", 1)
        assertEquals(1, rewards.size)
        destroy(id)
        adapter.callbacks.onUserEarnedReward("coins", 2)
        assertEquals(1, rewards.size)
    }

    @Test
    fun destroyWhileShowingSuppressesReward() {
        val (id, adapter) = loaded()
        show(id)
        destroy(id)
        adapter.callbacks.onUserEarnedReward("coins", 1)
        assertTrue(rewards.isEmpty())
    }

    @Test
    fun twoHandlesAreIndependent() {
        val (a, adapterA) = loaded("a")
        val (b, adapterB) = loaded("b")
        show(a)
        adapterA.callbacks.onAdShowed()
        assertTrue(controller.isReady(b))
        destroy(a)
        assertEquals(0, adapterB.destroyCount)
        show(b)
        assertEquals(1, adapterB.showCount)
    }
}
