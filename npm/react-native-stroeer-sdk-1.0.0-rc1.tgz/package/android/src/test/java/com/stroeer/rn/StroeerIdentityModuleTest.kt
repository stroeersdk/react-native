package com.stroeer.rn

import com.facebook.react.bridge.JavaOnlyMap
import com.facebook.react.bridge.ReactApplicationContext
import com.stroeer.ads.plugins.identity.IdentityManager
import com.stroeer.ads.plugins.identity.objects.IdentityCustomInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class StroeerIdentityModuleTest {

    private lateinit var identityManager: IdentityManager
    private lateinit var module: StroeerIdentityModule

    @Before
    fun setUp() {
        // A real manager is a plain holder for customInfo: no mock needed.
        identityManager = IdentityManager()
        module = StroeerIdentityModule(mock(ReactApplicationContext::class.java), identityManager)
    }

    private fun info(vararg pairs: Pair<String, String?>) = JavaOnlyMap().also { map ->
        pairs.forEach { (k, v) -> if (v == null) map.putNull(k) else map.putString(k, v) }
    }

    @Test
    fun `module name is StroeerIdentityModule`() {
        assertEquals("StroeerIdentityModule", module.name)
    }

    @Test
    fun `setCustomInfo maps every field`() {
        module.setCustomInfo(
            info("email" to "a@b.c", "phone" to "1", "puid" to "p", "regionCode" to "DE", "cityCode" to "Berlin")
        )

        val applied = identityManager.customInfo!!
        assertEquals("a@b.c", applied.email)
        assertEquals("1", applied.phone)
        assertEquals("p", applied.puid)
        assertEquals("DE", applied.regionCode)
        assertEquals("Berlin", applied.cityCode)
    }

    @Test
    fun `omitted and null fields are null`() {
        module.setCustomInfo(info("email" to "a@b.c", "phone" to null))

        val applied = identityManager.customInfo!!
        assertEquals("a@b.c", applied.email)
        assertNull(applied.phone)
        assertNull(applied.puid)
        assertNull(applied.regionCode)
        assertNull(applied.cityCode)
    }

    @Test
    fun `every call builds a fresh object and values do not leak between calls`() {
        module.setCustomInfo(info("email" to "a@b.c", "puid" to "p"))
        val first: IdentityCustomInfo = identityManager.customInfo!!

        module.setCustomInfo(info("phone" to "2"))
        val second = identityManager.customInfo!!

        assertNotSame(first, second)
        assertEquals("a@b.c", first.email)
        assertEquals("p", first.puid)
        assertNull(first.phone)
        assertNull(second.email)
        assertNull(second.puid)
        assertEquals("2", second.phone)
    }
}
