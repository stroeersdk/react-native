package com.stroeer.rn

import android.app.Activity
import com.facebook.react.bridge.CxxCallbackImpl
import com.facebook.react.bridge.JavaOnlyMap
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.BaseJavaModule
import com.facebook.soloader.nativeloader.NativeLoader
import com.facebook.soloader.nativeloader.NativeLoaderDelegate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentCaptor
import org.mockito.Mockito.mock
import org.mockito.Mockito.never
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class StroeerInterstitialModuleTest {

    private class FakeAdapter : FullscreenSdkAdapter {
        var destroyCount = 0
        var showCount = 0
        lateinit var callbacks: FullscreenSdkCallbacks
        override fun load(adSlotId: String, callbacks: FullscreenSdkCallbacks) {
            this.callbacks = callbacks
        }
        override fun show() { showCount++ }
        override fun destroy() { destroyCount++ }
    }

    private class NoopScheduler : FullscreenScheduler {
        override fun postDelayed(delayMs: Long, task: Runnable) = FullscreenCancellable { }
    }

    private lateinit var reactContext: ReactApplicationContext
    private lateinit var activity: Activity
    private lateinit var module: StroeerInterstitialModule
    private lateinit var emitter: CxxCallbackImpl
    private val adapters = mutableListOf<FakeAdapter>()

    @Before
    fun setUp() {
        activity = Robolectric.buildActivity(Activity::class.java).setup().get()
        reactContext = mock(ReactApplicationContext::class.java)
        // CxxCallbackImpl is a JNI hybrid class: loading it needs a NativeLoader, but the native
        // library itself is never used since it is only mocked here.
        NativeLoader.initIfUninitialized(object : NativeLoaderDelegate {
            override fun loadLibrary(shortName: String?, flags: Int) = true
            override fun getLibraryPath(libName: String?): String? = null
            override fun getSoSourcesVersion() = 0
        })
        emitter = mock(CxxCallbackImpl::class.java)
        module = StroeerInterstitialModule(
            reactContext,
            activityProvider = { activity },
            adapterFactory = FullscreenSdkAdapterFactory { FakeAdapter().also { adapters.add(it) } },
            scheduler = NoopScheduler(),
            mapFactory = { JavaOnlyMap() },
            loadTimeoutMs = 60_000L
        )
        // The generated emitOnXxx helpers dereference the emitter callback without a null check;
        // the TurboModule host installs it through this protected setter.
        val setter = BaseJavaModule::class.java.getDeclaredMethod(
            "setEventEmitterCallback",
            CxxCallbackImpl::class.java
        )
        setter.isAccessible = true
        setter.invoke(module, emitter)
    }

    private fun createAd(): String {
        val promise = mock(Promise::class.java)
        module.createAd("slot", promise)
        val captor = ArgumentCaptor.forClass(Any::class.java)
        verify(promise).resolve(captor.capture())
        return captor.value as String
    }

    private fun emitted(): List<Pair<String, ReadableMap>> =
        org.mockito.Mockito.mockingDetails(emitter).invocations
            .filter { it.method.name == "invoke" }
            // Mockito expands the varargs: arguments are [eventName, payload].
            .map { (it.arguments[0] as String) to (it.arguments[1] as ReadableMap) }

    @Test
    fun nameAndSpecContract() {
        assertEquals("StroeerInterstitial", module.name)
    }

    @Test
    fun createReturnsAdIdAndRejectsEmptySlot() {
        val id = createAd()
        assertTrue(id.isNotEmpty())
        val bad = mock(Promise::class.java)
        module.createAd("", bad)
        verify(bad).reject(FullscreenErrorCodes.INVALID_ARGUMENT, "publisherSlotName must not be empty")
    }

    @Test
    fun loadResolvesAndEmitsLoadedWithAdId() {
        val id = createAd()
        val promise = mock(Promise::class.java)
        module.load(id, promise)
        verify(promise, never()).resolve(org.mockito.ArgumentMatchers.any())

        adapters[0].callbacks.onAdLoaded()
        verify(promise).resolve(null)
        val events = emitted()
        assertEquals(1, events.size)
        assertEquals("onAdLoaded", events[0].first)
        assertEquals(id, events[0].second.getString("adId"))
    }

    @Test
    fun failedLoadEmitsNestedErrorAndRejects() {
        val id = createAd()
        val promise = mock(Promise::class.java)
        module.load(id, promise)
        adapters[0].callbacks.onAdFailedToLoad("no fill")
        verify(promise).reject("LOAD_FAILED", "no fill")
        val (name, payload) = emitted().single()
        assertEquals("onAdFailedToLoad", name)
        assertEquals(id, payload.getString("adId"))
        val error = payload.getMap("error")!!
        assertEquals("LOAD_FAILED", error.getString("code"))
        assertEquals("no fill", error.getString("message"))
    }

    @Test
    fun showFlowEmitsShowedImpressionClickedDismissed() {
        val id = createAd()
        module.load(id, mock(Promise::class.java))
        adapters[0].callbacks.onAdLoaded()
        val ready = mock(Promise::class.java)
        module.isReady(id, ready)
        verify(ready).resolve(true)

        val show = mock(Promise::class.java)
        module.show(id, show)
        assertEquals(1, adapters[0].showCount)
        verify(show, never()).resolve(org.mockito.ArgumentMatchers.any())
        adapters[0].callbacks.onAdShowed()
        verify(show).resolve(null)
        adapters[0].callbacks.onAdImpression()
        adapters[0].callbacks.onAdClicked()
        adapters[0].callbacks.onAdDismissed()
        assertEquals(
            listOf("onAdLoaded", "onAdShowed", "onAdImpression", "onAdClicked", "onAdDismissed"),
            emitted().map { it.first }
        )
        assertEquals(0, adapters[0].destroyCount)
        module.destroy(id, mock(Promise::class.java))
        assertEquals(1, adapters[0].destroyCount)
    }

    @Test
    fun preconditionRejectionsEmitNothing() {
        val unknown = mock(Promise::class.java)
        module.show("nope", unknown)
        verify(unknown).reject("UNKNOWN_AD", "Unknown ad: nope")
        val id = createAd()
        val notReady = mock(Promise::class.java)
        module.show(id, notReady)
        verify(notReady).reject("NOT_READY", "The ad is not loaded yet")
        assertTrue(emitted().isEmpty())
    }

    @Test
    fun destroyIsIdempotentAndResolvesUnknownIds() {
        val id = createAd()
        module.load(id, mock(Promise::class.java))
        val first = mock(Promise::class.java)
        module.destroy(id, first)
        val second = mock(Promise::class.java)
        module.destroy(id, second)
        module.destroy("never-existed", mock(Promise::class.java))
        verify(first).resolve(null)
        verify(second).resolve(null)
        assertEquals(1, adapters[0].destroyCount)
    }

    @Test
    fun emitFailureDoesNotBreakPromiseSettlement() {
        val id = createAd()
        val promise = mock(Promise::class.java)
        module.load(id, promise)
        org.mockito.Mockito.doThrow(NullPointerException("no emitter")).`when`(emitter)
            .invoke(org.mockito.ArgumentMatchers.any())
        adapters[0].callbacks.onAdLoaded()
        verify(promise).resolve(null)
    }

    @Test
    fun invalidateRejectsPendingAndDestroysSdk() {
        val id = createAd()
        val promise = mock(Promise::class.java)
        module.load(id, promise)
        module.invalidate()
        module.invalidate()
        verify(promise, times(1)).reject(FullscreenErrorCodes.DESTROYED, "The ad was destroyed")
        assertEquals(1, adapters[0].destroyCount)
        verify(reactContext, times(1)).removeLifecycleEventListener(module)
    }

    @Test
    fun hostPauseAndResumeAreForwardedToTheController() {
        val id = createAd()
        module.load(id, mock(Promise::class.java))
        adapters.last().callbacks.onAdLoaded()
        module.onHostPause()
        val paused = mock(Promise::class.java)
        module.show(id, paused)
        verify(paused).reject(FullscreenErrorCodes.APP_IN_BACKGROUND, "The app is in the background; show the ad once it is in the foreground")
        assertEquals(0, adapters.last().showCount)
        module.onHostResume()
        module.show(id, mock(Promise::class.java))
        assertEquals(1, adapters.last().showCount)
    }

    @Test
    fun hostDestroyFailsPendingLoad() {
        val id = createAd()
        val promise = mock(Promise::class.java)
        module.load(id, promise)
        module.onHostDestroy()
        verify(promise).reject(
            FullscreenErrorCodes.ACTIVITY_LOST,
            "The Activity was destroyed while the ad was loading"
        )
        assertEquals("onAdFailedToLoad", emitted().single().first)
    }
}
