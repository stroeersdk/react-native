package com.stroeer.rn

import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.stroeer.ads.plugins.monitoring.IAdMonitorCallback
import com.stroeer.ads.plugins.monitoring.confiant.ConfiantLoader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentCaptor
import org.mockito.ArgumentMatchers.any
import org.mockito.ArgumentMatchers.anyBoolean
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mockito.doThrow
import org.mockito.Mockito.mock
import org.mockito.Mockito.never
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mockito.Mockito.verifyNoMoreInteractions
import org.mockito.Mockito.`when`
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class StroeerConfiantModuleTest {

    private class ManualScheduler : FullscreenScheduler {
        val tasks = mutableListOf<Runnable>()
        var cancelled = 0
        override fun postDelayed(delayMs: Long, task: Runnable): FullscreenCancellable {
            tasks.add(task)
            return FullscreenCancellable { cancelled++ }
        }
        fun fire() = tasks.toList().forEach { it.run() }
    }

    private lateinit var loader: ConfiantLoader
    private lateinit var scheduler: ManualScheduler
    private lateinit var module: StroeerConfiantModule
    private lateinit var promise: Promise

    @Before
    fun setUp() {
        loader = mock(ConfiantLoader::class.java)
        scheduler = ManualScheduler()
        promise = mock(Promise::class.java)
        module = StroeerConfiantModule(mock(ReactApplicationContext::class.java), loader, scheduler, 1_000L)
    }

    private fun captureCallback(): IAdMonitorCallback {
        val captor = ArgumentCaptor.forClass(IAdMonitorCallback::class.java)
        verify(loader).initialize(anyString(), anyBoolean(), captor.capture())
        return captor.value
    }

    @Test
    fun `module name is StroeerConfiantModule`() {
        assertEquals("StroeerConfiantModule", module.name)
    }

    @Test
    fun `blank property id is rejected without touching the SDK`() {
        module.initialize("  ", false, promise)

        verify(promise).reject("INVALID_ARGUMENT", "confiantPropertyId is blank")
        verify(loader, never()).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `resolves with the SDK result and settles once on a double callback`() {
        module.initialize("prop", true, promise)
        val callback = captureCallback()
        verify(loader).initialize("prop", true, callback)

        callback.onInitialized(true)
        callback.onInitialized(false)
        scheduler.fire()

        verify(promise, times(1)).resolve(true)
        verifyNoMoreInteractions(promise)
        assertEquals(1, scheduler.cancelled)
    }

    @Test
    fun `resolves false when the SDK reports failure`() {
        module.initialize("prop", false, promise)
        captureCallback().onInitialized(false)

        verify(promise).resolve(false)
    }

    @Test
    fun `rejects with INIT_FAILED when the SDK throws and ignores later callbacks`() {
        doThrow(IllegalStateException("boom")).`when`(loader).initialize(anyString(), anyBoolean(), any())

        module.initialize("prop", false, promise)

        verify(promise).reject(org.mockito.kotlin.eq("INIT_FAILED"), org.mockito.kotlin.eq("boom"), org.mockito.kotlin.any<Throwable>())
        scheduler.fire()
        verifyNoMoreInteractions(promise)
    }

    @Test
    fun `rejects with INIT_TIMEOUT when the callback never comes and ignores a late one`() {
        module.initialize("prop", false, promise)
        val callback = captureCallback()

        scheduler.fire()
        callback.onInitialized(true)

        verify(promise).reject(org.mockito.kotlin.eq("INIT_TIMEOUT"), anyString())
        verifyNoMoreInteractions(promise)
    }

    @Test
    fun `second initialize while one is pending is rejected`() {
        val second = mock(Promise::class.java)
        module.initialize("prop", false, promise)
        module.initialize("prop", false, second)

        verify(second).reject(org.mockito.kotlin.eq("ALREADY_INITIALIZING"), anyString())
        verify(loader, times(1)).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `retry after timeout does not call the loader again`() {
        val retry = mock(Promise::class.java)
        module.initialize("prop", false, promise)
        scheduler.fire()

        module.initialize("other", true, retry)

        verify(retry).reject(org.mockito.kotlin.eq("ALREADY_INITIALIZING"), anyString())
        verify(loader, times(1)).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `late callback after timeout is cached for later calls`() {
        module.initialize("prop", false, promise)
        val callback = captureCallback()
        scheduler.fire()
        callback.onInitialized(true)

        val retry = mock(Promise::class.java)
        module.initialize("prop", false, retry)

        verify(retry).resolve(true)
        verify(loader, times(1)).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `retry after a false result resolves false without calling the loader`() {
        module.initialize("prop", false, promise)
        captureCallback().onInitialized(false)

        val retry = mock(Promise::class.java)
        module.initialize("prop", false, retry)

        verify(retry).resolve(false)
        verify(loader, times(1)).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `initialize can be retried after the SDK threw`() {
        doThrow(IllegalStateException("boom")).`when`(loader).initialize(anyString(), anyBoolean(), any())
        module.initialize("prop", false, promise)
        module.initialize("prop", false, mock(Promise::class.java))

        verify(loader, times(2)).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `resolves true immediately when Confiant is already running`() {
        `when`(loader.isRunnable()).thenReturn(true)

        module.initialize("prop", false, promise)

        verify(promise).resolve(true)
        verify(loader, never()).initialize(anyString(), anyBoolean(), any())
    }

    @Test
    fun `enableTestMode is forwarded before initialize and ignored afterwards`() {
        module.enableTestMode()
        verify(loader, times(1)).enableTestMode()

        module.initialize("prop", false, promise)
        module.enableTestMode()

        verify(loader, times(1)).enableTestMode()
        assertTrue(scheduler.tasks.isNotEmpty())
    }
}
