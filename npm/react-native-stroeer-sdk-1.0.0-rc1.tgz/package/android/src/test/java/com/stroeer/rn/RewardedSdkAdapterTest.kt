package com.stroeer.rn

import android.app.Activity
import com.google.android.gms.ads.rewarded.RewardItem
import com.stroeer.ads.formats.rewarded.StroeerRewardedFullListener
import com.stroeer.ads.formats.rewarded.StroeerRewardedView
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotSame
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.mockito.Mockito.verify
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class RewardedSdkAdapterTest {

    private class Recorder : FullscreenSdkCallbacks {
        val rewards = mutableListOf<Pair<String?, Int?>>()
        var loaded = 0
        override fun onAdLoaded() { loaded++ }
        override fun onAdFailedToLoad(message: String?) = Unit
        override fun onAdShowed() = Unit
        override fun onAdDismissed() = Unit
        override fun onAdFailedToShow(message: String?) = Unit
        override fun onAdClicked() = Unit
        override fun onAdImpression() = Unit
        override fun onUserEarnedReward(type: String?, amount: Int?) {
            rewards.add(type to amount)
        }
    }

    private val activity: Activity = Robolectric.buildActivity(Activity::class.java).setup().get()

    @Test
    fun everyInstanceDisablesLoadAfterReady() {
        val views = mutableListOf<StroeerRewardedView>()
        val factory: (Activity) -> StroeerRewardedView = { mock(StroeerRewardedView::class.java).also { views.add(it) } }
        RewardedSdkAdapter(activity, factory)
        RewardedSdkAdapter(activity, factory)
        assertEquals(2, views.size)
        assertNotSame(views[0], views[1])
        views.forEach { view ->
            val setterCalls = org.mockito.Mockito.mockingDetails(view).invocations
                .filter { it.method.name == "setLoadAfterReady" }
            assertEquals(listOf<Any?>(false), setterCalls.map { it.arguments[0] })
        }
    }

    @Test
    fun forwardsRewardItemAndMissingItem() {
        val view = mock(StroeerRewardedView::class.java)
        val adapter = RewardedSdkAdapter(activity) { view }
        val callbacks = Recorder()
        adapter.load("slot", callbacks)

        // Kotlin non-null parameters make Mockito matchers unusable: inspect the invocation.
        val load = org.mockito.Mockito.mockingDetails(view).invocations.single { it.method.name == "load" }
        assertEquals("slot", load.arguments[0])
        val listener = load.arguments[1] as StroeerRewardedFullListener

        listener.onAdLoaded(null)
        val item = mock(RewardItem::class.java)
        org.mockito.Mockito.`when`(item.type).thenReturn("coins")
        org.mockito.Mockito.`when`(item.amount).thenReturn(5)
        listener.onUserEarnedReward(item)
        listener.onUserEarnedReward(null)
        assertEquals(1, callbacks.loaded)
        assertEquals(listOf<Pair<String?, Int?>>("coins" to 5, null to null), callbacks.rewards)
    }

    @Test
    fun showAndDestroyDelegate() {
        val view = mock(StroeerRewardedView::class.java)
        val adapter = RewardedSdkAdapter(activity) { view }
        adapter.show()
        adapter.destroy()
        verify(view).show()
        verify(view).destroy()
    }
}
