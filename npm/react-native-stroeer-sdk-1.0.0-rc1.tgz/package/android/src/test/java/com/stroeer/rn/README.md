# Unit Tests for Stroeer React Native SDK

This directory contains unit tests for the `com.stroeer.rn` package modules.

## Test Coverage

### Modules Tested

1. **StroeerModuleTest** - Tests for the main SDK module
   - Module name verification
   - SDK initialization with configuration
   - Debug and inspection mode
   - Personalized ads control
   - Module constants

2. **StroeerInterstitialModuleTest** - Tests for interstitial ad module
   - Ad loading
   - Ad showing
   - Ad state checking
   - Ad destruction
   - Multiple ad handling
   - Null activity handling

4. **StroeerConfiantModuleTest** - Tests for Confiant monitoring plugin
   - Module initialization
   - Property configuration
   - Diagnostics mode
   - Malicious ad handling
   - Consent state management

5. **StroeerIdentityModuleTest** - Tests for Identity management plugin
   - Module initialization
   - Partner ID configuration
   - Storage type settings
   - Debug mode
   - Consent state management

6. **StroeerPackageTest** - Tests for React Native package
   - Module registration
   - View manager registration
   - Name uniqueness validation
   - Proper instantiation

## Running the Tests

### From Command Line

```bash
# Run all tests
./gradlew test

# Run specific test class
./gradlew test --tests StroeerModuleTest

# Run specific test method
./gradlew test --tests StroeerModuleTest."test getName returns correct module name"

# Run tests with coverage report
./gradlew testDebugUnitTest jacocoTestReport
```

### From Android Studio

1. Right-click on the test file or test method
2. Select "Run 'TestName'"
3. View results in the Run window

## Test Framework

- **JUnit 4**: Testing framework
- **Mockito**: Mocking framework for creating test doubles
- **Mockito-Kotlin**: Kotlin extensions for Mockito

## Dependencies

Required test dependencies (already configured in build.gradle):

```gradle
testImplementation 'junit:junit:4.13.2'
testImplementation 'androidx.test:core:1.5.0'
testImplementation 'org.robolectric:robolectric:4.11.1'
testImplementation 'org.mockito:mockito-core:5.7.0'
testImplementation 'org.mockito.kotlin:mockito-kotlin:2.2.11'
```

## Test Structure

Each test class follows this structure:

```kotlin
@RunWith(MockitoJUnitRunner::class)
class ModuleTest {
    @Mock
    private lateinit var reactContext: ReactApplicationContext

    @Before
    fun setup() {
        // Initialize mocks and test subject
    }

    @Test
    fun `test description`() {
        // Given - setup test data
        // When - execute test action
        // Then - verify results
    }
}
```

## Writing New Tests

When adding new modules or features:

1. Create a new test file: `[ModuleName]Test.kt`
2. Follow the existing test structure
3. Mock React Native dependencies (ReactApplicationContext, Promise, etc.)
4. Test both success and failure paths
5. Test edge cases (null values, empty strings, etc.)

## Best Practices

- **Arrange-Act-Assert**: Structure tests with Given-When-Then pattern
- **Test Independence**: Each test should be independent and not rely on others
- **Mock External Dependencies**: Use Mockito to mock React Native and Android dependencies
- **Descriptive Names**: Use backticks for descriptive test names
- **Verify Behavior**: Use `verify()` to check that expected methods were called
- **Test Edge Cases**: Include tests for null values, empty inputs, and error conditions

## Continuous Integration

These tests should be run in CI/CD pipelines before merging code:

```yaml
# Example GitHub Actions workflow
- name: Run Unit Tests
  run: ./gradlew testDebugUnitTest

- name: Generate Coverage Report
  run: ./gradlew jacocoTestReport
```

## Coverage Goals

- **Module Tests**: 80%+ coverage for business logic
- **Package Tests**: 100% coverage for module registration
- **Integration Points**: Full coverage for React Native bridge methods

## Troubleshooting

### Tests not found
- Ensure test files are in `src/test/java/` directory
- Check that class names end with `Test`
- Verify JUnit dependency is present

### Mocking issues
- Make sure Mockito and Mockito-Kotlin are properly configured
- Use `@Mock` annotation for dependencies
- Initialize mocks in `@Before` method

### React Native context issues
- Mock `ReactApplicationContext` properly
- Mock `currentActivity` when testing Activity-dependent code
- Use `whenever()` to define mock behavior

## Future Improvements

- [ ] Add integration tests
- [ ] Increase test coverage to 90%+
- [ ] Add UI tests for banner view manager
- [ ] Add performance tests
- [ ] Add snapshot tests for view rendering
