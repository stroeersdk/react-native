package com.stroeer.rn

import android.app.Activity
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import com.facebook.react.bridge.DynamicFromObject
import com.facebook.react.bridge.JavaOnlyArray
import com.facebook.react.bridge.JavaOnlyMap
import com.facebook.react.bridge.BridgeReactContext
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.mock
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.lang.ref.WeakReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
class StroeerBannerContainerTest {

    private class FakeAdapter(activity: Activity) : BannerSdkAdapter {
        // Like a creative-less banner: wraps to 0x0 unless measured with an exact spec.
        override val view: View = object : View(activity) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                val exactWidth = MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY
                val exactHeight = MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY
                setMeasuredDimension(
                    if (exactWidth) MeasureSpec.getSize(widthMeasureSpec) else 0,
                    if (exactHeight) MeasureSpec.getSize(heightMeasureSpec) else 0
                )
            }
        }
        override var adSlotId: String = ""
        override var adSize = BannerAdSizeDp(320, 50)
        override var source: String = "gam"

        var configuredUrl: String? = "unset"
        var configuredTargeting: Map<String, String>? = null
        var loadCount = 0
        var destroyCount = 0
        var loadedSlot: String? = null
        var throwOnLoad: Exception? = null
        var throwOnConfigure: Exception? = null
        var throwOnDestroy: Exception? = null

        // Like the SDK, hold the listener only weakly.
        private var weakCallbacks: WeakReference<BannerSdkCallbacks>? = null
        val callbacks: BannerSdkCallbacks get() = weakCallbacks!!.get()!!

        override fun configure(contentUrl: String?, customTargeting: Map<String, String>) {
            throwOnConfigure?.let { throw it }
            configuredUrl = contentUrl
            configuredTargeting = customTargeting
        }

        override fun load(adSlotId: String, callbacks: BannerSdkCallbacks) {
            throwOnLoad?.let { throw it }
            loadCount++
            loadedSlot = adSlotId
            this.adSlotId = adSlotId
            weakCallbacks = WeakReference(callbacks)
        }

        override fun destroy() {
            destroyCount++
            throwOnDestroy?.let { throw it }
        }
    }

    private lateinit var activity: Activity
    private lateinit var container: StroeerBannerContainer
    private val adapters = mutableListOf<FakeAdapter>()
    private val events = mutableListOf<BannerEventPayload>()
    private var activityAvailable = true
    private var factoryError: Exception? = null
    private var adapterSetup: (FakeAdapter) -> Unit = {}

    // When set, the provider returns this Activity instead of the attached one.
    private var providedActivity: Activity? = null

    @Before
    fun setup() {
        activity = Robolectric.buildActivity(Activity::class.java).setup().get()
        container = StroeerBannerContainer(
            activity,
            activityProvider = { if (activityAvailable) providedActivity ?: activity else null },
            eventSink = { _, payload -> events.add(payload) },
            adapterFactory = { act ->
                factoryError?.let { throw it }
                FakeAdapter(act).also { adapterSetup(it); adapters.add(it) }
            }
        )
        container.id = 42
    }

    private fun attach() {
        activity.setContentView(container)
        idle()
    }

    private fun idle() = shadowOf(Looper.getMainLooper()).idle()

    private fun commit(
        slot: String? = "slot",
        url: String? = null,
        targeting: Map<String, String>? = emptyMap(),
        idle: Boolean = true
    ) {
        container.setSlotName(slot)
        container.setContentUrl(url)
        container.setCustomTargeting(targeting)
        container.commitConfig()
        if (idle) idle()
    }

    @Test
    fun `commit before attach loads once on attach`() {
        commit()
        assertEquals(0, adapters.size)
        attach()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals("slot", adapters[0].loadedSlot)
        assertNull(adapters[0].configuredUrl)
        assertSame(adapters[0].view, container.getChildAt(0))
    }

    @Test
    fun `commit after attach loads once`() {
        attach()
        commit()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
    }

    @Test
    fun `configure receives normalized content url and targeting`() {
        attach()
        commit(url = "https://example.com", targeting = mapOf("a" to "b"))
        assertEquals("https://example.com", adapters[0].configuredUrl)
        assertEquals(mapOf("a" to "b"), adapters[0].configuredTargeting)
    }

    @Test
    fun `identical and equivalent config does not reload`() {
        attach()
        commit(targeting = mapOf("a" to "1", "b" to "2"))
        commit(targeting = mapOf("b" to "2", "a" to "1"))
        commit(url = "", targeting = mapOf("a" to "1", "b" to "2"))
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)
    }

    @Test
    fun `slot, url and targeting changes each replace the banner once`() {
        attach()
        commit()
        commit(slot = "other")
        assertEquals(2, adapters.size)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals("other", adapters[1].loadedSlot)

        commit(slot = "other", url = "https://x.de")
        assertEquals(3, adapters.size)
        assertEquals(1, adapters[1].destroyCount)

        commit(slot = "other", url = "https://x.de", targeting = mapOf("k" to "v"))
        assertEquals(4, adapters.size)
        assertEquals(1, adapters[2].destroyCount)
        assertEquals(0, adapters[3].destroyCount)
        assertEquals(1, container.childCount)
        assertSame(adapters[3].view, container.getChildAt(0))
    }

    @Test
    fun `stale callbacks from a replaced banner are ignored`() {
        attach()
        commit()
        val old = adapters[0]
        val oldCallbacks = old.callbacks
        commit(slot = "other")
        events.clear()

        oldCallbacks.onAdLoaded()
        oldCallbacks.onAdImpression()
        oldCallbacks.onAdFailedToLoad("late")
        oldCallbacks.onAdClicked()
        assertTrue(events.isEmpty())

        adapters[1].callbacks.onAdLoaded()
        assertEquals(1, events.size)
        assertEquals("other", events[0].publisherSlotName)
    }

    private fun hostContainer(): Pair<ReactContext, StroeerBannerContainer> {
        val reactContext = BridgeReactContext(activity)
        val hosted = StroeerBannerContainer(
            reactContext,
            activityProvider = { if (activityAvailable) providedActivity ?: activity else null },
            eventSink = { _, payload -> events.add(payload) },
            adapterFactory = { act -> FakeAdapter(act).also { adapterSetup(it); adapters.add(it) } }
        )
        hosted.id = 43
        return reactContext to hosted
    }

    @Test
    fun `missing activity waits silently and a later identical commit loads once`() {
        activityAvailable = false
        attach()
        commit()
        commit()
        assertEquals(0, adapters.size)
        assertTrue(events.isEmpty())

        activityAvailable = true
        commit()
        commit()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `activity restored by detach and reattach loads once`() {
        activityAvailable = false
        attach()
        commit()
        assertEquals(0, adapters.size)

        activityAvailable = true
        (container.parent as ViewGroup).removeView(container)
        idle()
        assertEquals(0, adapters.size)
        activity.setContentView(container)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `activity restored by host resume loads once and resume never reloads`() {
        val (reactContext, hosted) = hostContainer()
        activityAvailable = false
        activity.setContentView(hosted)
        hosted.setSlotName("slot")
        hosted.commitConfig()
        idle()
        assertEquals(0, adapters.size)

        activityAvailable = true
        reactContext.onHostResume(activity)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)

        reactContext.onHostResume(activity)
        reactContext.onHostResume(activity)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `host resume after dispose does nothing`() {
        val (reactContext, hosted) = hostContainer()
        activityAvailable = false
        activity.setContentView(hosted)
        hosted.setSlotName("slot")
        hosted.commitConfig()
        idle()

        hosted.dispose()
        activityAvailable = true
        reactContext.onHostResume(activity)
        idle()
        assertEquals(0, adapters.size)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `host resume without attachment does not load`() {
        val (reactContext, hosted) = hostContainer()
        hosted.setSlotName("slot")
        hosted.commitConfig()
        reactContext.onHostResume(activity)
        idle()
        assertEquals(0, adapters.size)
    }

    @Test
    fun `null, finishing and destroyed activities are unavailable`() {
        attach()

        activityAvailable = false
        commit()
        assertEquals(0, adapters.size)
        activityAvailable = true

        val finishing = Robolectric.buildActivity(Activity::class.java).setup().get()
        finishing.finish()
        providedActivity = finishing
        commit()
        assertEquals(0, adapters.size)

        val destroyed = Robolectric.buildActivity(Activity::class.java).setup().destroy().get()
        providedActivity = destroyed
        commit()
        assertEquals(0, adapters.size)
        assertTrue(events.isEmpty())

        providedActivity = null
        commit()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
    }

    @Test
    fun `invalid config fails once and loads nothing`() {
        attach()
        commit(slot = "")
        commit(slot = "")
        assertEquals(1, events.size)
        assertEquals(BannerErrorCodes.INVALID_ARGUMENT, events[0].errorCode)

        commit(targeting = null)
        assertEquals(2, events.size)
        assertEquals(BannerErrorCodes.INVALID_ARGUMENT, events[1].errorCode)
        assertEquals(0, adapters.size)
    }

    @Test
    fun `invalid config destroys the previous banner`() {
        attach()
        commit()
        commit(slot = "")
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(0, container.childCount)
    }

    @Test
    fun `exception while creating the banner reports SETUP_FAILED`() {
        factoryError = IllegalStateException("boom")
        attach()
        commit()
        assertEquals(BannerErrorCodes.SETUP_FAILED, events.single().errorCode)
        assertEquals("boom", events.single().errorMessage)
    }

    private fun assertSetupFailedOnce(adapter: FakeAdapter, message: String) {
        assertEquals(1, adapters.size)
        assertEquals(0, adapter.loadCount)
        assertEquals(1, adapter.destroyCount)
        assertEquals(0, container.childCount)
        assertEquals(BannerErrorCodes.SETUP_FAILED, events.single().errorCode)
        assertEquals(message, events.single().errorMessage)
    }

    private fun assertNoRetryAfterFailure(adapter: FakeAdapter) {
        commit()
        (container.parent as ViewGroup).removeView(container)
        idle()
        activity.setContentView(container)
        idle()
        container.dispose()
        container.dispose()
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapter.destroyCount)
        assertEquals(1, events.size)
    }

    @Test
    fun `configure failure destroys the adapter once and reports once`() {
        adapterSetup = { it.throwOnConfigure = IllegalStateException("configure boom") }
        attach()
        commit()
        assertSetupFailedOnce(adapters[0], "configure boom")
        assertNoRetryAfterFailure(adapters[0])
    }

    @Test
    fun `addView failure destroys the adapter once and reports once`() {
        val stray = android.widget.FrameLayout(activity)
        adapterSetup = { stray.addView(it.view) }
        attach()
        commit()
        assertSetupFailedOnce(adapters[0], events.single().errorMessage!!)
        assertNoRetryAfterFailure(adapters[0])
    }

    @Test
    fun `host resume after a setup failure does not retry`() {
        val (reactContext, hosted) = hostContainer()
        adapterSetup = { it.throwOnConfigure = IllegalStateException("configure boom") }
        activity.setContentView(hosted)
        hosted.setSlotName("slot")
        hosted.commitConfig()
        idle()
        reactContext.onHostResume(activity)
        reactContext.onHostResume(activity)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, events.size)
        hosted.dispose()
        assertEquals(1, adapters[0].destroyCount)
    }

    @Test
    fun `config change after a setup failure loads the replacement once`() {
        adapterSetup = { if (adapters.isEmpty()) it.throwOnConfigure = IllegalStateException("boom") }
        attach()
        commit()
        commit(slot = "other")
        assertEquals(2, adapters.size)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, adapters[1].loadCount)
        assertEquals(0, adapters[1].destroyCount)
        assertEquals(1, events.size)
    }

    @Test
    fun `throwing destroy during setup failure keeps the original error and destroys once`() {
        adapterSetup = {
            it.throwOnConfigure = IllegalStateException("configure boom")
            it.throwOnDestroy = IllegalStateException("destroy boom")
        }
        attach()
        commit()
        assertSetupFailedOnce(adapters[0], "configure boom")
        container.dispose()
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, events.size)
    }

    @Test
    fun `exception while loading reports SETUP_FAILED`() {
        // Factory-created adapters throw on load.
        val throwing = StroeerBannerContainer(
            activity,
            activityProvider = { activity },
            eventSink = { _, payload -> events.add(payload) },
            adapterFactory = { act ->
                FakeAdapter(act).also {
                    it.throwOnLoad = IllegalStateException("load boom")
                    adapters.add(it)
                }
            }
        )
        throwing.id = 7
        activity.setContentView(throwing)
        throwing.setSlotName("slot")
        throwing.commitConfig()
        idle()
        assertEquals(BannerErrorCodes.SETUP_FAILED, events.single().errorCode)
        assertEquals("load boom", events.single().errorMessage)
    }

    @Test
    fun `loaded and impression are both delivered with the live size`() {
        attach()
        commit()
        val adapter = adapters[0]
        adapter.callbacks.onAdLoaded()
        adapter.adSize = BannerAdSizeDp(300, 250)
        adapter.callbacks.onAdImpression()

        assertEquals(2, events.size)
        assertEquals(BannerEventType.LOADED, events[0].type)
        assertEquals(320, events[0].width)
        assertEquals(50, events[0].height)
        assertEquals("gam", events[0].source)
        assertEquals("slot", events[0].publisherSlotName)
        assertEquals(BannerEventType.IMPRESSION, events[1].type)
        assertEquals(300, events[1].width)
        assertEquals(250, events[1].height)
    }

    @Test
    fun `relayout is applied before loaded is reported`() {
        attach()
        commit()
        val adapter = adapters[0]
        adapter.callbacks.onAdLoaded()
        assertEquals(320, adapter.view.width)
        assertEquals(50, adapter.view.height)
    }

    @Test
    fun `open, close and click are forwarded`() {
        attach()
        commit()
        val callbacks = adapters[0].callbacks
        callbacks.onAdOpened()
        callbacks.onAdClosed()
        callbacks.onAdClicked()
        assertEquals(
            listOf(BannerEventType.OPENED, BannerEventType.CLOSED, BannerEventType.CLICKED),
            events.map { it.type }
        )
    }

    @Test
    fun `detach and reattach keeps the instance and does not reload`() {
        attach()
        commit()
        val parent = container.parent as ViewGroup
        parent.removeView(container)
        idle()
        adapters[0].callbacks.onAdLoaded()
        activity.setContentView(container)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)
        assertEquals(1, container.childCount)
    }

    @Test
    fun `relayout is skipped while detached`() {
        attach()
        commit()
        val adapter = adapters[0]
        (container.parent as ViewGroup).removeView(container)
        idle()
        adapter.callbacks.onAdLoaded()
        assertEquals(0, adapter.view.width)
    }

    @Test
    fun `dispose destroys exactly once and drops callbacks`() {
        attach()
        commit()
        val adapter = adapters[0]
        val callbacks = adapter.callbacks
        container.dispose()
        container.dispose()
        assertEquals(1, adapter.destroyCount)
        assertEquals(0, container.childCount)

        events.clear()
        callbacks.onAdLoaded()
        assertTrue(events.isEmpty())

        // No further loads after dispose.
        container.setSlotName("again")
        container.commitConfig()
        idle()
        assertEquals(1, adapters.size)
    }

    @Test
    fun `refresh failure keeps the creative and the instance`() {
        attach()
        commit()
        val adapter = adapters[0]
        adapter.callbacks.onAdLoaded()
        adapter.callbacks.onAdFailedToLoad("refresh failed")

        assertEquals(BannerEventType.FAILED_TO_LOAD, events.last().type)
        assertEquals(BannerErrorCodes.LOAD_FAILED, events.last().errorCode)
        assertEquals("refresh failed", events.last().errorMessage)
        assertEquals(0, adapter.destroyCount)
        assertEquals(1, container.childCount)

        // The instance keeps working afterwards.
        adapter.callbacks.onAdImpression()
        assertEquals(BannerEventType.IMPRESSION, events.last().type)
    }

    @Test
    fun `container retains the listener against the weak SDK reference`() {
        attach()
        commit()
        System.gc()
        System.runFinalization()
        adapters[0].callbacks.onAdLoaded()
        assertNotNull(events.singleOrNull())
    }

    @Test
    fun `events are dropped while the view has no id`() {
        container.id = View.NO_ID
        attach()
        commit()
        adapters[0].callbacks.onAdLoaded()
        assertTrue(events.isEmpty())
    }

    @Test
    fun `config change while detached invalidates the pending load`() {
        attach()
        commit(idle = false)
        val old = adapters[0]
        (container.parent as ViewGroup).removeView(container)
        commit(slot = "other", idle = false)
        idle()
        assertEquals(0, old.loadCount)
        assertEquals(1, old.destroyCount)
        assertEquals(0, container.childCount)
        assertTrue(events.isEmpty())

        activity.setContentView(container)
        idle()
        assertEquals(2, adapters.size)
        assertEquals("other", adapters[1].loadedSlot)
        assertEquals(1, adapters[1].loadCount)
    }

    @Test
    fun `dispose before the posted load runs prevents the load`() {
        attach()
        commit(idle = false)
        container.dispose()
        idle()
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
    }

    @Test
    fun `replacement before the posted load runs prevents the old load`() {
        attach()
        commit(idle = false)
        commit(slot = "other", idle = false)
        idle()
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, adapters[1].loadCount)
    }

    @Test
    fun `activity lost before the posted load runs discards the prepared banner`() {
        attach()
        commit(idle = false)
        activityAvailable = false
        idle()
        assertEquals(1, adapters.size)
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(0, container.childCount)
        assertTrue(events.isEmpty())

        // The config stayed unattempted: it loads once the Activity is back.
        activityAvailable = true
        commit()
        assertEquals(2, adapters.size)
        assertEquals(1, adapters[1].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `activity finishing before the posted load runs discards the prepared banner`() {
        attach()
        commit(idle = false)
        activity.finish()
        idle()
        assertEquals(1, adapters.size)
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `activity replaced before the posted load runs loads once on the replacement`() {
        attach()
        // Built first: setting an Activity up drains the main looper.
        val replacement = Robolectric.buildActivity(Activity::class.java).setup().get()
        commit(idle = false)
        providedActivity = replacement
        idle()
        assertEquals(2, adapters.size)
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, adapters[1].loadCount)
        assertEquals(0, adapters[1].destroyCount)
        assertEquals(1, container.childCount)
        assertSame(adapters[1].view, container.getChildAt(0))
        assertTrue(events.isEmpty())
    }

    @Test
    fun `config change while waiting for an activity loads only the latest config`() {
        activityAvailable = false
        attach()
        commit(slot = "first")
        commit(slot = "second")
        assertEquals(0, adapters.size)

        activityAvailable = true
        commit(slot = "second")
        assertEquals(1, adapters.size)
        assertEquals("second", adapters[0].loadedSlot)
        assertEquals(1, adapters[0].loadCount)
    }

    // ---- Deferred load: attachment and layout gates ----

    private fun detach() {
        (container.parent as ViewGroup).removeView(container)
    }

    /** Attached but never laid out: GONE children are skipped by the layout pass. */
    private fun attachUnlaidOut() {
        container.visibility = View.GONE
        activity.setContentView(container)
        idle()
        assertFalse(container.isLaidOut)
    }

    private fun layOut() {
        container.visibility = View.VISIBLE
        idle()
        assertTrue(container.isLaidOut)
    }

    @Test
    fun `detach before the posted load runs prevents the load until reattach`() {
        attach()
        commit(idle = false)
        detach()
        idle()
        assertEquals(1, adapters.size)
        assertEquals(0, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)

        activity.setContentView(container)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `detach and reattach before the original post runs loads exactly once`() {
        attach()
        commit(idle = false)
        detach()
        activity.setContentView(container)
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
    }

    @Test
    fun `attached but not laid out waits for the container layout`() {
        attachUnlaidOut()
        commit()
        idle()
        assertEquals(1, adapters.size)
        assertEquals(0, adapters[0].loadCount)

        layOut()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)
    }

    @Test
    fun `container laid out at zero size loads and still relayouts the banner`() {
        activity.setContentView(container, ViewGroup.LayoutParams(0, 0))
        idle()
        commit()
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].view.width)

        adapters[0].callbacks.onAdLoaded()
        assertEquals(320, adapters[0].view.width)
        assertEquals(50, adapters[0].view.height)
    }

    @Test
    fun `repeated layout, resume and identical commits never duplicate the load`() {
        val (reactContext, hosted) = hostContainer()
        hosted.visibility = View.GONE
        activity.setContentView(hosted)
        idle()
        hosted.setSlotName("slot")
        hosted.commitConfig()
        hosted.commitConfig()
        reactContext.onHostResume(activity)
        reactContext.onHostResume(activity)
        hosted.visibility = View.VISIBLE
        hosted.requestLayout()
        hosted.requestLayout()
        hosted.commitConfig()
        idle()
        hosted.requestLayout()
        reactContext.onHostResume(activity)
        hosted.commitConfig()
        idle()
        assertEquals(1, adapters.size)
        assertEquals(1, adapters[0].loadCount)
        assertEquals(0, adapters[0].destroyCount)
    }

    @Test
    fun `activity changed while detached discards the old banner on reattach`() {
        val replacement = Robolectric.buildActivity(Activity::class.java).setup().get()
        attach()
        commit(idle = false)
        detach()
        idle()
        providedActivity = replacement
        activity.setContentView(container)
        idle()

        assertEquals(2, adapters.size)
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertSame(replacement, adapters[1].view.context)
        assertEquals(1, adapters[1].loadCount)
        assertEquals(0, adapters[1].destroyCount)
        assertEquals(1, container.childCount)
        assertTrue(events.isEmpty())
    }

    @Test
    fun `dispose while awaiting layout or detached prevents the load`() {
        attachUnlaidOut()
        commit()
        container.dispose()
        layOut()
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(0, adapters[0].loadCount)

        // Detached variant.
        val second = StroeerBannerContainer(
            activity,
            activityProvider = { activity },
            eventSink = { _, payload -> events.add(payload) },
            adapterFactory = { act -> FakeAdapter(act).also { adapters.add(it) } }
        )
        second.id = 44
        activity.setContentView(second)
        idle()
        second.setSlotName("slot")
        second.commitConfig()
        (second.parent as ViewGroup).removeView(second)
        second.dispose()
        activity.setContentView(second)
        idle()
        assertEquals(2, adapters.size)
        assertEquals(0, adapters[1].loadCount)
        assertEquals(1, adapters[1].destroyCount)
    }

    @Test
    fun `config change while awaiting layout loads only the latest config`() {
        attachUnlaidOut()
        commit(slot = "first")
        commit(slot = "second")
        layOut()
        assertEquals(2, adapters.size)
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals("second", adapters[1].loadedSlot)
        assertEquals(1, adapters[1].loadCount)
    }

    @Test
    fun `config change while detached loads only the latest config after reattach`() {
        attach()
        commit(slot = "first", idle = false)
        detach()
        commit(slot = "second", idle = false)
        idle()
        activity.setContentView(container)
        idle()
        assertEquals(0, adapters[0].loadCount)
        assertEquals(1, adapters[0].destroyCount)
        assertEquals(1, adapters[1].loadCount)
        assertEquals("second", adapters[1].loadedSlot)
    }

    // ---- BannerEvent / targeting / manager ----

    @Test
    fun `banner events are never coalesced`() {
        for (type in BannerEventType.values()) {
            val event = BannerEvent(1, 2, BannerEventPayload(type, "slot"))
            assertFalse(event.canCoalesce())
            assertEquals(type.eventName, event.eventName)
        }
    }

    @Test
    fun `parseCustomTargeting copies string maps`() {
        val map = JavaOnlyMap.of("a", "1", "b", "2")
        assertEquals(mapOf("a" to "1", "b" to "2"), parseCustomTargeting(DynamicFromObject(map)))
    }

    @Test
    fun `parseCustomTargeting treats null as empty`() {
        assertEquals(emptyMap<String, String>(), parseCustomTargeting(DynamicFromObject(null)))
        assertEquals(emptyMap<String, String>(), parseCustomTargeting(null))
    }

    @Test
    fun `parseCustomTargeting rejects non-string values and non-maps`() {
        assertNull(parseCustomTargeting(DynamicFromObject(JavaOnlyMap.of("a", 1.0))))
        assertNull(parseCustomTargeting(DynamicFromObject(JavaOnlyArray.of("a"))))
        assertNull(parseCustomTargeting(DynamicFromObject("text")))
    }

    @Test
    fun `manager exports direct event registrations`() {
        val manager = StroeerBannerViewManager(mock(ReactApplicationContext::class.java))
        assertEquals("StroeerBannerView", manager.name)
        val constants = manager.exportedCustomDirectEventTypeConstants!!
        for (name in listOf("Loaded", "Impression", "FailedToLoad", "Opened", "Closed", "Clicked")) {
            assertEquals(
                mapOf("registrationName" to "onAd$name"),
                constants["topAd$name"]
            )
        }
    }
}
