# Ströer SDK for React Native

The Ströer SDK helps publishers integrate banner, interstitial, and rewarded ads into React Native applications on Android and iOS. Optional modules add consent management (CMP), identity, and ad-quality protection with Confiant.

npm package: `react-native-stroeer-sdk`

## Change log
### [1.0.0] (07.Oct.2026)

#### New
- Rebranded the SDK as StröerSDK.
- Changed the package name to `com.stroeer.ads`. (Android)
- Updated the library repository: GitHub – StröerSDK Android. (Android)
- Added a Jetpack Compose wrapper (`com.stroeer.compose`). (Android)
- Configuration is now revalidated using an ETag instead of being re-downloaded on every refresh. (Android)
- The React Native bridge is now built for the New Architecture only (React Native 0.82): every module is a codegen TurboModule and the banner is a Fabric component.
- Interstitial and rewarded ads are now ad handles (`create` → `load` → `show` → `destroy`). Several ads can be loaded at the same time, and hooks and components each own their ad, so they no longer replace each other's listeners.
- Every banner, interstitial and rewarded event is logged by the native SDK. (Android)

#### Fixed
- Corrected the precedence of key-values and `contentUrl` for GAM. Key-values from remote configuration are now also included in Prebid requests. (Android)
- Ad size is now rechecked at impression time, as the size of some banners is determined only when the impression occurs. (Android)
- The SDK no longer adds an app-name label to the merged manifest. (Android)
- Banner: `onAdLoaded` is no longer lost when an impression follows immediately, and every load failure is now reported to `onAdFailedToLoad`.
- Interstitial and rewarded ads no longer show automatically after loading, and `show()` now resolves once the ad is actually presented.
- Rewarded: loading again after a failed load works, and a reward that arrives after the ad is dismissed is still delivered.
- `clearConfigurationCache()` no longer clears the app's default shared preferences (including consent); it now only requests a fresh configuration.
- User and context targeting is now sent to Prebid in the correct place; GAM receives the same key-values as before.
- Release JS bundling of the example app works again in the monorepo.
- Fixed various minor bugs.

#### Changed
- The SDK version reported to GAM and Prebid now follows the new versioning scheme (major + 20). (Android)
- Removed the OkHttp dependency. (Android)
- SDK libraries are now obfuscated. (Android)
- Updated third-party library versions (Android):
  - Prebid Mobile: 3.3.4
  - SourcePoint: 7.15.13
  - Google Mobile Ads SDK: 24.6.0 (publishers can upgrade to a later version)
  - Kotlin: 2.1.0 (publishers can upgrade to a later version)
- The iOS native SDK is now the `StroeerSDK` pod (1.0.0-rc.3), which replaces `YieldloveAdIntegration`. It is installed from `https://stroeersdk.github.io/iOS/CocoaPods/StroeerSDK.podspec` with the subspecs `Core` (default) and `Consent`. (iOS)
- Updated third-party library versions (iOS):
  - Prebid Mobile: 3.4.1
  - Google Mobile Ads SDK: 13.7.0
  - ConsentViewController (SourcePoint): ~> 7.12
- Errors are now reported as `{ code, message }`. A missing native module is reported with the code `MODULE_UNAVAILABLE`.
- Jetifier is no longer required. (Android)

#### Breaking changes (React Native API)
- **Banner (`StroeerBannerAd`)**: loading is driven by props. It reloads when `publisherSlotName`, `contentUrl` or `customTargeting` change in value; change the React `key` to force a reload. `onAdFailedToLoad` receives `{ code, message }`. The `destroyWhenDetached` prop is removed.
- **Interstitial and rewarded**: use `const ad = await StroeerInterstitial.create(slot)` (or `StroeerRewarded.create(slot)`), then `ad.subscribe(...)`, `ad.load()`, `ad.show()` and `ad.destroy()`. `setLoadAfterReady`, `setListeners` and `removeAllListeners` are removed. `useStroeerInterstitial` / `useStroeerRewarded` and the `StroeerInterstitialAd` / `StroeerRewardedAd` components (controlled through a ref) are kept on the new API.
- **StroeerSDK**:
  - `setUserTargeting`, `setContextTargeting`, `setContextDataTargeting` and `setCustomTargeting` are replaced by `setGlobalCustomTargeting({ user: [...], context: [...], <key>: [...] })`.
  - `reloadConfigurationAndGetSlotNames` is renamed to `resetAndLoadConfiguration`.
  - `setApplicationName` and `clearConfigurationCache` return Promises.
  - `getSlotNames` rejects with `CONFIG_NOT_LOADED` instead of resolving `null`, and `getConfiguration` resolves `null` when no configuration is loaded.
- **StroeerIdentity**: `setEmail`, `setPhone`, `setPuid`, `setRegionCode`, `setCityCode` and `apply` are replaced by `setCustomInfo({ email, phone, puid, regionCode, cityCode })`.
- **StroeerConfiant**: `initialize` resolves only once; a second call while it is running rejects with `ALREADY_INITIALIZING`.
- **IabTestConsent** is removed from the library; it is test tooling and now lives in the example app.

### [4.2.2] (29.May.2026)
- Fixed the issue that UI in a scroll view may not be displayed correctly
- Updated the podspec file to use ~> 10.5.0 for YieldloveAdIntegration, so CocoaPods resolves only 10.5.x versions

### [4.2.1] (18.May.2026)
- Added web Debug pages.
- DisplayManager and DisplayManagerVer are updated. ("StroeerSDK", "10.5.0")
- General bug fixes and stability improvements.
- Disabled banner reloading for Confiant temporarily. (Android)
- Updated third-party libraries (iOS)
  - CMP: 7.12.9
  - Google Mobile Ads SDK: 12.11.0>
- Updated third-party libraries:
  - CMP: 7.15.11
  - Google Mobile Ads SDK: 25.1.0
  - Prebid: 3.3.0

### [4.1.2] (21.Mar.2026)
- Use EventDispatcher instead of UIManagerModule (bridgeless compatibility)

### [4.1.1] (17.Mar.2026)
- Support custom targeting

### [4.1.0] (2.Mar.2026)
- Added support for IO campaign banners from Ströer.(Android, iOS)
- Implemented disableErrorLog. When enabled, Android error messages will be replaced with informational messages. The default value is false.(Android)
- Fixed a minor issue related to configuration loading. (Android)
- Enhanced debug panel with more detailed information.(iOS)
- General bug fixes and stability improvements (iOS)

### [4.0.0] (22.Jan.2026)
- Class names are updated to Stroeer. Yieldlove is deprecated
- React-Native version is updated to 80.2
- Kotlin version is updated to 2.1.0
- Implemented debug panels
- Improved the banner size management
- All legacy RN modules are updated

### [3.1.7] (27.Sep.2025)
- Added a log to track the SDK version.
- Added additional logs to help diagnose issues.
- Improved the stability of banner resizing.

### [3.1.6] (27.Sep.2025)
- Fixed : prevent fluid-size banner from being clipped

### [3.1.3] (29.July.2025)
- Fixed the issue that React compile fails.
- Rollback to 0.73.4 for react-native version
- Do not use 3.1.2 version, which may cause the compile error (removed the version from the change log)

### [3.1.1] (07.July.2025)
- Fixed the issue that the landscape mode may break the ad layout on iOS.
- react-native version is updated to 0.76.4

### [3.1.0] (05.June.2025)
- Removed CriteoSDK
- Enabled/Disabled Confiant via the setting from the SDK server
- Will attempted to initialize Confiant again when it failed.
- Upgraded the debug information panel
- Displayed the version number
- Improved the error message from the SDK
- Supported Fluid size for Google Ad
- Disabled Gravite Shake Debug mode
- Displayed the Gravite debug information via the debug panel (Android)
- Disabled Gravite Shake Debug mode by default. This will be enabled when inspection mode is enabled. (iOS)
- Fixed the issue that applications can obfuscate the SDK, which can result in disabling ID5
- Yieldlove.developerModeEnabled is obsolete. Use Yieldlove.enableInspectionMode()
- Yieldlove.debug is obsolete. Use Yieldlove.enableDebugMode()


### [3.0.0] (25.March.2025)
- Updated Gravite SDK version:
  - iOS: 3.12.0
  - Android: 3.12.5
- Updated Kotlin version is 2.0
- Fixed an issue where the banner size from Gravite was not being set correctly.
- Fixed an issue where the zone was excluded in the placement name for Gravite


## Requirements
- React Native 0.82.1 or above (the New Architecture is always enabled — RN 0.82 removed the legacy architecture)
- React 19.1.1 or above
- Node 20.19.4 or above
- Android Min SDK 24
- iOS 15.1 or above (Xcode 16.1 or above)
- Kotlin 2.1.20

### iOS native SDK
The iOS native SDK is distributed as the `StroeerSDK` pod. Add it to your app's `Podfile`, adding the `Consent` subspec if you use consent management (CMP):

```ruby
pod 'StroeerSDK', :podspec => 'https://stroeersdk.github.io/iOS/CocoaPods/StroeerSDK.podspec', :subspecs => ['Core', 'Consent']
```

### Integration Document
[React Native Integration Document](https://stroeerdigitalgroup.atlassian.net/wiki/spaces/SDGPUBLIC/pages/5024874499/React+Native+Integraiton+document)

## Use Confiant.
For more detailed information, refer to the [Development Document Link](https://stroeerdigitalgroup.atlassian.net/wiki/x/A4CBKwE)

## Testing ads

Please contact your account manager to get your test configuration.

## Troubleshooting

#### My application crashes on start

The Google Mobile Ads SDK may be initialized without an application ID.

_Ad Manager_

iOS: [Update your Info.plist](https://developers.google.com/ad-manager/mobile-ads-sdk/ios/quick-start#update_your_infoplist).
Android: [Get Started](https://developers.google.com/ad-manager/mobile-ads-sdk/android/quick-start)

_AdMob_

iOS: [Update your Info.plist](https://developers.google.com/admob/ios/quick-start#update_your_infoplist).
Android: [Get Started](https://developers.google.com/admob/android/quick-start)


Release Notes

### [2.6.1] (01.October.2024)
- Gravite and Confiant are added as Plugin
- Support Stroeer to Gravite Placements Mapping Table.
- Support Gravite Direct Call
- Added the ad source. (Stroeer / Gravite)
- Disabled the error log for error report requests.

### [2.5.0] (01.October.2024)
- Backfill feature is not supported.

### [2.4.2] (12.September.2024)
- Fixed the issue causing the initial advertisement loading to fail.

### [2.4.1] (6.September.2024)
- Added privacy manifest file for IOS (If you don't want to update library check the appendix part)

### [2.4.0] (4.September.2024)
- Added a BackFill feature.
- Java version is updated (17)
