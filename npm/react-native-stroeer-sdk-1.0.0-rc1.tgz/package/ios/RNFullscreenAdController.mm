#import "RNFullscreenAdController.h"

#import <UIKit/UIKit.h>
#import "SLogger+RN.h"
#import "StroeerUtils.h"

NSString *const RNFullscreenErrInvalidArgument = @"INVALID_ARGUMENT";
NSString *const RNFullscreenErrUnknownAd = @"UNKNOWN_AD";
NSString *const RNFullscreenErrInvalidState = @"INVALID_STATE";
NSString *const RNFullscreenErrNotReady = @"NOT_READY";
NSString *const RNFullscreenErrNoActivity = @"NO_ACTIVITY";
NSString *const RNFullscreenErrActivityLost = @"ACTIVITY_LOST";
NSString *const RNFullscreenErrLoadFailed = @"LOAD_FAILED";
NSString *const RNFullscreenErrLoadTimeout = @"LOAD_TIMEOUT";
NSString *const RNFullscreenErrShowFailed = @"SHOW_FAILED";
NSString *const RNFullscreenErrDestroyed = @"DESTROYED";
NSString *const RNFullscreenErrAppInBackground = @"APP_IN_BACKGROUND";

// The SDK can fail silently (no callback), so a load is bounded.
static const NSTimeInterval kLoadTimeoutSeconds = 60.0;

typedef NS_ENUM(NSInteger, RNFullscreenAdState) {
  RNFullscreenAdStateIdle,
  RNFullscreenAdStateLoading,
  RNFullscreenAdStateReady,
  RNFullscreenAdStateShowing,
  RNFullscreenAdStateDismissed,
  RNFullscreenAdStateFailed,
};

static NSString *RNFullscreenStateName(RNFullscreenAdState state)
{
  switch (state) {
    case RNFullscreenAdStateIdle: return @"IDLE";
    case RNFullscreenAdStateLoading: return @"LOADING";
    case RNFullscreenAdStateReady: return @"READY";
    case RNFullscreenAdStateShowing: return @"SHOWING";
    case RNFullscreenAdStateDismissed: return @"DISMISSED";
    case RNFullscreenAdStateFailed: return @"FAILED";
  }
  return @"UNKNOWN";
}

@interface RNFullscreenAdRecord : NSObject
@property (nonatomic, copy) NSString *adId;
@property (nonatomic, copy) NSString *slot;
@property (nonatomic, assign) RNFullscreenAdState state;
@property (nonatomic, strong, nullable) id<RNFullscreenSdkAdapter> adapter;
// Identifies the SDK instance whose callbacks are valid; kept after the adapter was released so
// callbacks queued around dismissal still route.
@property (nonatomic, strong, nullable) NSObject *session;
@property (nonatomic, weak, nullable) UIWindow *window;
// The scene the ad belongs to: guessed at load when exactly one scene is foreground active, set
// authoritatively from the presenting window at show. Nil when ownership is unknown.
@property (nonatomic, weak, nullable) UIWindowScene *scene;
@property (nonatomic, copy, nullable) RCTPromiseResolveBlock loadResolve;
@property (nonatomic, copy, nullable) RCTPromiseRejectBlock loadReject;
@property (nonatomic, copy, nullable) RCTPromiseResolveBlock showResolve;
@property (nonatomic, copy, nullable) RCTPromiseRejectBlock showReject;
@property (nonatomic, copy, nullable) dispatch_block_t timeout;
// destroy() was requested while SHOWING: no more public events.
@property (nonatomic, assign) BOOL disposed;
@property (nonatomic, assign) BOOL rewardDelivered;
// SHOWING starts when show() is requested; set once the SDK confirmed the presentation.
@property (nonatomic, assign) BOOL showConfirmed;
@end

@implementation RNFullscreenAdRecord
@end

@implementation RNFullscreenAdController {
  NSString *_logTag;
  RNFullscreenSdkAdapterFactory _adapterFactory;
  __weak id<RNFullscreenAdEvents> _events;
  NSMutableDictionary<NSString *, RNFullscreenAdRecord *> *_records;
  BOOL _invalidated;
  BOOL _appActive;
  NSMutableArray<id> *_observers;
}

- (instancetype)initWithLogTag:(NSString *)logTag
                adapterFactory:(RNFullscreenSdkAdapterFactory)adapterFactory
                        events:(id<RNFullscreenAdEvents>)events
{
  if ((self = [super init])) {
    _logTag = [logTag copy];
    _adapterFactory = [adapterFactory copy];
    _events = events;
    _records = [NSMutableDictionary new];
    _appActive = [UIApplication sharedApplication].applicationState == UIApplicationStateActive;
    _observers = [NSMutableArray new];

    __weak RNFullscreenAdController *weakSelf = self;
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [_observers addObject:[center addObserverForName:UIApplicationDidBecomeActiveNotification
                                              object:nil
                                               queue:[NSOperationQueue mainQueue]
                                          usingBlock:^(NSNotification *_) { [weakSelf setAppActive:YES]; }]];
    [_observers addObject:[center addObserverForName:UISceneDidDisconnectNotification
                                              object:nil
                                               queue:[NSOperationQueue mainQueue]
                                          usingBlock:^(NSNotification *note) { [weakSelf onSceneDisconnected:note.object]; }]];
    [_observers addObject:[center addObserverForName:UIApplicationWillResignActiveNotification
                                              object:nil
                                               queue:[NSOperationQueue mainQueue]
                                          usingBlock:^(NSNotification *_) { [weakSelf setAppActive:NO]; }]];
  }
  return self;
}

- (void)dealloc
{
  for (id observer in _observers) [[NSNotificationCenter defaultCenter] removeObserver:observer];
}

// The only scene an ad can be attributed to without a presenter: the single foreground active
// one. Nil when there is none or several (ambiguous).
- (nullable UIWindowScene *)unambiguousActiveScene
{
  UIWindowScene *found = nil;
  for (UIScene *candidate in [UIApplication sharedApplication].connectedScenes) {
    if (![candidate isKindOfClass:[UIWindowScene class]]) continue;
    if (candidate.activationState != UISceneActivationStateForegroundActive) continue;
    if (found) return nil;
    found = (UIWindowScene *)candidate;
  }
  return found;
}

// The host scene is going away (Android: Activity destroyed): ads still loading fail, loaded but
// not shown ads can no longer be shown. A confirmed presentation is left to the SDK; an
// unconfirmed one will never be confirmed, so its pending show is settled. Records are kept
// until destroy.
- (void)onSceneDisconnected:(id)scene
{
  for (RNFullscreenAdRecord *record in [_records.allValues copy]) {
    UIWindowScene *owner = record.scene;
    if (record.state == RNFullscreenAdStateShowing) {
      if (record.showConfirmed) continue;
      // Without a known scene, fall back to the presenting window (gone window: scene is gone too).
      if (owner ? owner != scene : (record.window && record.window.windowScene != scene)) continue;
      [self failShow:record
                code:RNFullscreenErrActivityLost
             message:@"The scene was disconnected while the ad was being shown"];
      continue;
    }
    if (!owner || owner != scene) continue;
    switch (record.state) {
      case RNFullscreenAdStateLoading:
        [self failLoad:record
                  code:RNFullscreenErrActivityLost
               message:@"The scene was disconnected while the ad was loading"];
        break;
      case RNFullscreenAdStateReady:
        record.state = RNFullscreenAdStateFailed;
        [self cancelTimeout:record];
        [self releaseAdapter:record];
        break;
      default:
        break;
    }
  }
}

- (void)setAppActive:(BOOL)active
{
  _appActive = active;
}

#pragma mark - Public API

- (void)createWithSlot:(NSString *)slot resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  if (_invalidated) {
    reject(RNFullscreenErrDestroyed, @"The React instance was destroyed", nil);
    return;
  }
  if (slot.length == 0) {
    reject(RNFullscreenErrInvalidArgument, @"publisherSlotName must not be empty", nil);
    return;
  }
  NSString *adId = [NSUUID UUID].UUIDString;
  while (_records[adId]) adId = [NSUUID UUID].UUIDString;
  RNFullscreenAdRecord *record = [RNFullscreenAdRecord new];
  record.adId = adId;
  record.slot = slot;
  record.state = RNFullscreenAdStateIdle;
  _records[adId] = record;
  resolve(adId);
}

- (void)load:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNFullscreenAdRecord *record = _records[adId];
  if (!record) {
    reject(RNFullscreenErrUnknownAd, [NSString stringWithFormat:@"Unknown ad: %@", adId], nil);
    return;
  }
  if (record.state != RNFullscreenAdStateIdle) {
    reject(RNFullscreenErrInvalidState,
           [NSString stringWithFormat:@"Cannot load an ad in state %@; an ad can only be loaded once",
                                      RNFullscreenStateName(record.state)],
           nil);
    return;
  }
  // The SDK needs no view controller to load (only show does), so early preloads are allowed.
  record.state = RNFullscreenAdStateLoading;
  record.scene = [self unambiguousActiveScene];
  record.loadResolve = resolve;
  record.loadReject = reject;
  NSObject *session = [NSObject new];
  record.session = session;

  @try {
    id<RNFullscreenSdkAdapter> adapter = _adapterFactory();
    record.adapter = adapter;
    RNFullscreenSdkCallbacks *callbacks = [self callbacksForRecord:record session:session];

    __weak RNFullscreenAdController *weakSelf = self;
    dispatch_block_t timeout = dispatch_block_create((dispatch_block_flags_t)0, ^{
      [weakSelf onLoadTimeout:record session:session];
    });
    record.timeout = timeout;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(kLoadTimeoutSeconds * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), timeout);

    [adapter loadWithSlot:record.slot callbacks:callbacks];
  } @catch (NSException *e) {
    [RNSLogger e:[NSString stringWithFormat:@"%@ Error loading ad: %@", _logTag, e.reason]];
    [self failLoad:record code:RNFullscreenErrLoadFailed message:e.reason ?: @"Failed to load ad"];
  }
}

- (void)show:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNFullscreenAdRecord *record = _records[adId];
  if (!record) {
    reject(RNFullscreenErrUnknownAd, [NSString stringWithFormat:@"Unknown ad: %@", adId], nil);
    return;
  }
  switch (record.state) {
    case RNFullscreenAdStateReady:
      break;
    case RNFullscreenAdStateIdle:
    case RNFullscreenAdStateLoading:
      reject(RNFullscreenErrNotReady, @"The ad is not loaded yet", nil);
      return;
    default:
      reject(RNFullscreenErrInvalidState,
             [NSString stringWithFormat:@"Cannot show an ad in state %@; an ad can only be shown once",
                                        RNFullscreenStateName(record.state)],
             nil);
      return;
  }

  // A precondition rejection: no event, the ad stays READY and can be shown once the app is active.
  if (!_appActive) {
    reject(RNFullscreenErrAppInBackground, @"The app is in the background; show the ad once it is in the foreground", nil);
    return;
  }

  // The SDK no-ops silently when it cannot present, so check the presenter here: it must live in
  // a window; that window is tracked for this presentation only (scene teardown).
  UIViewController *presenter = [StroeerUtils presentingViewController];
  UIWindow *window = presenter.view.window;
  if (!presenter || !window) {
    NSString *message = @"No view controller is available to present the ad";
    record.state = RNFullscreenAdStateFailed;
    [self releaseAdapter:record];
    [self emitFailedToShow:record code:RNFullscreenErrActivityLost message:message];
    reject(RNFullscreenErrActivityLost, message, nil);
    return;
  }

  record.state = RNFullscreenAdStateShowing;
  record.window = window;
  record.scene = window.windowScene;
  record.showResolve = resolve;
  record.showReject = reject;
  @try {
    [record.adapter showWithViewController:presenter];
  } @catch (NSException *e) {
    [RNSLogger e:[NSString stringWithFormat:@"%@ Error showing ad: %@", _logTag, e.reason]];
    [self failShow:record code:RNFullscreenErrShowFailed message:e.reason ?: @"Failed to show ad"];
  }
}

- (BOOL)isReady:(NSString *)adId
{
  RNFullscreenAdRecord *record = _records[adId];
  if (!record || record.state != RNFullscreenAdStateReady) return NO;
  return YES;
}

- (void)destroy:(NSString *)adId resolve:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject
{
  RNFullscreenAdRecord *record = _records[adId];
  if (record) [self destroyRecord:record];
  resolve(nil);
}

- (void)invalidate
{
  if (_invalidated) return;
  _invalidated = YES;
  _events = nil;
  for (id observer in _observers) [[NSNotificationCenter defaultCenter] removeObserver:observer];
  [_observers removeAllObjects];
  for (RNFullscreenAdRecord *record in [_records.allValues copy]) {
    [self destroyRecord:record];
    // A showing ad keeps its adapter after destroyRecord:; nothing will route its dismissal now.
    [self releaseAdapter:record];
  }
  [_records removeAllObjects];
}

#pragma mark - Destroy

- (void)destroyRecord:(RNFullscreenAdRecord *)record
{
  [self cancelTimeout:record];
  if (record.state == RNFullscreenAdStateShowing) {
    // The ad is still on screen: suppress public events and let the dismissal / show failure
    // callback release it and remove the record.
    record.disposed = YES;
    [self settleShowReject:record code:RNFullscreenErrDestroyed message:@"The ad was destroyed"];
    return;
  }
  [_records removeObjectForKey:record.adId];
  record.disposed = YES;
  [self settleLoadReject:record code:RNFullscreenErrDestroyed message:@"The ad was destroyed"];
  [self settleShowReject:record code:RNFullscreenErrDestroyed message:@"The ad was destroyed"];
  [self releaseAdapter:record];
}

#pragma mark - SDK callbacks

- (RNFullscreenSdkCallbacks *)callbacksForRecord:(RNFullscreenAdRecord *)record session:(NSObject *)session
{
  __weak RNFullscreenAdController *weakSelf = self;
  __weak RNFullscreenAdRecord *weakRecord = record;
  // Valid while the record is registered and belongs to this SDK instance.
  BOOL (^isCurrent)(NSString *) = ^BOOL(NSString *caller) {
    __strong RNFullscreenAdController *self_ = weakSelf;
    RNFullscreenAdRecord *r = weakRecord;
    BOOL current = self_ && r && self_->_records[r.adId] == r && r.session == session;
    if (!current) {
      [RNSLogger d:[NSString stringWithFormat:@"[FullscreenAdController] Ignoring %@ from a stale ad instance", caller]];
    }
    return current;
  };

  RNFullscreenSdkCallbacks *cb = [RNFullscreenSdkCallbacks new];

  cb.onLoaded = ^{
    if (!isCurrent(@"onAdLoaded")) return;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.state != RNFullscreenAdStateLoading) return;
    [weakSelf cancelTimeout:r];
    r.state = RNFullscreenAdStateReady;
    [weakSelf emit:^(id<RNFullscreenAdEvents> e) { [e onAdLoaded:r.adId]; } event:@"onAdLoaded" record:r];
    [weakSelf settleLoadResolve:r];
  };
  cb.onFailedToLoad = ^(NSString *message) {
    if (!isCurrent(@"onAdFailedToLoad")) return;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.state != RNFullscreenAdStateLoading) return;
    [weakSelf failLoad:r code:RNFullscreenErrLoadFailed message:message ?: @"Failed to load ad"];
  };
  cb.onShowed = ^{
    if (!isCurrent(@"onAdShowed")) return;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.state != RNFullscreenAdStateShowing) return;
    r.showConfirmed = YES;
    if (!r.disposed) {
      [weakSelf emit:^(id<RNFullscreenAdEvents> e) { [e onAdShowed:r.adId]; } event:@"onAdShowed" record:r];
    }
    [weakSelf settleShowResolve:r];
  };
  cb.onDismissed = ^{
    if (!isCurrent(@"onAdDismissed")) return;
    __strong RNFullscreenAdController *self_ = weakSelf;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.state != RNFullscreenAdStateShowing) return;
    if (r.disposed) {
      // destroy() was requested while showing: release now.
      r.state = RNFullscreenAdStateDismissed;
      [self_ releaseAdapter:r];
      [self_->_records removeObjectForKey:r.adId];
      return;
    }
    if (!r.showConfirmed) {
      // Dismissed without a showed callback: the presentation never happened.
      [self_ failShow:r code:RNFullscreenErrShowFailed message:@"The ad was dismissed before it was shown"];
      return;
    }
    r.state = RNFullscreenAdStateDismissed;
    // The adapter stays alive until destroy / invalidate: a reward may arrive after dismissal.
    [self_ emit:^(id<RNFullscreenAdEvents> e) { [e onAdDismissed:r.adId]; } event:@"onAdDismissed" record:r];
  };
  cb.onFailedToShow = ^(NSString *message) {
    if (!isCurrent(@"onAdFailedToShow")) return;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.state != RNFullscreenAdStateShowing) return;
    [weakSelf failShow:r code:RNFullscreenErrShowFailed message:message ?: @"Failed to show ad"];
  };
  cb.onClicked = ^{
    if (!isCurrent(@"onAdClicked")) return;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.disposed || ![weakSelf isPresented:r]) return;
    [weakSelf emit:^(id<RNFullscreenAdEvents> e) { [e onAdClicked:r.adId]; } event:@"onAdClicked" record:r];
  };
  cb.onImpression = ^{
    if (!isCurrent(@"onAdImpression")) return;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.disposed || ![weakSelf isPresented:r]) return;
    [weakSelf emit:^(id<RNFullscreenAdEvents> e) { [e onAdImpression:r.adId]; } event:@"onAdImpression" record:r];
  };
  cb.onUserEarnedReward = ^(NSString *type, NSNumber *amount) {
    if (!isCurrent(@"onUserEarnedReward")) return;
    __strong RNFullscreenAdController *self_ = weakSelf;
    RNFullscreenAdRecord *r = weakRecord;
    if (r.disposed || ![self_ isPresented:r]) return;
    if (type == nil || amount == nil) {
      [RNSLogger e:[NSString stringWithFormat:@"%@ The SDK delivered no reward item; no reward event emitted", self_->_logTag]];
      return;
    }
    if (r.rewardDelivered) {
      [RNSLogger e:[NSString stringWithFormat:@"%@ Ignoring a second reward for the same ad", self_->_logTag]];
      return;
    }
    if (![self_->_events respondsToSelector:@selector(onUserEarnedReward:type:amount:)]) return;
    r.rewardDelivered = YES;
    [RNSLogger i:[NSString stringWithFormat:@"%@ onUserEarnedReward - slot: %@, adId: %@, reward: %@ %@",
                                            self_->_logTag, r.slot, r.adId, amount, type]];
    [self_->_events onUserEarnedReward:r.adId type:type amount:amount.doubleValue];
  };
  return cb;
}

// Callbacks queued around dismissal still route, hence DISMISSED counts as well.
- (BOOL)isPresented:(RNFullscreenAdRecord *)record
{
  return record.state == RNFullscreenAdStateShowing || record.state == RNFullscreenAdStateDismissed;
}

- (void)onLoadTimeout:(RNFullscreenAdRecord *)record session:(NSObject *)session
{
  if (_records[record.adId] != record || record.session != session) return;
  if (record.state != RNFullscreenAdStateLoading) return;
  [self failLoad:record
            code:RNFullscreenErrLoadTimeout
         message:[NSString stringWithFormat:@"The ad did not finish loading within %d seconds", (int)kLoadTimeoutSeconds]];
}

#pragma mark - Failures and settlement

- (void)failLoad:(RNFullscreenAdRecord *)record code:(NSString *)code message:(NSString *)message
{
  [self cancelTimeout:record];
  record.state = RNFullscreenAdStateFailed;
  [self releaseAdapter:record];
  if (!record.disposed) {
    [RNSLogger e:[NSString stringWithFormat:@"%@ onAdFailedToLoad - slot: %@, adId: %@, code: %@, message: %@",
                                            _logTag, record.slot, record.adId, code, message]];
    [_events onAdFailedToLoad:record.adId code:code message:message];
  }
  [self settleLoadReject:record code:code message:message];
}

- (void)failShow:(RNFullscreenAdRecord *)record code:(NSString *)code message:(NSString *)message
{
  record.state = RNFullscreenAdStateFailed;
  [self releaseAdapter:record];
  if (record.disposed) {
    [_records removeObjectForKey:record.adId];
    return;
  }
  [self emitFailedToShow:record code:code message:message];
  [self settleShowReject:record code:code message:message];
}

- (void)emitFailedToShow:(RNFullscreenAdRecord *)record code:(NSString *)code message:(NSString *)message
{
  [RNSLogger e:[NSString stringWithFormat:@"%@ onAdFailedToShow - slot: %@, adId: %@, code: %@, message: %@",
                                          _logTag, record.slot, record.adId, code, message]];
  [_events onAdFailedToShow:record.adId code:code message:message];
}

- (void)emit:(void (^)(id<RNFullscreenAdEvents>))block event:(NSString *)name record:(RNFullscreenAdRecord *)record
{
  [RNSLogger i:[NSString stringWithFormat:@"%@ %@ - slot: %@, adId: %@", _logTag, name, record.slot, record.adId]];
  block(_events);
}

- (void)cancelTimeout:(RNFullscreenAdRecord *)record
{
  if (record.timeout) dispatch_block_cancel(record.timeout);
  record.timeout = nil;
}

- (void)settleLoadResolve:(RNFullscreenAdRecord *)record
{
  RCTPromiseResolveBlock resolve = record.loadResolve;
  record.loadResolve = nil;
  record.loadReject = nil;
  if (resolve) resolve(nil);
}

- (void)settleLoadReject:(RNFullscreenAdRecord *)record code:(NSString *)code message:(NSString *)message
{
  RCTPromiseRejectBlock reject = record.loadReject;
  record.loadResolve = nil;
  record.loadReject = nil;
  if (reject) reject(code, message, nil);
}

- (void)settleShowResolve:(RNFullscreenAdRecord *)record
{
  RCTPromiseResolveBlock resolve = record.showResolve;
  record.showResolve = nil;
  record.showReject = nil;
  if (resolve) resolve(nil);
}

- (void)settleShowReject:(RNFullscreenAdRecord *)record code:(NSString *)code message:(NSString *)message
{
  RCTPromiseRejectBlock reject = record.showReject;
  record.showResolve = nil;
  record.showReject = nil;
  if (reject) reject(code, message, nil);
}

/// Releases the SDK instance exactly once.
- (void)releaseAdapter:(RNFullscreenAdRecord *)record
{
  id<RNFullscreenSdkAdapter> adapter = record.adapter;
  record.adapter = nil;
  [adapter destroy];
}

@end
