require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "react-native-stroeer-sdk"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => min_ios_version_supported }
  s.source       = { :git => "https://github.com/mbrtargeting/stroeerSDK-react-native.git", :tag => "#{s.version}" }

  s.source_files = "ios/**/*.{h,m,mm,swift}"

  # Installs all the React Native dependencies (React-Core, RCT-Folly, codegen
  # artifacts, ReactCommon/turbomodule, ...) and sets the required compiler flags.
  # Required since RN 0.82, where the New Architecture is always enabled.
  install_modules_dependencies(s)

  # StroeerSDK is not published to CocoaPods trunk. Consuming apps must declare it in their
  # Podfile with an explicit :podspec URL, e.g.
  #   pod 'StroeerSDK', :podspec => 'https://stroeersdk.github.io/iOS/CocoaPods/StroeerSDK.podspec',
  #                     :subspecs => ['Core', 'Consent']
  # Only the default Core subspec is required here (the bridge, including ConfiantLoader, compiles
  # against Core); apps that need CMP add the Consent subspec themselves.
  s.dependency 'StroeerSDK', '1.0.0-rc.3'
end
